CREATE TABLE `community_area` (
  `community_area_no` int NOT NULL,
  `community_area_name` varchar(64)  DEFAULT NULL,
  `side` varchar(64)  DEFAULT NULL,
  `population` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`community_area_no`)
);

CREATE TABLE `crime` (
  `report_no` int NOT NULL,
  `case_number` varchar(64)  DEFAULT NULL,
  `DATE` varchar(64)  DEFAULT NULL,
  `block` varchar(64)  DEFAULT NULL,
  `iucr_no` varchar(64)  DEFAULT NULL,
  `location_description` varchar(64)  DEFAULT NULL,
  `arrest` varchar(64)  DEFAULT NULL,
  `domestic` varchar(64)  DEFAULT NULL,
  `beat` int DEFAULT NULL,
  `district_no` int DEFAULT NULL,
  `ward_no` int DEFAULT NULL,
  `community_area_no` int DEFAULT NULL,
  `fbi_code_no` varchar(64)  DEFAULT NULL,
  `latitude` varchar(64)  DEFAULT NULL,
  `longitude` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`report_no`),
  KEY `fk_Crime_ward_no` (`ward_no`),
  KEY `fk_Crime_iucr_no` (`iucr_no`),
  KEY `fk_Crime_district_no` (`district_no`),
  KEY `fk_Crime_community_area_no` (`community_area_no`),
  KEY `fk_Crime_fbi_code_no` (`fbi_code_no`)
);

CREATE TABLE `district` (
  `district_no` int NOT NULL,
  `district_name` varchar(64)  DEFAULT NULL,
  `address` varchar(64)  DEFAULT NULL,
  `zip_code` int DEFAULT NULL,
  `commander` varchar(64)  DEFAULT NULL,
  `email` varchar(64)  DEFAULT NULL,
  `phone` varchar(64)  DEFAULT NULL,
  `fax` varchar(64)  DEFAULT NULL,
  `tty` varchar(64)  DEFAULT NULL,
  `twitter` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`district_no`)
);

CREATE TABLE `fbi_code` (
  `fbi_code_no` varchar(64)  NOT NULL,
  `title` varchar(64)  DEFAULT NULL,
  `description` varchar(512)  DEFAULT NULL,
  `crime_against` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`fbi_code_no`)
);

CREATE TABLE `iucr` (
  `iucr_no` varchar(64)  NOT NULL,
  `primary_description` varchar(64)  DEFAULT NULL,
  `secondary_description` varchar(64)  DEFAULT NULL,
  `index_code` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`iucr_no`)
);

CREATE TABLE `neighborhood` (
  `neighborhood_name` varchar(64)  NOT NULL,
  `community_area_no` int DEFAULT NULL,
  PRIMARY KEY (`neighborhood_name`),
  KEY `fk_Neighborhood_community_area_no` (`community_area_no`)
);

CREATE TABLE `ward` (
  `ward_no` int NOT NULL,
  `alderman_first_name` varchar(64)  DEFAULT NULL,
  `alderman_last_name` varchar(64)  DEFAULT NULL,
  `alderman_name_suffix` varchar(64)  DEFAULT NULL,
  `ward_office_address` varchar(64)  DEFAULT NULL,
  `ward_office_zip` varchar(64)  DEFAULT NULL,
  `ward_email` varchar(64)  DEFAULT NULL,
  `ward_office_phone` varchar(64)  DEFAULT NULL,
  `ward_office_fax` varchar(64)  DEFAULT NULL,
  `city_hall_office_room` int DEFAULT NULL,
  `city_hall_office_phone` varchar(64)  DEFAULT NULL,
  `city_hall_office_fax` varchar(64)  DEFAULT NULL,
  `Population` int DEFAULT NULL,
  PRIMARY KEY (`ward_no`)
);


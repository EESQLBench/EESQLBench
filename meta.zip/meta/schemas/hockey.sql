CREATE TABLE `abbrev` (
  `Type` varchar(64)  NOT NULL,
  `Code` varchar(64)  NOT NULL,
  `Fullname` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`Type`,`Code`)
);

CREATE TABLE `awardscoaches` (
  `coachID` varchar(64)  DEFAULT NULL,
  `award` varchar(64)  DEFAULT NULL,
  `year` int DEFAULT NULL,
  `lgID` varchar(64)  DEFAULT NULL,
  `note` varchar(256)  DEFAULT NULL,
  KEY `fk_AwardsCoaches_coachID` (`coachID`)
);

CREATE TABLE `awardsmisc` (
  `name` varchar(64)  NOT NULL,
  `ID` varchar(64)  DEFAULT NULL,
  `award` varchar(64)  DEFAULT NULL,
  `year` int DEFAULT NULL,
  `lgID` varchar(64)  DEFAULT NULL,
  `note` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`name`)
);

CREATE TABLE `awardsplayers` (
  `playerID` varchar(64)  NOT NULL,
  `award` varchar(64)  NOT NULL,
  `year` int NOT NULL,
  `lgID` varchar(64)  DEFAULT NULL,
  `note` varchar(64)  DEFAULT NULL,
  `pos` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`playerID`,`award`,`year`)
);

CREATE TABLE `coaches` (
  `coachID` varchar(64)  NOT NULL,
  `year` int NOT NULL,
  `tmID` varchar(64)  NOT NULL,
  `lgID` varchar(64)  DEFAULT NULL,
  `stint` int NOT NULL,
  `notes` varchar(64)  DEFAULT NULL,
  `g` int DEFAULT NULL,
  `w` int DEFAULT NULL,
  `l` int DEFAULT NULL,
  `t` int DEFAULT NULL,
  `postg` varchar(64)  DEFAULT NULL,
  `postw` varchar(64)  DEFAULT NULL,
  `postl` varchar(64)  DEFAULT NULL,
  `postt` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`coachID`,`year`,`tmID`,`stint`)
);

CREATE TABLE `combinedshutouts` (
  `year` int DEFAULT NULL,
  `month` int DEFAULT NULL,
  `DATE` int DEFAULT NULL,
  `tmID` varchar(64)  DEFAULT NULL,
  `oppID` varchar(64)  DEFAULT NULL,
  `R/P` text ,
  `IDgoalie1` varchar(64)  DEFAULT NULL,
  `IDgoalie2` varchar(64)  DEFAULT NULL,
  KEY `fk_CombinedShutouts_IDgoalie1` (`IDgoalie1`),
  KEY `fk_CombinedShutouts_IDgoalie2` (`IDgoalie2`)
);

CREATE TABLE `goalies` (
  `playerID` varchar(64)  NOT NULL,
  `year` int NOT NULL,
  `stint` int NOT NULL,
  `tmID` varchar(64)  DEFAULT NULL,
  `lgID` varchar(64)  DEFAULT NULL,
  `GP` varchar(64)  DEFAULT NULL,
  `Min` varchar(64)  DEFAULT NULL,
  `W` varchar(64)  DEFAULT NULL,
  `L` varchar(64)  DEFAULT NULL,
  `T/OL` text ,
  `ENG` varchar(64)  DEFAULT NULL,
  `SHO` varchar(64)  DEFAULT NULL,
  `GA` varchar(64)  DEFAULT NULL,
  `SA` varchar(64)  DEFAULT NULL,
  `PostGP` varchar(64)  DEFAULT NULL,
  `PostMin` varchar(64)  DEFAULT NULL,
  `PostW` varchar(64)  DEFAULT NULL,
  `PostL` varchar(64)  DEFAULT NULL,
  `PostT` varchar(64)  DEFAULT NULL,
  `PostENG` varchar(64)  DEFAULT NULL,
  `PostSHO` varchar(64)  DEFAULT NULL,
  `PostGA` varchar(64)  DEFAULT NULL,
  `PostSA` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`playerID`,`year`,`stint`)
);

CREATE TABLE `goaliessc` (
  `playerID` varchar(64)  NOT NULL,
  `year` int NOT NULL,
  `tmID` varchar(64)  DEFAULT NULL,
  `lgID` varchar(64)  DEFAULT NULL,
  `GP` int DEFAULT NULL,
  `Min` int DEFAULT NULL,
  `W` int DEFAULT NULL,
  `L` int DEFAULT NULL,
  `T` int DEFAULT NULL,
  `SHO` int DEFAULT NULL,
  `GA` int DEFAULT NULL,
  PRIMARY KEY (`playerID`,`year`)
);

CREATE TABLE `goaliesshootout` (
  `playerID` varchar(64)  DEFAULT NULL,
  `year` int DEFAULT NULL,
  `stint` int DEFAULT NULL,
  `tmID` varchar(64)  DEFAULT NULL,
  `W` int DEFAULT NULL,
  `L` int DEFAULT NULL,
  `SA` int DEFAULT NULL,
  `GA` int DEFAULT NULL,
  KEY `fk_GoaliesShootout_playerID` (`playerID`)
);

CREATE TABLE `hof` (
  `year` int DEFAULT NULL,
  `hofID` varchar(64)  NOT NULL,
  `name` varchar(64)  DEFAULT NULL,
  `category` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`hofID`)
);

CREATE TABLE `master` (
  `playerID` varchar(64)  DEFAULT NULL,
  `coachID` varchar(64)  DEFAULT NULL,
  `hofID` varchar(64)  DEFAULT NULL,
  `firstName` varchar(64)  DEFAULT NULL,
  `lastName` varchar(64)  NOT NULL,
  `nameNote` varchar(64)  DEFAULT NULL,
  `nameGiven` varchar(64)  DEFAULT NULL,
  `nameNick` varchar(64)  DEFAULT NULL,
  `height` varchar(64)  DEFAULT NULL,
  `weight` varchar(64)  DEFAULT NULL,
  `shootCatch` varchar(64)  DEFAULT NULL,
  `legendsID` varchar(64)  DEFAULT NULL,
  `ihdbID` varchar(64)  DEFAULT NULL,
  `hrefID` varchar(64)  DEFAULT NULL,
  `firstNHL` varchar(64)  DEFAULT NULL,
  `lastNHL` varchar(64)  DEFAULT NULL,
  `firstWHA` varchar(64)  DEFAULT NULL,
  `lastWHA` varchar(64)  DEFAULT NULL,
  `pos` varchar(64)  DEFAULT NULL,
  `birthYear` varchar(64)  DEFAULT NULL,
  `birthMon` varchar(64)  DEFAULT NULL,
  `birthDay` varchar(64)  DEFAULT NULL,
  `birthCountry` varchar(64)  DEFAULT NULL,
  `birthState` varchar(64)  DEFAULT NULL,
  `birthCity` varchar(64)  DEFAULT NULL,
  `deathYear` varchar(64)  DEFAULT NULL,
  `deathMon` varchar(64)  DEFAULT NULL,
  `deathDay` varchar(64)  DEFAULT NULL,
  `deathCountry` varchar(64)  DEFAULT NULL,
  `deathState` varchar(64)  DEFAULT NULL,
  `deathCity` varchar(64)  DEFAULT NULL,
  UNIQUE KEY `uk_playerID` (`playerID`),
  KEY `fk_Master_coachID` (`coachID`)
);

CREATE TABLE `scoring` (
  `playerID` varchar(64)  DEFAULT NULL,
  `year` int DEFAULT NULL,
  `stint` int DEFAULT NULL,
  `tmID` varchar(64)  DEFAULT NULL,
  `lgID` varchar(64)  DEFAULT NULL,
  `pos` varchar(64)  DEFAULT NULL,
  `GP` int DEFAULT NULL,
  `G` int DEFAULT NULL,
  `A` int DEFAULT NULL,
  `Pts` int DEFAULT NULL,
  `PIM` int DEFAULT NULL,
  `+/-` text ,
  `PPG` varchar(64)  DEFAULT NULL,
  `PPA` varchar(64)  DEFAULT NULL,
  `SHG` varchar(64)  DEFAULT NULL,
  `SHA` varchar(64)  DEFAULT NULL,
  `GWG` varchar(64)  DEFAULT NULL,
  `GTG` varchar(64)  DEFAULT NULL,
  `SOG` varchar(64)  DEFAULT NULL,
  `PostGP` varchar(64)  DEFAULT NULL,
  `PostG` varchar(64)  DEFAULT NULL,
  `PostA` varchar(64)  DEFAULT NULL,
  `PostPts` varchar(64)  DEFAULT NULL,
  `PostPIM` varchar(64)  DEFAULT NULL,
  `Post+/-` text ,
  `PostPPG` varchar(64)  DEFAULT NULL,
  `PostPPA` varchar(64)  DEFAULT NULL,
  `PostSHG` varchar(64)  DEFAULT NULL,
  `PostSHA` varchar(64)  DEFAULT NULL,
  `PostGWG` varchar(64)  DEFAULT NULL,
  `PostSOG` varchar(64)  DEFAULT NULL,
  KEY `fk_Scoring_playerID` (`playerID`)
);

CREATE TABLE `scoringsc` (
  `playerID` varchar(64)  DEFAULT NULL,
  `year` int DEFAULT NULL,
  `tmID` varchar(64)  DEFAULT NULL,
  `lgID` varchar(64)  DEFAULT NULL,
  `pos` varchar(64)  DEFAULT NULL,
  `GP` int DEFAULT NULL,
  `G` int DEFAULT NULL,
  `A` int DEFAULT NULL,
  `Pts` int DEFAULT NULL,
  `PIM` int DEFAULT NULL,
  KEY `fk_ScoringSC_playerID` (`playerID`)
);

CREATE TABLE `scoringshootout` (
  `playerID` varchar(64)  DEFAULT NULL,
  `year` int DEFAULT NULL,
  `stint` int DEFAULT NULL,
  `tmID` varchar(64)  DEFAULT NULL,
  `S` int DEFAULT NULL,
  `G` int DEFAULT NULL,
  `GDG` int DEFAULT NULL,
  KEY `fk_ScoringShootout_playerID` (`playerID`)
);

CREATE TABLE `scoringsup` (
  `playerID` varchar(64)  DEFAULT NULL,
  `year` int DEFAULT NULL,
  `PPA` varchar(64)  DEFAULT NULL,
  `SHA` varchar(64)  DEFAULT NULL,
  KEY `fk_ScoringSup_playerID` (`playerID`)
);

CREATE TABLE `seriespost` (
  `year` int DEFAULT NULL,
  `round` varchar(64)  DEFAULT NULL,
  `series` varchar(64)  DEFAULT NULL,
  `tmIDWinner` varchar(64)  DEFAULT NULL,
  `lgIDWinner` varchar(64)  DEFAULT NULL,
  `tmIDLoser` varchar(64)  DEFAULT NULL,
  `lgIDLoser` varchar(64)  DEFAULT NULL,
  `W` int DEFAULT NULL,
  `L` int DEFAULT NULL,
  `T` int DEFAULT NULL,
  `GoalsWinner` int DEFAULT NULL,
  `GoalsLoser` int DEFAULT NULL,
  `note` varchar(64)  DEFAULT NULL
);

CREATE TABLE `teams` (
  `year` int NOT NULL,
  `lgID` varchar(64)  DEFAULT NULL,
  `tmID` varchar(64)  NOT NULL,
  `franchID` varchar(64)  DEFAULT NULL,
  `confID` varchar(64)  DEFAULT NULL,
  `divID` varchar(64)  DEFAULT NULL,
  `rank` int DEFAULT NULL,
  `playoff` varchar(64)  DEFAULT NULL,
  `G` int DEFAULT NULL,
  `W` int DEFAULT NULL,
  `L` int DEFAULT NULL,
  `T` int DEFAULT NULL,
  `OTL` varchar(64)  DEFAULT NULL,
  `Pts` int DEFAULT NULL,
  `SoW` varchar(64)  DEFAULT NULL,
  `SoL` varchar(64)  DEFAULT NULL,
  `GF` int DEFAULT NULL,
  `GA` int DEFAULT NULL,
  `name` varchar(64)  DEFAULT NULL,
  `PIM` varchar(64)  DEFAULT NULL,
  `BenchMinor` varchar(64)  DEFAULT NULL,
  `PPG` varchar(64)  DEFAULT NULL,
  `PPC` varchar(64)  DEFAULT NULL,
  `SHA` varchar(64)  DEFAULT NULL,
  `PKG` varchar(64)  DEFAULT NULL,
  `PKC` varchar(64)  DEFAULT NULL,
  `SHF` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`year`,`tmID`)
);

CREATE TABLE `teamshalf` (
  `year` int NOT NULL,
  `lgID` varchar(64)  DEFAULT NULL,
  `tmID` varchar(64)  NOT NULL,
  `half` int NOT NULL,
  `rank` int DEFAULT NULL,
  `G` int DEFAULT NULL,
  `W` int DEFAULT NULL,
  `L` int DEFAULT NULL,
  `T` int DEFAULT NULL,
  `GF` int DEFAULT NULL,
  `GA` int DEFAULT NULL,
  PRIMARY KEY (`year`,`tmID`,`half`)
);

CREATE TABLE `teamsplits` (
  `year` int NOT NULL,
  `lgID` varchar(64)  DEFAULT NULL,
  `tmID` varchar(64)  NOT NULL,
  `hW` int DEFAULT NULL,
  `hL` int DEFAULT NULL,
  `hT` int DEFAULT NULL,
  `hOTL` varchar(64)  DEFAULT NULL,
  `rW` int DEFAULT NULL,
  `rL` int DEFAULT NULL,
  `rT` int DEFAULT NULL,
  `rOTL` varchar(64)  DEFAULT NULL,
  `SepW` varchar(64)  DEFAULT NULL,
  `SepL` varchar(64)  DEFAULT NULL,
  `SepT` varchar(256)  DEFAULT NULL,
  `SepOL` varchar(64)  DEFAULT NULL,
  `OctW` varchar(64)  DEFAULT NULL,
  `OctL` varchar(64)  DEFAULT NULL,
  `OctT` varchar(64)  DEFAULT NULL,
  `OctOL` varchar(64)  DEFAULT NULL,
  `NovW` varchar(64)  DEFAULT NULL,
  `NovL` varchar(64)  DEFAULT NULL,
  `NovT` varchar(64)  DEFAULT NULL,
  `NovOL` varchar(64)  DEFAULT NULL,
  `DecW` varchar(64)  DEFAULT NULL,
  `DecL` varchar(64)  DEFAULT NULL,
  `DecT` varchar(64)  DEFAULT NULL,
  `DecOL` varchar(64)  DEFAULT NULL,
  `JanW` int DEFAULT NULL,
  `JanL` int DEFAULT NULL,
  `JanT` int DEFAULT NULL,
  `JanOL` varchar(64)  DEFAULT NULL,
  `FebW` int DEFAULT NULL,
  `FebL` int DEFAULT NULL,
  `FebT` int DEFAULT NULL,
  `FebOL` varchar(64)  DEFAULT NULL,
  `MarW` varchar(64)  DEFAULT NULL,
  `MarL` varchar(64)  DEFAULT NULL,
  `MarT` varchar(64)  DEFAULT NULL,
  `MarOL` varchar(64)  DEFAULT NULL,
  `AprW` varchar(64)  DEFAULT NULL,
  `AprL` varchar(64)  DEFAULT NULL,
  `AprT` varchar(64)  DEFAULT NULL,
  `AprOL` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`year`,`tmID`)
);

CREATE TABLE `teamspost` (
  `year` int NOT NULL,
  `lgID` varchar(64)  DEFAULT NULL,
  `tmID` varchar(64)  NOT NULL,
  `G` int DEFAULT NULL,
  `W` int DEFAULT NULL,
  `L` int DEFAULT NULL,
  `T` int DEFAULT NULL,
  `GF` int DEFAULT NULL,
  `GA` int DEFAULT NULL,
  `PIM` varchar(64)  DEFAULT NULL,
  `BenchMinor` varchar(64)  DEFAULT NULL,
  `PPG` varchar(64)  DEFAULT NULL,
  `PPC` varchar(64)  DEFAULT NULL,
  `SHA` varchar(64)  DEFAULT NULL,
  `PKG` varchar(64)  DEFAULT NULL,
  `PKC` varchar(64)  DEFAULT NULL,
  `SHF` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`year`,`tmID`)
);

CREATE TABLE `teamssc` (
  `year` int NOT NULL,
  `lgID` varchar(64)  DEFAULT NULL,
  `tmID` varchar(64)  NOT NULL,
  `G` int DEFAULT NULL,
  `W` int DEFAULT NULL,
  `L` int DEFAULT NULL,
  `T` int DEFAULT NULL,
  `GF` int DEFAULT NULL,
  `GA` int DEFAULT NULL,
  `PIM` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`year`,`tmID`)
);

CREATE TABLE `teamvsteam` (
  `year` int NOT NULL,
  `lgID` varchar(64)  DEFAULT NULL,
  `tmID` varchar(64)  NOT NULL,
  `oppID` varchar(64)  NOT NULL,
  `W` int DEFAULT NULL,
  `L` int DEFAULT NULL,
  `T` int DEFAULT NULL,
  `OTL` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`year`,`tmID`,`oppID`)
);


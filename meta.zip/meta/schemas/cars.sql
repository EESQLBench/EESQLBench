CREATE TABLE `country` (
  `origin` int NOT NULL,
  `country` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`origin`)
);

CREATE TABLE `data` (
  `ID` int NOT NULL,
  `mpg` double DEFAULT NULL,
  `cylinders` int DEFAULT NULL,
  `displacement` double DEFAULT NULL,
  `horsepower` int DEFAULT NULL,
  `weight` int DEFAULT NULL,
  `acceleration` double DEFAULT NULL,
  `model` int DEFAULT NULL,
  `car_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`ID`)
);

CREATE TABLE `price` (
  `ID` int NOT NULL,
  `price` double DEFAULT NULL,
  PRIMARY KEY (`ID`)
);

CREATE TABLE `production` (
  `ID` int NOT NULL,
  `model_year` int NOT NULL,
  `country` int DEFAULT NULL,
  PRIMARY KEY (`ID`,`model_year`),
  KEY `fk_production_country` (`country`)
);


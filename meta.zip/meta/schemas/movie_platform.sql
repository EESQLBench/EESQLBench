CREATE TABLE `lists` (
  `user_id` int NOT NULL,
  `list_id` int NOT NULL,
  `list_title` varchar(256)  DEFAULT NULL,
  `list_movie_number` int DEFAULT NULL,
  `list_update_timestamp_utc` datetime DEFAULT NULL,
  `list_creation_timestamp_utc` datetime DEFAULT NULL,
  `list_followers` int DEFAULT NULL,
  `list_url` varchar(256)  DEFAULT NULL,
  `list_comments` int DEFAULT NULL,
  `list_description` text ,
  `list_cover_image_url` varchar(128)  DEFAULT NULL,
  `list_first_image_url` varchar(128)  DEFAULT NULL,
  `list_second_image_url` varchar(128)  DEFAULT NULL,
  `list_third_image_url` varchar(128)  DEFAULT NULL,
  PRIMARY KEY (`list_id`),
  KEY `fk_lists_user_id` (`user_id`)
);

CREATE TABLE `lists_users` (
  `user_id` int NOT NULL,
  `list_id` int NOT NULL,
  `list_update_date_utc` date DEFAULT NULL,
  `list_creation_date_utc` date DEFAULT NULL,
  `user_trialist` tinyint(1) DEFAULT '0',
  `user_subscriber` tinyint(1) DEFAULT '0',
  `user_avatar_image_url` varchar(128)  DEFAULT NULL,
  `user_cover_image_url` varchar(128)  DEFAULT NULL,
  `user_eligible_for_trial` tinyint(1) DEFAULT '0',
  `user_has_payment_method` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`user_id`,`list_id`)
);

CREATE TABLE `movies` (
  `movie_id` int NOT NULL,
  `movie_title` varchar(256)  DEFAULT NULL,
  `movie_release_year` int DEFAULT NULL,
  `movie_url` varchar(256)  DEFAULT NULL,
  `movie_title_language` varchar(64)  DEFAULT NULL,
  `movie_popularity` int DEFAULT NULL,
  `movie_image_url` varchar(128)  DEFAULT NULL,
  `director_id` varchar(256)  DEFAULT NULL,
  `director_name` varchar(256)  DEFAULT NULL,
  `director_url` varchar(256)  DEFAULT NULL,
  PRIMARY KEY (`movie_id`)
);

CREATE TABLE `ratings` (
  `movie_id` int DEFAULT NULL,
  `rating_id` varchar(16)  DEFAULT NULL,
  `rating_url` varchar(256)  DEFAULT NULL,
  `rating_score` int DEFAULT NULL,
  `rating_timestamp_utc` datetime DEFAULT NULL,
  `critic` text ,
  `critic_likes` int DEFAULT NULL,
  `critic_comments` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `user_trialist` tinyint(1) DEFAULT '0',
  `user_subscriber` tinyint(1) DEFAULT '0',
  `user_eligible_for_trial` tinyint(1) DEFAULT '0',
  `user_has_payment_method` tinyint(1) DEFAULT '0',
  KEY `fk_ratings_movie_id` (`movie_id`),
  KEY `fk_ratings_user_id` (`user_id`)
);

CREATE TABLE `ratings_users` (
  `user_id` int NOT NULL,
  `rating_date_utc` date DEFAULT NULL,
  `user_trialist` tinyint(1) DEFAULT '0',
  `user_subscriber` tinyint(1) DEFAULT '0',
  `user_avatar_image_url` varchar(128)  DEFAULT NULL,
  `user_cover_image_url` varchar(128)  DEFAULT NULL,
  `user_eligible_for_trial` tinyint(1) DEFAULT '0',
  `user_has_payment_method` tinyint(1) DEFAULT '0',
  KEY `fk_ratings_users_user_id` (`user_id`)
);


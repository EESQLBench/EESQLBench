CREATE TABLE `country` (
  `CountryCode` varchar(64)  NOT NULL,
  `ShortName` varchar(64)  DEFAULT NULL,
  `TableName` varchar(64)  DEFAULT NULL,
  `LongName` varchar(128)  DEFAULT NULL,
  `Alpha2Code` varchar(64)  DEFAULT NULL,
  `CurrencyUnit` varchar(64)  DEFAULT NULL,
  `SpecialNotes` varchar(256)  DEFAULT NULL,
  `Region` varchar(64)  DEFAULT NULL,
  `IncomeGroup` varchar(64)  DEFAULT NULL,
  `Wb2Code` varchar(64)  DEFAULT NULL,
  `NationalAccountsBaseYear` varchar(128)  DEFAULT NULL,
  `NationalAccountsReferenceYear` varchar(64)  DEFAULT NULL,
  `SnaPriceValuation` varchar(64)  DEFAULT NULL,
  `LendingCategory` varchar(64)  DEFAULT NULL,
  `OtherGroups` varchar(64)  DEFAULT NULL,
  `SystemOfNationalAccounts` varchar(64)  DEFAULT NULL,
  `AlternativeConversionFactor` varchar(64)  DEFAULT NULL,
  `PppSurveyYear` varchar(64)  DEFAULT NULL,
  `BalanceOfPaymentsManualInUse` varchar(64)  DEFAULT NULL,
  `ExternalDebtReportingStatus` varchar(64)  DEFAULT NULL,
  `SystemOfTrade` varchar(64)  DEFAULT NULL,
  `GovernmentAccountingConcept` varchar(64)  DEFAULT NULL,
  `ImfDataDisseminationStandard` varchar(64)  DEFAULT NULL,
  `LatestPopulationCensus` varchar(64)  DEFAULT NULL,
  `LatestHouseholdSurvey` varchar(128)  DEFAULT NULL,
  `SourceOfMostRecentIncomeAndExpenditureData` varchar(128)  DEFAULT NULL,
  `VitalRegistrationComplete` varchar(64)  DEFAULT NULL,
  `LatestAgriculturalCensus` varchar(64)  DEFAULT NULL,
  `LatestIndustrialData` int DEFAULT NULL,
  `LatestTradeData` int DEFAULT NULL,
  `LatestWaterWithdrawalData` int DEFAULT NULL,
  PRIMARY KEY (`CountryCode`)
);

CREATE TABLE `countrynotes` (
  `Countrycode` varchar(64)  NOT NULL,
  `Seriescode` varchar(64)  NOT NULL,
  `Description` varchar(256)  DEFAULT NULL,
  PRIMARY KEY (`Countrycode`,`Seriescode`),
  KEY `fk_CountryNotes_Seriescode` (`Seriescode`)
);

CREATE TABLE `footnotes` (
  `Countrycode` varchar(64)  NOT NULL,
  `Seriescode` varchar(64)  NOT NULL,
  `Year` varchar(64)  NOT NULL,
  `Description` varchar(256)  DEFAULT NULL,
  PRIMARY KEY (`Countrycode`,`Seriescode`,`Year`),
  KEY `fk_Footnotes_Seriescode` (`Seriescode`)
);

CREATE TABLE `indicators` (
  `CountryName` varchar(64)  DEFAULT NULL,
  `CountryCode` varchar(64)  NOT NULL,
  `IndicatorName` varchar(256)  DEFAULT NULL,
  `IndicatorCode` varchar(64)  NOT NULL,
  `Year` int NOT NULL,
  `Value` bigint DEFAULT NULL,
  PRIMARY KEY (`CountryCode`,`IndicatorCode`,`Year`)
);

CREATE TABLE `series` (
  `SeriesCode` varchar(64)  NOT NULL,
  `Topic` varchar(128)  DEFAULT NULL,
  `IndicatorName` varchar(256)  DEFAULT NULL,
  `ShortDefinition` varchar(256)  DEFAULT NULL,
  `LongDefinition` varchar(256)  DEFAULT NULL,
  `UnitOfMeasure` varchar(64)  DEFAULT NULL,
  `Periodicity` varchar(64)  DEFAULT NULL,
  `BasePeriod` varchar(64)  DEFAULT NULL,
  `OtherNotes` int DEFAULT NULL,
  `AggregationMethod` varchar(64)  DEFAULT NULL,
  `LimitationsAndExceptions` varchar(256)  DEFAULT NULL,
  `NotesFromOriginalSource` varchar(256)  DEFAULT NULL,
  `GeneralComments` varchar(256)  DEFAULT NULL,
  `Source` varchar(256)  DEFAULT NULL,
  `StatisticalConceptAndMethodology` varchar(256)  DEFAULT NULL,
  `DevelopmentRelevance` varchar(256)  DEFAULT NULL,
  `RelatedSourceLinks` varchar(128)  DEFAULT NULL,
  `OtherWebLinks` int DEFAULT NULL,
  `RelatedIndicators` int DEFAULT NULL,
  `LicenseType` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`SeriesCode`)
);

CREATE TABLE `seriesnotes` (
  `Seriescode` varchar(64)  NOT NULL,
  `Year` varchar(64)  NOT NULL,
  `Description` varchar(256)  DEFAULT NULL,
  PRIMARY KEY (`Seriescode`,`Year`)
);


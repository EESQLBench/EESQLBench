CREATE TABLE `generalinfo` (
  `id_restaurant` int NOT NULL,
  `label` varchar(64)  DEFAULT NULL,
  `food_type` varchar(64)  DEFAULT NULL,
  `city` varchar(64)  DEFAULT NULL,
  `review` double DEFAULT NULL,
  PRIMARY KEY (`id_restaurant`),
  KEY `fk_generalinfo_city` (`city`)
);

CREATE TABLE `geographic` (
  `city` varchar(64)  NOT NULL,
  `county` varchar(64)  DEFAULT NULL,
  `region` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`city`)
);

CREATE TABLE `location` (
  `id_restaurant` int NOT NULL,
  `street_num` int DEFAULT NULL,
  `street_name` varchar(64)  DEFAULT NULL,
  `city` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id_restaurant`),
  KEY `fk_location_city` (`city`)
);


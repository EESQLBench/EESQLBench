CREATE TABLE `country` (
  `id` int NOT NULL,
  `country_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `ranking_criteria` (
  `id` int NOT NULL,
  `ranking_system_id` int DEFAULT NULL,
  `criteria_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_ranking_criteria_ranking_system_id` (`ranking_system_id`)
);

CREATE TABLE `ranking_system` (
  `id` int NOT NULL,
  `system_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `university` (
  `id` int NOT NULL,
  `country_id` int DEFAULT NULL,
  `university_name` varchar(128)  DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_university_country_id` (`country_id`)
);

CREATE TABLE `university_ranking_year` (
  `university_id` int DEFAULT NULL,
  `ranking_criteria_id` int DEFAULT NULL,
  `year` int DEFAULT NULL,
  `score` int DEFAULT NULL,
  KEY `fk_university_ranking_year_ranking_criteria_id` (`ranking_criteria_id`),
  KEY `fk_university_ranking_year_university_id` (`university_id`)
);

CREATE TABLE `university_year` (
  `university_id` int DEFAULT NULL,
  `year` int DEFAULT NULL,
  `num_students` int DEFAULT NULL,
  `student_staff_ratio` double DEFAULT NULL,
  `pct_international_students` int DEFAULT NULL,
  `pct_female_students` int DEFAULT NULL,
  KEY `fk_university_year_university_id` (`university_id`)
);


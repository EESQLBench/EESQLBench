CREATE TABLE `chapters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Act` int NOT NULL,
  `Scene` int NOT NULL,
  `Description` varchar(128)  NOT NULL,
  `work_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_chapters_work_id` (`work_id`)
);

CREATE TABLE `characters` (
  `id` int NOT NULL AUTO_INCREMENT,
  `CharName` varchar(64)  NOT NULL,
  `Abbrev` varchar(64)  NOT NULL,
  `Description` varchar(128)  NOT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `paragraphs` (
  `id` int NOT NULL AUTO_INCREMENT,
  `ParagraphNum` int NOT NULL,
  `PlainText` varchar(4096)  NOT NULL,
  `character_id` int NOT NULL,
  `chapter_id` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `fk_paragraphs_character_id` (`character_id`),
  KEY `fk_paragraphs_chapter_id` (`chapter_id`)
);

CREATE TABLE `works` (
  `id` int NOT NULL AUTO_INCREMENT,
  `Title` varchar(64)  NOT NULL,
  `LongTitle` varchar(64)  NOT NULL,
  `DATE` int NOT NULL,
  `GenreType` varchar(64)  NOT NULL,
  PRIMARY KEY (`id`)
);


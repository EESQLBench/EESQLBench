CREATE TABLE `actor` (
  `ActorID` int NOT NULL,
  `Name` varchar(64)  DEFAULT NULL,
  `DATE of Birth` date DEFAULT NULL,
  `Birth City` text ,
  `Birth Country` text ,
  `Height (Inches)` int DEFAULT NULL,
  `Biography` varchar(4096)  DEFAULT NULL,
  `Gender` varchar(64)  DEFAULT NULL,
  `Ethnicity` varchar(64)  DEFAULT NULL,
  `NetWorth` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`ActorID`)
);

CREATE TABLE `characters` (
  `MovieID` int NOT NULL,
  `ActorID` int NOT NULL,
  `Character Name` text ,
  `creditOrder` int DEFAULT NULL,
  `pay` varchar(64)  DEFAULT NULL,
  `screentime` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`MovieID`,`ActorID`),
  KEY `fk_characters_ActorID` (`ActorID`)
);

CREATE TABLE `movie` (
  `MovieID` int NOT NULL,
  `Title` varchar(128)  DEFAULT NULL,
  `MPAA Rating` text ,
  `Budget` int DEFAULT NULL,
  `Gross` int DEFAULT NULL,
  `Release DATE` text ,
  `Genre` varchar(64)  DEFAULT NULL,
  `Runtime` int DEFAULT NULL,
  `Rating` double DEFAULT NULL,
  `Rating Count` int DEFAULT NULL,
  `Summary` varchar(512)  DEFAULT NULL,
  PRIMARY KEY (`MovieID`)
);


CREATE TABLE `address` (
  `address_id` int NOT NULL,
  `street_number` varchar(64)  DEFAULT NULL,
  `street_name` varchar(64)  DEFAULT NULL,
  `city` varchar(64)  DEFAULT NULL,
  `country_id` int DEFAULT NULL,
  PRIMARY KEY (`address_id`),
  KEY `fk_address_country_id` (`country_id`)
);

CREATE TABLE `address_status` (
  `status_id` int NOT NULL,
  `address_status` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`status_id`)
);

CREATE TABLE `author` (
  `author_id` int NOT NULL,
  `author_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`author_id`)
);

CREATE TABLE `book` (
  `book_id` int NOT NULL,
  `title` varchar(256)  DEFAULT NULL,
  `isbn13` varchar(64)  DEFAULT NULL,
  `language_id` int DEFAULT NULL,
  `num_pages` int DEFAULT NULL,
  `publication_date` date DEFAULT NULL,
  `publisher_id` int DEFAULT NULL,
  PRIMARY KEY (`book_id`),
  KEY `fk_book_language_id` (`language_id`),
  KEY `fk_book_publisher_id` (`publisher_id`)
);

CREATE TABLE `book_author` (
  `book_id` int NOT NULL,
  `author_id` int NOT NULL,
  PRIMARY KEY (`book_id`,`author_id`),
  KEY `fk_book_author_author_id` (`author_id`)
);

CREATE TABLE `book_language` (
  `language_id` int NOT NULL,
  `language_code` varchar(64)  DEFAULT NULL,
  `language_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`language_id`)
);

CREATE TABLE `country` (
  `country_id` int NOT NULL,
  `country_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`country_id`)
);

CREATE TABLE `cust_order` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `order_date` datetime DEFAULT NULL,
  `customer_id` int NOT NULL,
  `shipping_method_id` int NOT NULL,
  `dest_address_id` int NOT NULL,
  PRIMARY KEY (`order_id`),
  KEY `fk_cust_order_customer_id` (`customer_id`),
  KEY `fk_cust_order_shipping_method_id` (`shipping_method_id`),
  KEY `fk_cust_order_dest_address_id` (`dest_address_id`)
);

CREATE TABLE `customer` (
  `customer_id` int NOT NULL,
  `first_name` varchar(64)  DEFAULT NULL,
  `last_name` varchar(64)  DEFAULT NULL,
  `email` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`customer_id`)
);

CREATE TABLE `customer_address` (
  `customer_id` int NOT NULL,
  `address_id` int NOT NULL,
  `status_id` int DEFAULT NULL,
  PRIMARY KEY (`customer_id`,`address_id`),
  KEY `fk_customer_address_address_id` (`address_id`)
);

CREATE TABLE `order_history` (
  `history_id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `status_id` int NOT NULL,
  `status_date` datetime DEFAULT NULL,
  PRIMARY KEY (`history_id`),
  KEY `fk_order_history_order_id` (`order_id`),
  KEY `fk_order_history_status_id` (`status_id`)
);

CREATE TABLE `order_line` (
  `line_id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `book_id` int NOT NULL,
  `price` double DEFAULT NULL,
  PRIMARY KEY (`line_id`),
  KEY `fk_order_line_order_id` (`order_id`),
  KEY `fk_order_line_book_id` (`book_id`)
);

CREATE TABLE `order_status` (
  `status_id` int NOT NULL,
  `status_value` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`status_id`)
);

CREATE TABLE `publisher` (
  `publisher_id` int NOT NULL,
  `publisher_name` varchar(128)  DEFAULT NULL,
  PRIMARY KEY (`publisher_id`)
);

CREATE TABLE `shipping_method` (
  `method_id` int NOT NULL,
  `method_name` varchar(64)  DEFAULT NULL,
  `cost` double DEFAULT NULL,
  PRIMARY KEY (`method_id`)
);


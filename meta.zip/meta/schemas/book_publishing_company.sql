CREATE TABLE `authors` (
  `au_id` varchar(64)  NOT NULL,
  `au_lname` varchar(64)  NOT NULL,
  `au_fname` varchar(64)  NOT NULL,
  `phone` varchar(64)  NOT NULL,
  `address` varchar(64)  DEFAULT NULL,
  `city` varchar(64)  DEFAULT NULL,
  `state` varchar(64)  DEFAULT NULL,
  `zip` varchar(64)  DEFAULT NULL,
  `contract` varchar(64)  NOT NULL,
  PRIMARY KEY (`au_id`)
);

CREATE TABLE `discounts` (
  `discounttype` varchar(64)  NOT NULL,
  `stor_id` varchar(64)  DEFAULT NULL,
  `lowqty` int DEFAULT NULL,
  `highqty` int DEFAULT NULL,
  `discount` double NOT NULL,
  KEY `fk_discounts_stor_id` (`stor_id`)
);

CREATE TABLE `employee` (
  `emp_id` varchar(64)  NOT NULL,
  `fname` varchar(64)  NOT NULL,
  `minit` varchar(64)  DEFAULT NULL,
  `lname` varchar(64)  NOT NULL,
  `job_id` int NOT NULL,
  `job_lvl` int DEFAULT NULL,
  `pub_id` varchar(64)  NOT NULL,
  `hire_date` datetime NOT NULL,
  PRIMARY KEY (`emp_id`),
  KEY `fk_employee_job_id` (`job_id`),
  KEY `fk_employee_pub_id` (`pub_id`)
);

CREATE TABLE `jobs` (
  `job_id` int NOT NULL,
  `job_desc` varchar(64)  NOT NULL,
  `min_lvl` int NOT NULL,
  `max_lvl` int NOT NULL,
  PRIMARY KEY (`job_id`)
);

CREATE TABLE `pub_info` (
  `pub_id` varchar(64)  NOT NULL,
  `logo` blob,
  `pr_info` longtext ,
  PRIMARY KEY (`pub_id`)
);

CREATE TABLE `publishers` (
  `pub_id` varchar(64)  NOT NULL,
  `pub_name` varchar(64)  DEFAULT NULL,
  `city` varchar(64)  DEFAULT NULL,
  `state` varchar(64)  DEFAULT NULL,
  `country` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`pub_id`)
);

CREATE TABLE `roysched` (
  `title_id` varchar(64)  NOT NULL,
  `lorange` int DEFAULT NULL,
  `hirange` int DEFAULT NULL,
  `royalty` int DEFAULT NULL,
  KEY `fk_roysched_title_id` (`title_id`)
);

CREATE TABLE `sales` (
  `stor_id` varchar(64)  NOT NULL,
  `ord_num` varchar(64)  NOT NULL,
  `ord_date` datetime NOT NULL,
  `qty` int NOT NULL,
  `payterms` varchar(64)  NOT NULL,
  `title_id` varchar(64)  NOT NULL,
  PRIMARY KEY (`stor_id`,`ord_num`,`title_id`),
  KEY `fk_sales_title_id` (`title_id`)
);

CREATE TABLE `stores` (
  `stor_id` varchar(64)  NOT NULL,
  `stor_name` varchar(64)  DEFAULT NULL,
  `stor_address` varchar(64)  DEFAULT NULL,
  `city` varchar(64)  DEFAULT NULL,
  `state` varchar(64)  DEFAULT NULL,
  `zip` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`stor_id`)
);

CREATE TABLE `titleauthor` (
  `au_id` varchar(64)  NOT NULL,
  `title_id` varchar(64)  NOT NULL,
  `au_ord` int DEFAULT NULL,
  `royaltyper` int DEFAULT NULL,
  PRIMARY KEY (`au_id`,`title_id`),
  KEY `fk_titleauthor_title_id` (`title_id`)
);

CREATE TABLE `titles` (
  `title_id` varchar(64)  NOT NULL,
  `title` varchar(64)  NOT NULL,
  `type` varchar(64)  NOT NULL,
  `pub_id` varchar(64)  DEFAULT NULL,
  `price` double DEFAULT NULL,
  `advance` double DEFAULT NULL,
  `royalty` int DEFAULT NULL,
  `ytd_sales` int DEFAULT NULL,
  `notes` varchar(256)  DEFAULT NULL,
  `pubdate` datetime NOT NULL,
  PRIMARY KEY (`title_id`),
  KEY `fk_titles_pub_id` (`pub_id`)
);


CREATE TABLE `circuits` (
  `circuitId` int NOT NULL AUTO_INCREMENT,
  `circuitRef` varchar(64)  NOT NULL DEFAULT '',
  `name` varchar(64)  NOT NULL DEFAULT '',
  `location` varchar(64)  DEFAULT NULL,
  `country` varchar(64)  DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `lng` double DEFAULT NULL,
  `alt` int DEFAULT NULL,
  `url` varchar(128)  NOT NULL DEFAULT '',
  PRIMARY KEY (`circuitId`),
  UNIQUE KEY `url` (`url`)
);

CREATE TABLE `constructorresults` (
  `constructorResultsId` int NOT NULL AUTO_INCREMENT,
  `raceId` int NOT NULL DEFAULT '0',
  `constructorId` int NOT NULL DEFAULT '0',
  `points` double DEFAULT NULL,
  `status` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`constructorResultsId`),
  KEY `fk_constructorResults_raceId` (`raceId`),
  KEY `fk_constructorResults_constructorId` (`constructorId`)
);

CREATE TABLE `constructors` (
  `constructorId` int NOT NULL AUTO_INCREMENT,
  `constructorRef` varchar(64)  NOT NULL DEFAULT '',
  `name` varchar(64)  NOT NULL DEFAULT '',
  `nationality` varchar(64)  DEFAULT NULL,
  `url` varchar(128)  NOT NULL DEFAULT '',
  PRIMARY KEY (`constructorId`),
  UNIQUE KEY `name` (`name`)
);

CREATE TABLE `constructorstandings` (
  `constructorStandingsId` int NOT NULL AUTO_INCREMENT,
  `raceId` int NOT NULL DEFAULT '0',
  `constructorId` int NOT NULL DEFAULT '0',
  `points` double NOT NULL DEFAULT '0',
  `position` int DEFAULT NULL,
  `positionText` varchar(64)  DEFAULT NULL,
  `wins` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`constructorStandingsId`),
  KEY `fk_constructorStandings_raceId` (`raceId`),
  KEY `fk_constructorStandings_constructorId` (`constructorId`)
);

CREATE TABLE `drivers` (
  `driverId` int NOT NULL AUTO_INCREMENT,
  `driverRef` varchar(64)  NOT NULL DEFAULT '',
  `number` int DEFAULT NULL,
  `code` varchar(64)  DEFAULT NULL,
  `forename` varchar(64)  NOT NULL DEFAULT '',
  `surname` varchar(64)  NOT NULL DEFAULT '',
  `dob` date DEFAULT NULL,
  `nationality` varchar(64)  DEFAULT NULL,
  `url` varchar(128)  NOT NULL DEFAULT '',
  PRIMARY KEY (`driverId`),
  UNIQUE KEY `url` (`url`)
);

CREATE TABLE `driverstandings` (
  `driverStandingsId` int NOT NULL AUTO_INCREMENT,
  `raceId` int NOT NULL DEFAULT '0',
  `driverId` int NOT NULL DEFAULT '0',
  `points` double NOT NULL DEFAULT '0',
  `position` int DEFAULT NULL,
  `positionText` varchar(64)  DEFAULT NULL,
  `wins` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`driverStandingsId`),
  KEY `fk_driverStandings_raceId` (`raceId`),
  KEY `fk_driverStandings_driverId` (`driverId`)
);

CREATE TABLE `laptimes` (
  `raceId` int NOT NULL,
  `driverId` int NOT NULL,
  `lap` int NOT NULL,
  `position` int DEFAULT NULL,
  `time` varchar(64)  DEFAULT NULL,
  `milliseconds` int DEFAULT NULL,
  PRIMARY KEY (`raceId`,`driverId`,`lap`),
  KEY `fk_lapTimes_driverId` (`driverId`)
);

CREATE TABLE `pitstops` (
  `raceId` int NOT NULL,
  `driverId` int NOT NULL,
  `stop` int NOT NULL,
  `lap` int NOT NULL,
  `time` varchar(64)  NOT NULL,
  `duration` varchar(64)  DEFAULT NULL,
  `milliseconds` int DEFAULT NULL,
  PRIMARY KEY (`raceId`,`driverId`,`stop`),
  KEY `fk_pitStops_driverId` (`driverId`)
);

CREATE TABLE `qualifying` (
  `qualifyId` int NOT NULL AUTO_INCREMENT,
  `raceId` int NOT NULL DEFAULT '0',
  `driverId` int NOT NULL DEFAULT '0',
  `constructorId` int NOT NULL DEFAULT '0',
  `number` int NOT NULL DEFAULT '0',
  `position` int DEFAULT NULL,
  `q1` varchar(64)  DEFAULT NULL,
  `q2` varchar(64)  DEFAULT NULL,
  `q3` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`qualifyId`),
  KEY `fk_qualifying_raceId` (`raceId`),
  KEY `fk_qualifying_driverId` (`driverId`),
  KEY `fk_qualifying_constructorId` (`constructorId`)
);

CREATE TABLE `races` (
  `raceId` int NOT NULL AUTO_INCREMENT,
  `year` int NOT NULL DEFAULT '0',
  `round` int NOT NULL DEFAULT '0',
  `circuitId` int NOT NULL DEFAULT '0',
  `name` varchar(64)  NOT NULL DEFAULT '',
  `DATE` date NOT NULL DEFAULT '1900-01-01',
  `time` varchar(64)  DEFAULT NULL,
  `url` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`raceId`),
  UNIQUE KEY `url` (`url`),
  KEY `fk_races_year` (`year`),
  KEY `fk_races_circuitId` (`circuitId`)
);

CREATE TABLE `results` (
  `resultId` int NOT NULL AUTO_INCREMENT,
  `raceId` int NOT NULL DEFAULT '0',
  `driverId` int NOT NULL DEFAULT '0',
  `constructorId` int NOT NULL DEFAULT '0',
  `number` int DEFAULT NULL,
  `grid` int NOT NULL DEFAULT '0',
  `position` int DEFAULT NULL,
  `positionText` varchar(64)  NOT NULL DEFAULT '',
  `positionOrder` int NOT NULL DEFAULT '0',
  `points` double NOT NULL DEFAULT '0',
  `laps` int NOT NULL DEFAULT '0',
  `time` varchar(64)  DEFAULT NULL,
  `milliseconds` int DEFAULT NULL,
  `fastestLap` int DEFAULT NULL,
  `rank` int DEFAULT '0',
  `fastestLapTime` varchar(64)  DEFAULT NULL,
  `fastestLapSpeed` varchar(64)  DEFAULT NULL,
  `statusId` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`resultId`),
  KEY `fk_results_raceId` (`raceId`),
  KEY `fk_results_driverId` (`driverId`),
  KEY `fk_results_constructorId` (`constructorId`),
  KEY `fk_results_statusId` (`statusId`)
);

CREATE TABLE `seasons` (
  `year` int NOT NULL DEFAULT '0',
  `url` varchar(128)  NOT NULL DEFAULT '',
  PRIMARY KEY (`year`),
  UNIQUE KEY `url` (`url`)
);

CREATE TABLE `status` (
  `statusId` int NOT NULL AUTO_INCREMENT,
  `status` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`statusId`)
);


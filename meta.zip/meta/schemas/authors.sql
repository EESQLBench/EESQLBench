CREATE TABLE `author` (
  `Id` int NOT NULL,
  `Name` varchar(64)  DEFAULT NULL,
  `Affiliation` varchar(128)  DEFAULT NULL,
  PRIMARY KEY (`Id`)
);

CREATE TABLE `conference` (
  `Id` int NOT NULL,
  `ShortName` varchar(64)  DEFAULT NULL,
  `FullName` varchar(128)  DEFAULT NULL,
  `HomePage` varchar(128)  DEFAULT NULL,
  PRIMARY KEY (`Id`)
);

CREATE TABLE `journal` (
  `Id` int NOT NULL,
  `ShortName` varchar(64)  DEFAULT NULL,
  `FullName` varchar(128)  DEFAULT NULL,
  `HomePage` varchar(128)  DEFAULT NULL,
  PRIMARY KEY (`Id`)
);

CREATE TABLE `paper` (
  `Id` int NOT NULL,
  `Title` varchar(128)  DEFAULT NULL,
  `Year` int DEFAULT NULL,
  `ConferenceId` int DEFAULT NULL,
  `JournalId` int DEFAULT NULL,
  `Keyword` varchar(128)  DEFAULT NULL,
  PRIMARY KEY (`Id`),
  KEY `fk_Paper_ConferenceId` (`ConferenceId`),
  KEY `fk_Paper_JournalId` (`JournalId`)
);

CREATE TABLE `paperauthor` (
  `PaperId` int DEFAULT NULL,
  `AuthorId` int DEFAULT NULL,
  `Name` varchar(128)  DEFAULT NULL,
  `Affiliation` varchar(128)  DEFAULT NULL,
  KEY `fk_PaperAuthor_PaperId` (`PaperId`),
  KEY `fk_PaperAuthor_AuthorId` (`AuthorId`)
);


CREATE TABLE `ingredient` (
  `ingredient_id` int NOT NULL,
  `category` varchar(64)  DEFAULT NULL,
  `name` varchar(64)  DEFAULT NULL,
  `plural` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`ingredient_id`)
);

CREATE TABLE `nutrition` (
  `recipe_id` int NOT NULL,
  `protein` double DEFAULT NULL,
  `carbo` double DEFAULT NULL,
  `alcohol` double DEFAULT NULL,
  `total_fat` double DEFAULT NULL,
  `sat_fat` double DEFAULT NULL,
  `cholestrl` double DEFAULT NULL,
  `sodium` double DEFAULT NULL,
  `iron` double DEFAULT NULL,
  `vitamin_c` double DEFAULT NULL,
  `vitamin_a` double DEFAULT NULL,
  `fiber` double DEFAULT NULL,
  `pcnt_cal_carb` double DEFAULT NULL,
  `pcnt_cal_fat` double DEFAULT NULL,
  `pcnt_cal_prot` double DEFAULT NULL,
  `calories` double DEFAULT NULL,
  PRIMARY KEY (`recipe_id`)
);

CREATE TABLE `quantity` (
  `quantity_id` int NOT NULL,
  `recipe_id` int DEFAULT NULL,
  `ingredient_id` int DEFAULT NULL,
  `max_qty` double DEFAULT NULL,
  `min_qty` double DEFAULT NULL,
  `unit` varchar(64)  DEFAULT NULL,
  `preparation` varchar(64)  DEFAULT NULL,
  `optional` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`quantity_id`),
  KEY `fk_Quantity_ingredient_id` (`ingredient_id`),
  KEY `fk_Quantity_nutrition_id` (`recipe_id`)
);

CREATE TABLE `recipe` (
  `recipe_id` int NOT NULL,
  `title` varchar(64)  DEFAULT NULL,
  `subtitle` varchar(64)  DEFAULT NULL,
  `servings` int DEFAULT NULL,
  `yield_unit` varchar(64)  DEFAULT NULL,
  `prep_min` int DEFAULT NULL,
  `cook_min` int DEFAULT NULL,
  `stnd_min` int DEFAULT NULL,
  `source` varchar(64)  DEFAULT NULL,
  `intro` varchar(256)  DEFAULT NULL,
  `directions` varchar(2048)  DEFAULT NULL,
  PRIMARY KEY (`recipe_id`)
);


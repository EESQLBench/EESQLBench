CREATE TABLE `customer` (
  `c_custkey` int NOT NULL,
  `c_mktsegment` text ,
  `c_nationkey` int DEFAULT NULL,
  `c_name` text ,
  `c_address` text ,
  `c_phone` text ,
  `c_acctbal` double DEFAULT NULL,
  `c_comment` text ,
  PRIMARY KEY (`c_custkey`),
  KEY `c_nationkey` (`c_nationkey`)
);

CREATE TABLE `lineitem` (
  `l_shipdate` date DEFAULT NULL,
  `l_orderkey` int NOT NULL,
  `l_discount` double NOT NULL,
  `l_extendedprice` double NOT NULL,
  `l_suppkey` int NOT NULL,
  `l_quantity` int NOT NULL,
  `l_returnflag` varchar(64)  DEFAULT NULL,
  `l_partkey` int NOT NULL,
  `l_linestatus` varchar(64)  DEFAULT NULL,
  `l_tax` double NOT NULL,
  `l_commitdate` date DEFAULT NULL,
  `l_receiptdate` date DEFAULT NULL,
  `l_shipmode` varchar(64)  DEFAULT NULL,
  `l_linenumber` int NOT NULL,
  `l_shipinstruct` varchar(64)  DEFAULT NULL,
  `l_comment` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`l_orderkey`,`l_linenumber`)
);

CREATE TABLE `nation` (
  `n_nationkey` int NOT NULL,
  `n_name` varchar(64)  DEFAULT NULL,
  `n_regionkey` int DEFAULT NULL,
  `n_comment` varchar(128)  DEFAULT NULL,
  PRIMARY KEY (`n_nationkey`),
  KEY `fk_nation_n_regionkey` (`n_regionkey`)
);

CREATE TABLE `orders` (
  `o_orderdate` date DEFAULT NULL,
  `o_orderkey` int NOT NULL,
  `o_custkey` int NOT NULL,
  `o_orderpriority` varchar(64)  DEFAULT NULL,
  `o_shippriority` int DEFAULT NULL,
  `o_clerk` varchar(64)  DEFAULT NULL,
  `o_orderstatus` varchar(64)  DEFAULT NULL,
  `o_totalprice` double DEFAULT NULL,
  `o_comment` varchar(128)  DEFAULT NULL,
  PRIMARY KEY (`o_orderkey`),
  KEY `fk_orders_o_custkey` (`o_custkey`)
);

CREATE TABLE `part` (
  `p_partkey` int NOT NULL,
  `p_type` varchar(64)  DEFAULT NULL,
  `p_size` int DEFAULT NULL,
  `p_brand` varchar(64)  DEFAULT NULL,
  `p_name` varchar(64)  DEFAULT NULL,
  `p_container` varchar(64)  DEFAULT NULL,
  `p_mfgr` varchar(64)  DEFAULT NULL,
  `p_retailprice` double DEFAULT NULL,
  `p_comment` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`p_partkey`)
);

CREATE TABLE `partsupp` (
  `ps_partkey` int NOT NULL,
  `ps_suppkey` int NOT NULL,
  `ps_supplycost` double NOT NULL,
  `ps_availqty` int DEFAULT NULL,
  `ps_comment` varchar(256)  DEFAULT NULL,
  PRIMARY KEY (`ps_partkey`,`ps_suppkey`),
  KEY `fk_partsupp_ps_suppkey` (`ps_suppkey`)
);

CREATE TABLE `region` (
  `r_regionkey` int NOT NULL,
  `r_name` varchar(64)  DEFAULT NULL,
  `r_comment` varchar(128)  DEFAULT NULL,
  PRIMARY KEY (`r_regionkey`)
);

CREATE TABLE `supplier` (
  `s_suppkey` int NOT NULL,
  `s_nationkey` int DEFAULT NULL,
  `s_comment` varchar(128)  DEFAULT NULL,
  `s_name` varchar(64)  DEFAULT NULL,
  `s_address` varchar(64)  DEFAULT NULL,
  `s_phone` varchar(64)  DEFAULT NULL,
  `s_acctbal` double DEFAULT NULL,
  PRIMARY KEY (`s_suppkey`),
  KEY `fk_supplier_s_nationkey` (`s_nationkey`)
);


CREATE TABLE `categories` (
  `CategoryID` int NOT NULL AUTO_INCREMENT,
  `CategoryName` varchar(64)  DEFAULT NULL,
  `Description` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`CategoryID`)
);

CREATE TABLE `customers` (
  `CustomerID` int NOT NULL AUTO_INCREMENT,
  `CustomerName` varchar(64)  DEFAULT NULL,
  `ContactName` varchar(64)  DEFAULT NULL,
  `Address` varchar(64)  DEFAULT NULL,
  `City` varchar(64)  DEFAULT NULL,
  `PostalCode` varchar(64)  DEFAULT NULL,
  `Country` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`CustomerID`)
);

CREATE TABLE `employees` (
  `EmployeeID` int NOT NULL AUTO_INCREMENT,
  `LastName` varchar(64)  DEFAULT NULL,
  `FirstName` varchar(64)  DEFAULT NULL,
  `BirthDate` date DEFAULT NULL,
  `Photo` varchar(64)  DEFAULT NULL,
  `Notes` varchar(512)  DEFAULT NULL,
  PRIMARY KEY (`EmployeeID`)
);

CREATE TABLE `orderdetails` (
  `OrderDetailID` int NOT NULL AUTO_INCREMENT,
  `OrderID` int DEFAULT NULL,
  `ProductID` int DEFAULT NULL,
  `Quantity` int DEFAULT NULL,
  PRIMARY KEY (`OrderDetailID`),
  KEY `fk_OrderDetails_OrderID` (`OrderID`),
  KEY `fk_OrderDetails_ProductID` (`ProductID`)
);

CREATE TABLE `orders` (
  `OrderID` int NOT NULL AUTO_INCREMENT,
  `CustomerID` int DEFAULT NULL,
  `EmployeeID` int DEFAULT NULL,
  `OrderDate` datetime DEFAULT NULL,
  `ShipperID` int DEFAULT NULL,
  PRIMARY KEY (`OrderID`),
  KEY `fk_Orders_EmployeeID` (`EmployeeID`),
  KEY `fk_Orders_CustomerID` (`CustomerID`),
  KEY `fk_Orders_ShipperID` (`ShipperID`)
);

CREATE TABLE `products` (
  `ProductID` int NOT NULL AUTO_INCREMENT,
  `ProductName` varchar(64)  DEFAULT NULL,
  `SupplierID` int DEFAULT NULL,
  `CategoryID` int DEFAULT NULL,
  `Unit` varchar(64)  DEFAULT NULL,
  `Price` double DEFAULT '0',
  PRIMARY KEY (`ProductID`),
  KEY `fk_Products_CategoryID` (`CategoryID`),
  KEY `fk_Products_SupplierID` (`SupplierID`)
);

CREATE TABLE `shippers` (
  `ShipperID` int NOT NULL AUTO_INCREMENT,
  `ShipperName` varchar(64)  DEFAULT NULL,
  `Phone` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`ShipperID`)
);

CREATE TABLE `suppliers` (
  `SupplierID` int NOT NULL AUTO_INCREMENT,
  `SupplierName` varchar(64)  DEFAULT NULL,
  `ContactName` varchar(64)  DEFAULT NULL,
  `Address` varchar(64)  DEFAULT NULL,
  `City` varchar(64)  DEFAULT NULL,
  `PostalCode` varchar(64)  DEFAULT NULL,
  `Country` varchar(64)  DEFAULT NULL,
  `Phone` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`SupplierID`)
);


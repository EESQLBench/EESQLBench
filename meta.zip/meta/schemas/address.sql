CREATE TABLE `alias` (
  `zip_code` int NOT NULL,
  `alias` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`zip_code`)
);

CREATE TABLE `area_code` (
  `zip_code` int NOT NULL,
  `area_code` int NOT NULL,
  PRIMARY KEY (`zip_code`,`area_code`)
);

CREATE TABLE `avoid` (
  `zip_code` int NOT NULL,
  `bad_alias` varchar(64)  NOT NULL,
  PRIMARY KEY (`zip_code`,`bad_alias`)
);

CREATE TABLE `cbsa` (
  `CBSA` int NOT NULL,
  `CBSA_name` varchar(64)  DEFAULT NULL,
  `CBSA_type` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`CBSA`)
);

CREATE TABLE `congress` (
  `cognress_rep_id` varchar(64)  NOT NULL,
  `first_name` varchar(64)  DEFAULT NULL,
  `last_name` varchar(64)  DEFAULT NULL,
  `CID` varchar(64)  DEFAULT NULL,
  `party` varchar(64)  DEFAULT NULL,
  `state` varchar(64)  DEFAULT NULL,
  `abbreviation` varchar(64)  DEFAULT NULL,
  `House` varchar(64)  DEFAULT NULL,
  `District` int DEFAULT NULL,
  `land_area` double DEFAULT NULL,
  PRIMARY KEY (`cognress_rep_id`),
  KEY `fk_congress_abbreviation` (`abbreviation`)
);

CREATE TABLE `country` (
  `zip_code` int NOT NULL,
  `county` varchar(64)  NOT NULL,
  `state` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`zip_code`,`county`),
  KEY `fk_country_state` (`state`)
);

CREATE TABLE `state` (
  `abbreviation` varchar(64)  NOT NULL,
  `name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`abbreviation`)
);

CREATE TABLE `zip_congress` (
  `zip_code` int NOT NULL,
  `district` varchar(64)  NOT NULL,
  PRIMARY KEY (`zip_code`,`district`),
  KEY `fk_zip_congress_district` (`district`)
);

CREATE TABLE `zip_data` (
  `zip_code` int NOT NULL,
  `city` varchar(64)  DEFAULT NULL,
  `state` varchar(64)  DEFAULT NULL,
  `multi_county` varchar(64)  DEFAULT NULL,
  `type` varchar(64)  DEFAULT NULL,
  `organization` varchar(128)  DEFAULT NULL,
  `time_zone` varchar(64)  DEFAULT NULL,
  `daylight_savings` varchar(64)  DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `elevation` int DEFAULT NULL,
  `state_fips` int DEFAULT NULL,
  `county_fips` int DEFAULT NULL,
  `region` varchar(64)  DEFAULT NULL,
  `division` varchar(64)  DEFAULT NULL,
  `population_2020` int DEFAULT NULL,
  `population_2010` int DEFAULT NULL,
  `households` int DEFAULT NULL,
  `avg_house_value` int DEFAULT NULL,
  `avg_income_per_household` int DEFAULT NULL,
  `persons_per_household` double DEFAULT NULL,
  `white_population` int DEFAULT NULL,
  `black_population` int DEFAULT NULL,
  `hispanic_population` int DEFAULT NULL,
  `asian_population` int DEFAULT NULL,
  `american_indian_population` int DEFAULT NULL,
  `hawaiian_population` int DEFAULT NULL,
  `other_population` int DEFAULT NULL,
  `male_population` int DEFAULT NULL,
  `female_population` int DEFAULT NULL,
  `median_age` double DEFAULT NULL,
  `male_median_age` double DEFAULT NULL,
  `female_median_age` double DEFAULT NULL,
  `residential_mailboxes` int DEFAULT NULL,
  `business_mailboxes` int DEFAULT NULL,
  `total_delivery_receptacles` int DEFAULT NULL,
  `businesses` int DEFAULT NULL,
  `1st_quarter_payroll` bigint DEFAULT NULL,
  `annual_payroll` bigint DEFAULT NULL,
  `employees` int DEFAULT NULL,
  `water_area` double DEFAULT NULL,
  `land_area` double DEFAULT NULL,
  `single_family_delivery_units` int DEFAULT NULL,
  `multi_family_delivery_units` int DEFAULT NULL,
  `total_beneficiaries` int DEFAULT NULL,
  `retired_workers` int DEFAULT NULL,
  `disabled_workers` int DEFAULT NULL,
  `parents_and_widowed` int DEFAULT NULL,
  `spouses` int DEFAULT NULL,
  `children` int DEFAULT NULL,
  `over_65` int DEFAULT NULL,
  `monthly_benefits_all` int DEFAULT NULL,
  `monthly_benefits_retired_workers` int DEFAULT NULL,
  `monthly_benefits_widowed` int DEFAULT NULL,
  `CBSA` int DEFAULT NULL,
  PRIMARY KEY (`zip_code`),
  KEY `fk_zip_data_state` (`state`),
  KEY `fk_zip_data_CBSA` (`CBSA`)
);


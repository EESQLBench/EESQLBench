CREATE TABLE `dish` (
  `id` int NOT NULL,
  `name` varchar(2048)  DEFAULT NULL,
  `description` varchar(256)  DEFAULT NULL,
  `menus_appeared` int DEFAULT NULL,
  `times_appeared` int DEFAULT NULL,
  `first_appeared` int DEFAULT NULL,
  `last_appeared` int DEFAULT NULL,
  `lowest_price` double DEFAULT NULL,
  `highest_price` double DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `menu` (
  `id` int NOT NULL,
  `name` varchar(128)  DEFAULT NULL,
  `sponsor` varchar(128)  DEFAULT NULL,
  `event` varchar(256)  DEFAULT NULL,
  `venue` varchar(64)  DEFAULT NULL,
  `place` varchar(128)  DEFAULT NULL,
  `physical_description` varchar(128)  DEFAULT NULL,
  `occasion` varchar(128)  DEFAULT NULL,
  `notes` varchar(256)  DEFAULT NULL,
  `call_number` varchar(64)  DEFAULT NULL,
  `keywords` varchar(256)  DEFAULT NULL,
  `language` varchar(256)  DEFAULT NULL,
  `DATE` date DEFAULT NULL,
  `location` varchar(128)  DEFAULT NULL,
  `location_type` varchar(256)  DEFAULT NULL,
  `currency` varchar(64)  DEFAULT NULL,
  `currency_symbol` varchar(64)  DEFAULT NULL,
  `status` varchar(64)  DEFAULT NULL,
  `page_count` int DEFAULT NULL,
  `dish_count` int DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `menuitem` (
  `id` int NOT NULL,
  `menu_page_id` int DEFAULT NULL,
  `price` double DEFAULT NULL,
  `high_price` double DEFAULT NULL,
  `dish_id` int DEFAULT NULL,
  `created_at` varchar(64)  DEFAULT NULL,
  `updated_at` varchar(64)  DEFAULT NULL,
  `xpos` double DEFAULT NULL,
  `ypos` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_MenuItem_dish_id` (`dish_id`),
  KEY `fk_MenuItem_menu_page_id` (`menu_page_id`)
);

CREATE TABLE `menupage` (
  `id` int NOT NULL,
  `menu_id` int DEFAULT NULL,
  `page_number` int DEFAULT NULL,
  `image_id` double DEFAULT NULL,
  `full_height` int DEFAULT NULL,
  `full_width` int DEFAULT NULL,
  `uuid` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_MenuPage_menu_id` (`menu_id`)
);


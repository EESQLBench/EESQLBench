CREATE TABLE `attributes` (
  `attribute_id` int NOT NULL,
  `attribute_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`attribute_id`)
);

CREATE TABLE `business` (
  `business_id` int NOT NULL,
  `active` varchar(64)  DEFAULT NULL,
  `city` varchar(64)  DEFAULT NULL,
  `state` varchar(64)  DEFAULT NULL,
  `stars` double DEFAULT NULL,
  `review_count` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`business_id`)
);

CREATE TABLE `business_attributes` (
  `attribute_id` int NOT NULL,
  `business_id` int NOT NULL,
  `attribute_value` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`attribute_id`,`business_id`),
  KEY `fk_Business_Attributes_business_id` (`business_id`)
);

CREATE TABLE `business_categories` (
  `business_id` int NOT NULL,
  `category_id` int NOT NULL,
  PRIMARY KEY (`business_id`,`category_id`),
  KEY `fk_Business_Categories_category_id` (`category_id`)
);

CREATE TABLE `business_hours` (
  `business_id` int NOT NULL,
  `day_id` int NOT NULL,
  `opening_time` varchar(64)  DEFAULT NULL,
  `closing_time` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`business_id`,`day_id`),
  KEY `fk_Business_Hours_day_id` (`day_id`)
);

CREATE TABLE `categories` (
  `category_id` int NOT NULL,
  `category_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`category_id`)
);

CREATE TABLE `checkins` (
  `business_id` int NOT NULL,
  `day_id` int NOT NULL,
  `label_time_0` varchar(64)  DEFAULT NULL,
  `label_time_1` varchar(64)  DEFAULT NULL,
  `label_time_2` varchar(64)  DEFAULT NULL,
  `label_time_3` varchar(64)  DEFAULT NULL,
  `label_time_4` varchar(64)  DEFAULT NULL,
  `label_time_5` varchar(64)  DEFAULT NULL,
  `label_time_6` varchar(64)  DEFAULT NULL,
  `label_time_7` varchar(64)  DEFAULT NULL,
  `label_time_8` varchar(64)  DEFAULT NULL,
  `label_time_9` varchar(64)  DEFAULT NULL,
  `label_time_10` varchar(64)  DEFAULT NULL,
  `label_time_11` varchar(64)  DEFAULT NULL,
  `label_time_12` varchar(64)  DEFAULT NULL,
  `label_time_13` varchar(64)  DEFAULT NULL,
  `label_time_14` varchar(64)  DEFAULT NULL,
  `label_time_15` varchar(64)  DEFAULT NULL,
  `label_time_16` varchar(64)  DEFAULT NULL,
  `label_time_17` varchar(64)  DEFAULT NULL,
  `label_time_18` varchar(64)  DEFAULT NULL,
  `label_time_19` varchar(64)  DEFAULT NULL,
  `label_time_20` varchar(64)  DEFAULT NULL,
  `label_time_21` varchar(64)  DEFAULT NULL,
  `label_time_22` varchar(64)  DEFAULT NULL,
  `label_time_23` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`business_id`,`day_id`),
  KEY `fk_Checkins_day_id` (`day_id`)
);

CREATE TABLE `compliments` (
  `compliment_id` int NOT NULL,
  `compliment_type` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`compliment_id`)
);

CREATE TABLE `days` (
  `day_id` int NOT NULL,
  `day_of_week` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`day_id`)
);

CREATE TABLE `elite` (
  `user_id` int NOT NULL,
  `year_id` int NOT NULL,
  PRIMARY KEY (`user_id`,`year_id`),
  KEY `fk_Elite_year_id` (`year_id`)
);

CREATE TABLE `reviews` (
  `business_id` int NOT NULL,
  `user_id` int NOT NULL,
  `review_stars` int DEFAULT NULL,
  `review_votes_funny` varchar(64)  DEFAULT NULL,
  `review_votes_useful` varchar(64)  DEFAULT NULL,
  `review_votes_cool` varchar(64)  DEFAULT NULL,
  `review_length` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`business_id`,`user_id`),
  KEY `fk_Reviews_user_id` (`user_id`)
);

CREATE TABLE `tips` (
  `business_id` int NOT NULL,
  `user_id` int NOT NULL,
  `likes` int DEFAULT NULL,
  `tip_length` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`business_id`,`user_id`),
  KEY `fk_Tips_user_id` (`user_id`)
);

CREATE TABLE `users` (
  `user_id` int NOT NULL,
  `user_yelping_since_year` int DEFAULT NULL,
  `user_average_stars` varchar(64)  DEFAULT NULL,
  `user_votes_funny` varchar(64)  DEFAULT NULL,
  `user_votes_useful` varchar(64)  DEFAULT NULL,
  `user_votes_cool` varchar(64)  DEFAULT NULL,
  `user_review_count` varchar(64)  DEFAULT NULL,
  `user_fans` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`user_id`)
);

CREATE TABLE `users_compliments` (
  `compliment_id` int NOT NULL,
  `user_id` int NOT NULL,
  `number_of_compliments` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`compliment_id`,`user_id`),
  KEY `fk_Users_Compliments_user_id` (`user_id`)
);

CREATE TABLE `years` (
  `year_id` int NOT NULL,
  `actual_year` int DEFAULT NULL,
  PRIMARY KEY (`year_id`)
);


CREATE TABLE `method` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(256)  DEFAULT NULL,
  `FullComment` text ,
  `Summary` text ,
  `ApiCalls` varchar(256)  DEFAULT NULL,
  `CommentIsXml` int DEFAULT NULL,
  `SampledAt` bigint DEFAULT NULL,
  `SolutionId` int DEFAULT NULL,
  `Lang` varchar(64)  DEFAULT NULL,
  `NameTokenized` varchar(256)  DEFAULT NULL,
  PRIMARY KEY (`Id`)
);

CREATE TABLE `methodparameter` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `MethodId` varchar(64)  DEFAULT NULL,
  `Type` varchar(256)  DEFAULT NULL,
  `Name` varchar(256)  DEFAULT NULL,
  PRIMARY KEY (`Id`)
);

CREATE TABLE `repo` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `Url` text ,
  `Stars` int DEFAULT NULL,
  `Forks` int DEFAULT NULL,
  `Watchers` int DEFAULT NULL,
  `ProcessedTime` bigint DEFAULT NULL,
  PRIMARY KEY (`Id`)
);

CREATE TABLE `solution` (
  `Id` int NOT NULL AUTO_INCREMENT,
  `RepoId` int DEFAULT NULL,
  `Path` text ,
  `ProcessedTime` bigint DEFAULT NULL,
  `WasCompiled` int DEFAULT NULL,
  PRIMARY KEY (`Id`)
);


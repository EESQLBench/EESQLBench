CREATE TABLE `customers` (
  `CustomerID` int NOT NULL,
  `First` varchar(64)  DEFAULT NULL,
  `Last` varchar(64)  DEFAULT NULL,
  `StreetAddress` varchar(64)  DEFAULT NULL,
  `City` varchar(64)  DEFAULT NULL,
  `State` varchar(64)  DEFAULT NULL,
  `ZipCode` int DEFAULT NULL,
  `Email` varchar(64)  DEFAULT NULL,
  `PhoneNumber` varchar(64)  DEFAULT NULL,
  `FirstPurchaseDate` date DEFAULT NULL,
  `SubscribedToEmailList` varchar(64)  DEFAULT NULL,
  `Gender` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`CustomerID`)
);

CREATE TABLE `geolocation` (
  `LocationID` int NOT NULL,
  `Latitude` double DEFAULT NULL,
  `Longitude` double DEFAULT NULL,
  PRIMARY KEY (`LocationID`)
);

CREATE TABLE `location` (
  `LocationID` int NOT NULL,
  `LocationName` varchar(64)  DEFAULT NULL,
  `StreetAddress` varchar(64)  DEFAULT NULL,
  `City` varchar(64)  DEFAULT NULL,
  `State` varchar(64)  DEFAULT NULL,
  `ZipCode` int DEFAULT NULL,
  PRIMARY KEY (`LocationID`)
);

CREATE TABLE `rootbeer` (
  `RootBeerID` int NOT NULL,
  `BrandID` int DEFAULT NULL,
  `ContainerType` varchar(64)  DEFAULT NULL,
  `LocationID` int DEFAULT NULL,
  `PurchaseDate` date DEFAULT NULL,
  PRIMARY KEY (`RootBeerID`),
  KEY `fk_rootbeer_LocationID` (`LocationID`),
  KEY `fk_rootbeer_BrandID` (`BrandID`)
);

CREATE TABLE `rootbeerbrand` (
  `BrandID` int NOT NULL,
  `BrandName` varchar(64)  DEFAULT NULL,
  `FirstBrewedYear` int DEFAULT NULL,
  `BreweryName` varchar(64)  DEFAULT NULL,
  `City` varchar(64)  DEFAULT NULL,
  `State` varchar(64)  DEFAULT NULL,
  `Country` varchar(64)  DEFAULT NULL,
  `Description` text ,
  `CaneSugar` varchar(64)  DEFAULT NULL,
  `CornSyrup` varchar(64)  DEFAULT NULL,
  `Honey` varchar(64)  DEFAULT NULL,
  `ArtificialSweetener` varchar(64)  DEFAULT NULL,
  `Caffeinated` varchar(64)  DEFAULT NULL,
  `Alcoholic` varchar(64)  DEFAULT NULL,
  `AvailableInCans` varchar(64)  DEFAULT NULL,
  `AvailableInBottles` varchar(64)  DEFAULT NULL,
  `AvailableInKegs` varchar(64)  DEFAULT NULL,
  `Website` varchar(128)  DEFAULT NULL,
  `FacebookPage` varchar(128)  DEFAULT NULL,
  `Twitter` varchar(64)  DEFAULT NULL,
  `WholesaleCost` double DEFAULT NULL,
  `CurrentRetailPrice` double DEFAULT NULL,
  PRIMARY KEY (`BrandID`)
);

CREATE TABLE `rootbeerreview` (
  `CustomerID` int NOT NULL,
  `BrandID` int NOT NULL,
  `StarRating` int DEFAULT NULL,
  `ReviewDate` date DEFAULT NULL,
  `Review` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`CustomerID`,`BrandID`),
  KEY `fk_rootbeerreview_BrandID` (`BrandID`)
);

CREATE TABLE `transaction` (
  `TransactionID` int NOT NULL,
  `CreditCardNumber` bigint DEFAULT NULL,
  `CustomerID` int DEFAULT NULL,
  `TransactionDate` date DEFAULT NULL,
  `CreditCardType` varchar(64)  DEFAULT NULL,
  `LocationID` int DEFAULT NULL,
  `RootBeerID` int DEFAULT NULL,
  `PurchasePrice` double DEFAULT NULL,
  PRIMARY KEY (`TransactionID`),
  KEY `fk_transaction_CustomerID` (`CustomerID`),
  KEY `fk_transaction_LocationID` (`LocationID`),
  KEY `fk_transaction_RootBeerID` (`RootBeerID`)
);


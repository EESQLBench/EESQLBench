CREATE TABLE `bool` (
  `name` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`name`)
);

CREATE TABLE `disabled` (
  `name` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`name`)
);

CREATE TABLE `enlist` (
  `name` varchar(64)  NOT NULL,
  `organ` varchar(64)  NOT NULL,
  KEY `fk_enlist_name` (`name`)
);

CREATE TABLE `filed_for_bankrupcy` (
  `name` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`name`)
);

CREATE TABLE `longest_absense_from_school` (
  `name` varchar(64)  NOT NULL DEFAULT '',
  `month` int DEFAULT '0',
  PRIMARY KEY (`name`)
);

CREATE TABLE `male` (
  `name` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`name`)
);

CREATE TABLE `no_payment_due` (
  `name` varchar(64)  NOT NULL DEFAULT '',
  `bool` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`name`),
  KEY `fk_no_payment_due_bool` (`bool`)
);

CREATE TABLE `person` (
  `name` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`name`)
);

CREATE TABLE `unemployed` (
  `name` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`name`)
);


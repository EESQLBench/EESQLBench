CREATE TABLE `ball_by_ball` (
  `Match_Id` int NOT NULL,
  `Over_Id` int NOT NULL,
  `Ball_Id` int NOT NULL,
  `Innings_No` int NOT NULL,
  `Team_Batting` int DEFAULT NULL,
  `Team_Bowling` int DEFAULT NULL,
  `Striker_Batting_Position` int DEFAULT NULL,
  `Striker` int DEFAULT NULL,
  `Non_Striker` int DEFAULT NULL,
  `Bowler` int DEFAULT NULL,
  PRIMARY KEY (`Match_Id`,`Over_Id`,`Ball_Id`,`Innings_No`)
);

CREATE TABLE `batsman_scored` (
  `Match_Id` int NOT NULL,
  `Over_Id` int NOT NULL,
  `Ball_Id` int NOT NULL,
  `Runs_Scored` int DEFAULT NULL,
  `Innings_No` int NOT NULL,
  PRIMARY KEY (`Match_Id`,`Over_Id`,`Ball_Id`,`Innings_No`)
);

CREATE TABLE `batting_style` (
  `Batting_Id` int NOT NULL,
  `Batting_hand` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`Batting_Id`)
);

CREATE TABLE `bowling_style` (
  `Bowling_Id` int NOT NULL,
  `Bowling_skill` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`Bowling_Id`)
);

CREATE TABLE `city` (
  `City_Id` int NOT NULL,
  `City_Name` varchar(64)  DEFAULT NULL,
  `Country_id` int DEFAULT NULL,
  PRIMARY KEY (`City_Id`)
);

CREATE TABLE `country` (
  `Country_Id` int NOT NULL,
  `Country_Name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`Country_Id`)
);

CREATE TABLE `extra_runs` (
  `Match_Id` int NOT NULL,
  `Over_Id` int NOT NULL,
  `Ball_Id` int NOT NULL,
  `Extra_Type_Id` int DEFAULT NULL,
  `Extra_Runs` int DEFAULT NULL,
  `Innings_No` int NOT NULL,
  PRIMARY KEY (`Match_Id`,`Over_Id`,`Ball_Id`,`Innings_No`),
  KEY `fk_Extra_Runs_Extra_Type_Id` (`Extra_Type_Id`)
);

CREATE TABLE `extra_type` (
  `Extra_Id` int NOT NULL,
  `Extra_Name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`Extra_Id`)
);

CREATE TABLE `match` (
  `Match_Id` int NOT NULL,
  `Team_1` int DEFAULT NULL,
  `Team_2` int DEFAULT NULL,
  `Match_Date` date DEFAULT NULL,
  `Season_Id` int DEFAULT NULL,
  `Venue_Id` int DEFAULT NULL,
  `Toss_Winner` int DEFAULT NULL,
  `Toss_Decide` int DEFAULT NULL,
  `Win_Type` int DEFAULT NULL,
  `Win_Margin` int DEFAULT NULL,
  `Outcome_type` int DEFAULT NULL,
  `Match_Winner` int DEFAULT NULL,
  `Man_of_the_Match` int DEFAULT NULL,
  PRIMARY KEY (`Match_Id`),
  KEY `fk_Match_Team_1` (`Team_1`),
  KEY `fk_Match_Team_2` (`Team_2`),
  KEY `fk_Match_Season_Id` (`Season_Id`),
  KEY `fk_Match_Venue_Id` (`Venue_Id`),
  KEY `fk_Match_Toss_Winner` (`Toss_Winner`),
  KEY `fk_Match_Toss_Decide` (`Toss_Decide`),
  KEY `fk_Match_Win_Type` (`Win_Type`),
  KEY `fk_Match_Outcome_type` (`Outcome_type`),
  KEY `fk_Match_Match_Winner` (`Match_Winner`),
  KEY `fk_Match_Man_of_the_Match` (`Man_of_the_Match`)
);

CREATE TABLE `out_type` (
  `Out_Id` int NOT NULL,
  `Out_Name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`Out_Id`)
);

CREATE TABLE `outcome` (
  `Outcome_Id` int NOT NULL,
  `Outcome_Type` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`Outcome_Id`)
);

CREATE TABLE `player` (
  `Player_Id` int NOT NULL,
  `Player_Name` varchar(64)  DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `Batting_hand` int DEFAULT NULL,
  `Bowling_skill` int DEFAULT NULL,
  `Country_Name` int DEFAULT NULL,
  PRIMARY KEY (`Player_Id`),
  KEY `fk_Player_Batting_hand` (`Batting_hand`),
  KEY `fk_Player_Bowling_skill` (`Bowling_skill`),
  KEY `fk_Player_Country_Name` (`Country_Name`)
);

CREATE TABLE `player_match` (
  `Match_Id` int NOT NULL,
  `Player_Id` int NOT NULL,
  `Role_Id` int NOT NULL,
  `Team_Id` int DEFAULT NULL,
  PRIMARY KEY (`Match_Id`,`Player_Id`,`Role_Id`),
  KEY `fk_Player_Match_Player_Id` (`Player_Id`),
  KEY `fk_Player_Match_Team_Id` (`Team_Id`),
  KEY `fk_Player_Match_Role_Id` (`Role_Id`)
);

CREATE TABLE `rolee` (
  `Role_Id` int NOT NULL,
  `Role_Desc` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`Role_Id`)
);

CREATE TABLE `season` (
  `Season_Id` int NOT NULL,
  `Man_of_the_Series` int DEFAULT NULL,
  `Orange_Cap` int DEFAULT NULL,
  `Purple_Cap` int DEFAULT NULL,
  `Season_Year` int DEFAULT NULL,
  PRIMARY KEY (`Season_Id`)
);

CREATE TABLE `team` (
  `Team_Id` int NOT NULL,
  `Team_Name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`Team_Id`)
);

CREATE TABLE `toss_decision` (
  `Toss_Id` int NOT NULL,
  `Toss_Name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`Toss_Id`)
);

CREATE TABLE `umpire` (
  `Umpire_Id` int NOT NULL,
  `Umpire_Name` varchar(64)  DEFAULT NULL,
  `Umpire_Country` int DEFAULT NULL,
  PRIMARY KEY (`Umpire_Id`),
  KEY `fk_Umpire_Umpire_Country` (`Umpire_Country`)
);

CREATE TABLE `venue` (
  `Venue_Id` int NOT NULL,
  `Venue_Name` varchar(64)  DEFAULT NULL,
  `City_Id` int DEFAULT NULL,
  PRIMARY KEY (`Venue_Id`),
  KEY `fk_Venue_City_Id` (`City_Id`)
);

CREATE TABLE `wicket_taken` (
  `Match_Id` int NOT NULL,
  `Over_Id` int NOT NULL,
  `Ball_Id` int NOT NULL,
  `Player_Out` int DEFAULT NULL,
  `Kind_Out` int DEFAULT NULL,
  `Fielders` int DEFAULT NULL,
  `Innings_No` int NOT NULL,
  PRIMARY KEY (`Match_Id`,`Over_Id`,`Ball_Id`,`Innings_No`),
  KEY `fk_Wicket_Taken_Player_Out` (`Player_Out`),
  KEY `fk_Wicket_Taken_Kind_Out` (`Kind_Out`),
  KEY `fk_Wicket_Taken_Fielders` (`Fielders`)
);

CREATE TABLE `win_by` (
  `Win_Id` int NOT NULL,
  `Win_Type` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`Win_Id`)
);


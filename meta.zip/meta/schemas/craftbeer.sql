CREATE TABLE `beers` (
  `id` int NOT NULL,
  `brewery_id` int NOT NULL,
  `abv` double DEFAULT NULL,
  `ibu` double DEFAULT NULL,
  `name` varchar(64)  NOT NULL,
  `style` varchar(64)  DEFAULT NULL,
  `ounces` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_beers_brewery_id` (`brewery_id`)
);

CREATE TABLE `breweries` (
  `id` int NOT NULL,
  `name` varchar(64)  DEFAULT NULL,
  `city` varchar(64)  DEFAULT NULL,
  `state` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);


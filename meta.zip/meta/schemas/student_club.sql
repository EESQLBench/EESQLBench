CREATE TABLE `attendance` (
  `link_to_event` varchar(64)  NOT NULL,
  `link_to_member` varchar(64)  NOT NULL,
  PRIMARY KEY (`link_to_event`,`link_to_member`),
  KEY `fk_attendance_link_to_member` (`link_to_member`)
);

CREATE TABLE `budget` (
  `budget_id` varchar(64)  NOT NULL,
  `category` varchar(64)  DEFAULT NULL,
  `spent` double DEFAULT NULL,
  `remaining` double DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `event_status` varchar(64)  DEFAULT NULL,
  `link_to_event` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`budget_id`),
  KEY `fk_budget_link_to_event` (`link_to_event`)
);

CREATE TABLE `event` (
  `event_id` varchar(64)  NOT NULL,
  `event_name` varchar(64)  DEFAULT NULL,
  `event_date` varchar(64)  DEFAULT NULL,
  `type` varchar(64)  DEFAULT NULL,
  `notes` varchar(128)  DEFAULT NULL,
  `location` varchar(64)  DEFAULT NULL,
  `status` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`event_id`)
);

CREATE TABLE `expense` (
  `expense_id` varchar(64)  NOT NULL,
  `expense_description` varchar(64)  DEFAULT NULL,
  `expense_date` varchar(64)  DEFAULT NULL,
  `cost` double DEFAULT NULL,
  `approved` varchar(64)  DEFAULT NULL,
  `link_to_member` varchar(64)  DEFAULT NULL,
  `link_to_budget` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`expense_id`),
  KEY `fk_expense_link_to_budget` (`link_to_budget`),
  KEY `fk_expense_link_to_member` (`link_to_member`)
);

CREATE TABLE `income` (
  `income_id` varchar(64)  NOT NULL,
  `date_received` varchar(64)  DEFAULT NULL,
  `amount` int DEFAULT NULL,
  `source` varchar(64)  DEFAULT NULL,
  `notes` varchar(64)  DEFAULT NULL,
  `link_to_member` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`income_id`),
  KEY `fk_income_link_to_member` (`link_to_member`)
);

CREATE TABLE `major` (
  `major_id` varchar(64)  NOT NULL,
  `major_name` varchar(64)  DEFAULT NULL,
  `department` varchar(64)  DEFAULT NULL,
  `college` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`major_id`)
);

CREATE TABLE `member` (
  `member_id` varchar(64)  NOT NULL,
  `first_name` varchar(64)  DEFAULT NULL,
  `last_name` varchar(64)  DEFAULT NULL,
  `email` varchar(64)  DEFAULT NULL,
  `position` varchar(64)  DEFAULT NULL,
  `t_shirt_size` varchar(64)  DEFAULT NULL,
  `phone` varchar(64)  DEFAULT NULL,
  `zip` int DEFAULT NULL,
  `link_to_major` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`member_id`),
  KEY `fk_member_link_to_major` (`link_to_major`),
  KEY `fk_member_zip` (`zip`)
);

CREATE TABLE `zip_code` (
  `zip_code` int NOT NULL,
  `type` varchar(64)  DEFAULT NULL,
  `city` varchar(64)  DEFAULT NULL,
  `county` varchar(64)  DEFAULT NULL,
  `state` varchar(64)  DEFAULT NULL,
  `short_state` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`zip_code`)
);


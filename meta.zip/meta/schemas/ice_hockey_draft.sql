CREATE TABLE `height_info` (
  `height_id` int NOT NULL,
  `height_in_cm` int DEFAULT NULL,
  `height_in_inch` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`height_id`)
);

CREATE TABLE `playerinfo` (
  `ELITEID` int NOT NULL,
  `PlayerName` varchar(64)  DEFAULT NULL,
  `birthdate` varchar(64)  DEFAULT NULL,
  `birthyear` int DEFAULT NULL,
  `birthmonth` int DEFAULT NULL,
  `birthday` int DEFAULT NULL,
  `birthplace` varchar(64)  DEFAULT NULL,
  `nation` varchar(64)  DEFAULT NULL,
  `height` int DEFAULT NULL,
  `weight` int DEFAULT NULL,
  `position_info` varchar(64)  DEFAULT NULL,
  `shoots` varchar(64)  DEFAULT NULL,
  `draftyear` int DEFAULT NULL,
  `draftround` int DEFAULT NULL,
  `overall` int DEFAULT NULL,
  `overallby` varchar(64)  DEFAULT NULL,
  `CSS_rank` int DEFAULT NULL,
  `sum_7yr_GP` int DEFAULT NULL,
  `sum_7yr_TOI` int DEFAULT NULL,
  `GP_greater_than_0` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`ELITEID`),
  KEY `fk_PlayerInfo_height` (`height`),
  KEY `fk_PlayerInfo_weight` (`weight`)
);

CREATE TABLE `seasonstatus` (
  `ELITEID` int DEFAULT NULL,
  `SEASON` varchar(64)  DEFAULT NULL,
  `TEAM` varchar(64)  DEFAULT NULL,
  `LEAGUE` varchar(64)  DEFAULT NULL,
  `GAMETYPE` varchar(64)  DEFAULT NULL,
  `GP` int DEFAULT NULL,
  `G` int DEFAULT NULL,
  `A` int DEFAULT NULL,
  `P` int DEFAULT NULL,
  `PIM` int DEFAULT NULL,
  `PLUSMINUS` int DEFAULT NULL,
  KEY `fk_SeasonStatus_ELITEID` (`ELITEID`)
);

CREATE TABLE `weight_info` (
  `weight_id` int NOT NULL,
  `weight_in_kg` int DEFAULT NULL,
  `weight_in_lbs` int DEFAULT NULL,
  PRIMARY KEY (`weight_id`)
);


CREATE TABLE `customers` (
  `CustomerID` int NOT NULL,
  `Segment` varchar(64)  DEFAULT NULL,
  `Currency` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`CustomerID`),
  UNIQUE KEY `CustomerID` (`CustomerID`)
);

CREATE TABLE `gasstations` (
  `GasStationID` int NOT NULL,
  `ChainID` int DEFAULT NULL,
  `Country` varchar(64)  DEFAULT NULL,
  `Segment` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`GasStationID`),
  UNIQUE KEY `GasStationID` (`GasStationID`)
);

CREATE TABLE `products` (
  `ProductID` int NOT NULL,
  `Description` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`ProductID`),
  UNIQUE KEY `ProductID` (`ProductID`)
);

CREATE TABLE `transactions_1k` (
  `TransactionID` int NOT NULL AUTO_INCREMENT,
  `DATE` date DEFAULT NULL,
  `Time` varchar(64)  DEFAULT NULL,
  `CustomerID` int DEFAULT NULL,
  `CardID` int DEFAULT NULL,
  `GasStationID` int DEFAULT NULL,
  `ProductID` int DEFAULT NULL,
  `Amount` int DEFAULT NULL,
  `Price` double DEFAULT NULL,
  PRIMARY KEY (`TransactionID`)
);

CREATE TABLE `yearmonth` (
  `CustomerID` int NOT NULL,
  `DATE` varchar(64)  NOT NULL,
  `Consumption` double DEFAULT NULL,
  PRIMARY KEY (`DATE`,`CustomerID`),
  KEY `fk_yearmonth_CustomerID` (`CustomerID`)
);


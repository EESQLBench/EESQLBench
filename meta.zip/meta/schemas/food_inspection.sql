CREATE TABLE `businesses` (
  `business_id` int NOT NULL,
  `name` varchar(255)  NOT NULL,
  `address` varchar(255)  DEFAULT NULL,
  `city` varchar(100)  DEFAULT NULL,
  `postal_code` varchar(20)  DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `phone_number` bigint DEFAULT NULL,
  `tax_code` varchar(50)  DEFAULT NULL,
  `business_certificate` int NOT NULL,
  `application_date` date DEFAULT NULL,
  `owner_name` varchar(255)  NOT NULL,
  `owner_address` varchar(255)  DEFAULT NULL,
  `owner_city` varchar(100)  DEFAULT NULL,
  `owner_state` varchar(50)  DEFAULT NULL,
  `owner_zip` varchar(20)  DEFAULT NULL,
  PRIMARY KEY (`business_id`)
);

CREATE TABLE `inspections` (
  `business_id` int NOT NULL,
  `score` int DEFAULT NULL,
  `date` date NOT NULL,
  `type` varchar(100)  NOT NULL,
  KEY `fk_inspections_business` (`business_id`)) 
);

CREATE TABLE `violations` (
  `business_id` int NOT NULL,
  `date` date NOT NULL,
  `violation_type_id` varchar(100)  NOT NULL,
  `risk_category` varchar(100)  NOT NULL,
  `description` text  NOT NULL,
  KEY `fk_violations_business` (`business_id`) 
);


CREATE TABLE `customers` (
  `customerNumber` int NOT NULL,
  `customerName` varchar(64)  NOT NULL,
  `contactLastName` varchar(64)  NOT NULL,
  `contactFirstName` varchar(64)  NOT NULL,
  `phone` varchar(64)  NOT NULL,
  `addressLine1` varchar(64)  NOT NULL,
  `addressLine2` varchar(64)  DEFAULT NULL,
  `city` varchar(64)  NOT NULL,
  `state` varchar(64)  DEFAULT NULL,
  `postalCode` varchar(64)  DEFAULT NULL,
  `country` varchar(64)  NOT NULL,
  `salesRepEmployeeNumber` int DEFAULT NULL,
  `creditLimit` double DEFAULT NULL,
  PRIMARY KEY (`customerNumber`),
  KEY `fk_customers_salesRepEmployeeNumber` (`salesRepEmployeeNumber`)
);

CREATE TABLE `employees` (
  `employeeNumber` int NOT NULL,
  `lastName` varchar(64)  NOT NULL,
  `firstName` varchar(64)  NOT NULL,
  `extension` varchar(64)  NOT NULL,
  `email` varchar(64)  NOT NULL,
  `officeCode` varchar(64)  NOT NULL,
  `reportsTo` int DEFAULT NULL,
  `jobTitle` varchar(64)  NOT NULL,
  PRIMARY KEY (`employeeNumber`),
  KEY `fk_employees_officeCode` (`officeCode`)
);

CREATE TABLE `offices` (
  `officeCode` varchar(64)  NOT NULL,
  `city` varchar(64)  NOT NULL,
  `phone` varchar(64)  NOT NULL,
  `addressLine1` varchar(64)  NOT NULL,
  `addressLine2` varchar(64)  DEFAULT NULL,
  `state` varchar(64)  DEFAULT NULL,
  `country` varchar(64)  NOT NULL,
  `postalCode` varchar(64)  NOT NULL,
  `territory` varchar(64)  NOT NULL,
  PRIMARY KEY (`officeCode`)
);

CREATE TABLE `orderdetails` (
  `orderNumber` int NOT NULL,
  `productCode` varchar(64)  NOT NULL,
  `quantityOrdered` int NOT NULL,
  `priceEach` double NOT NULL,
  `orderLineNumber` int NOT NULL,
  PRIMARY KEY (`orderNumber`,`productCode`),
  KEY `fk_orderdetails_productCode` (`productCode`)
);

CREATE TABLE `orders` (
  `orderNumber` int NOT NULL,
  `orderDate` date NOT NULL,
  `requiredDate` date NOT NULL,
  `shippedDate` date DEFAULT NULL,
  `status` varchar(64)  NOT NULL,
  `comments` varchar(256)  DEFAULT NULL,
  `customerNumber` int NOT NULL,
  PRIMARY KEY (`orderNumber`),
  KEY `fk_orders_customerNumber` (`customerNumber`))
);

CREATE TABLE `payments` (
  `customerNumber` int NOT NULL,
  `checkNumber` varchar(64)  NOT NULL,
  `paymentDate` date NOT NULL,
  `amount` double NOT NULL,
  PRIMARY KEY (`customerNumber`,`checkNumber`)
);

CREATE TABLE `productlines` (
  `productLine` varchar(64)  NOT NULL,
  `textDescription` varchar(256)  DEFAULT NULL,
  `htmlDescription` varchar(256)  DEFAULT NULL,
  `image` blob,
  PRIMARY KEY (`productLine`)
);

CREATE TABLE `products` (
  `productCode` varchar(64)  NOT NULL,
  `productName` varchar(64)  NOT NULL,
  `productLine` varchar(64)  NOT NULL,
  `productScale` varchar(64)  NOT NULL,
  `productVendor` varchar(64)  NOT NULL,
  `productDescription` varchar(512)  NOT NULL,
  `quantityInStock` int NOT NULL,
  `buyPrice` double NOT NULL,
  `MSRP` double NOT NULL,
  PRIMARY KEY (`productCode`),
  KEY `fk_products_productLine` (`productLine`)
);


CREATE TABLE `relation` (
  `store_nbr` int NOT NULL,
  `station_nbr` int DEFAULT NULL,
  PRIMARY KEY (`store_nbr`),
  KEY `fk_relation_station_nbr` (`station_nbr`)
);

CREATE TABLE `sales_in_weather` (
  `DATE` date NOT NULL,
  `store_nbr` int NOT NULL,
  `item_nbr` int NOT NULL,
  `units` int DEFAULT NULL,
  PRIMARY KEY (`store_nbr`,`DATE`,`item_nbr`)
);

CREATE TABLE `weather` (
  `station_nbr` int NOT NULL,
  `DATE` date NOT NULL,
  `tmax` int DEFAULT NULL,
  `tmin` int DEFAULT NULL,
  `tavg` int DEFAULT NULL,
  `depart` int DEFAULT NULL,
  `dewpoint` int DEFAULT NULL,
  `wetbulb` int DEFAULT NULL,
  `heat` int DEFAULT NULL,
  `cool` int DEFAULT NULL,
  `sunrise` varchar(64)  DEFAULT NULL,
  `sunset` varchar(64)  DEFAULT NULL,
  `codesum` varchar(64)  DEFAULT NULL,
  `snowfall` double DEFAULT NULL,
  `preciptotal` double DEFAULT NULL,
  `stnpressure` double DEFAULT NULL,
  `sealevel` double DEFAULT NULL,
  `resultspeed` double DEFAULT NULL,
  `resultdir` int DEFAULT NULL,
  `avgspeed` double DEFAULT NULL,
  PRIMARY KEY (`station_nbr`,`DATE`)
);


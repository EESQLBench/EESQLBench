CREATE TABLE `city` (
  `id` int NOT NULL,
  `city_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `competitor_event` (
  `event_id` int DEFAULT NULL,
  `competitor_id` int DEFAULT NULL,
  `medal_id` int DEFAULT NULL,
  KEY `fk_competitor_event_competitor_id` (`competitor_id`),
  KEY `fk_competitor_event_event_id` (`event_id`),
  KEY `fk_competitor_event_medal_id` (`medal_id`)
);

CREATE TABLE `event` (
  `id` int NOT NULL,
  `sport_id` int DEFAULT NULL,
  `event_name` varchar(128)  DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_event_sport_id` (`sport_id`)
);

CREATE TABLE `games` (
  `id` int NOT NULL,
  `games_year` int DEFAULT NULL,
  `games_name` varchar(64)  DEFAULT NULL,
  `season` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `games_city` (
  `games_id` int DEFAULT NULL,
  `city_id` int DEFAULT NULL,
  KEY `fk_games_city_city_id` (`city_id`),
  KEY `fk_games_city_games_id` (`games_id`)
);

CREATE TABLE `games_competitor` (
  `id` int NOT NULL,
  `games_id` int DEFAULT NULL,
  `person_id` int DEFAULT NULL,
  `age` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_games_competitor_games_id` (`games_id`),
  KEY `fk_games_competitor_person_id` (`person_id`)
);

CREATE TABLE `medal` (
  `id` int NOT NULL,
  `medal_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `noc_region` (
  `id` int NOT NULL,
  `noc` varchar(64)  DEFAULT NULL,
  `region_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `person` (
  `id` int NOT NULL,
  `full_name` varchar(128)  DEFAULT NULL,
  `gender` varchar(64)  DEFAULT NULL,
  `height` int DEFAULT NULL,
  `weight` int DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `person_region` (
  `person_id` int DEFAULT NULL,
  `region_id` int DEFAULT NULL,
  KEY `fk_person_region_person_id` (`person_id`),
  KEY `fk_person_region_region_id` (`region_id`)
);

CREATE TABLE `sport` (
  `id` int NOT NULL,
  `sport_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);


CREATE TABLE `award` (
  `award_id` int NOT NULL,
  `organization` varchar(64)  DEFAULT NULL,
  `year` int DEFAULT NULL,
  `award_category` varchar(64)  DEFAULT NULL,
  `award` varchar(128)  DEFAULT NULL,
  `person` varchar(64)  DEFAULT NULL,
  `role` varchar(64)  DEFAULT NULL,
  `episode_id` varchar(64)  DEFAULT NULL,
  `season` varchar(256)  DEFAULT NULL,
  `song` varchar(256)  DEFAULT NULL,
  `result` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`award_id`),
  KEY `fk_Award_person` (`person`),
  KEY `fk_Award_episode_id` (`episode_id`)
);

CREATE TABLE `character_award` (
  `award_id` int DEFAULT NULL,
  `character` varchar(64)  DEFAULT NULL,
  KEY `fk_Character_Award_award_id` (`award_id`)
);

CREATE TABLE `credit` (
  `episode_id` varchar(64)  DEFAULT NULL,
  `category` varchar(64)  DEFAULT NULL,
  `person` varchar(64)  DEFAULT NULL,
  `role` varchar(64)  DEFAULT NULL,
  `credited` varchar(64)  DEFAULT NULL,
  KEY `fk_Credit_episode_id` (`episode_id`),
  KEY `fk_Credit_person` (`person`)
);

CREATE TABLE `episode` (
  `episode_id` varchar(64)  NOT NULL,
  `season` int DEFAULT NULL,
  `episode` int DEFAULT NULL,
  `number_in_series` int DEFAULT NULL,
  `title` varchar(64)  DEFAULT NULL,
  `summary` varchar(256)  DEFAULT NULL,
  `air_date` varchar(64)  DEFAULT NULL,
  `episode_image` varchar(128)  DEFAULT NULL,
  `rating` double DEFAULT NULL,
  `votes` int DEFAULT NULL,
  PRIMARY KEY (`episode_id`)
);

CREATE TABLE `keyword` (
  `episode_id` varchar(64)  NOT NULL,
  `keyword` varchar(64)  NOT NULL,
  PRIMARY KEY (`episode_id`,`keyword`)
);

CREATE TABLE `person` (
  `name` varchar(64)  NOT NULL,
  `birthdate` varchar(64)  DEFAULT NULL,
  `birth_name` varchar(64)  DEFAULT NULL,
  `birth_place` varchar(64)  DEFAULT NULL,
  `birth_region` varchar(64)  DEFAULT NULL,
  `birth_country` varchar(64)  DEFAULT NULL,
  `height_meters` double DEFAULT NULL,
  `nickname` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`name`)
);

CREATE TABLE `vote` (
  `episode_id` varchar(64)  DEFAULT NULL,
  `stars` int DEFAULT NULL,
  `votes` int DEFAULT NULL,
  `percent` double DEFAULT NULL,
  KEY `fk_Vote_episode_id` (`episode_id`)
);


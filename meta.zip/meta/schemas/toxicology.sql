CREATE TABLE `atom` (
  `atom_id` varchar(50) NOT NULL,
  `molecule_id` varchar(50) DEFAULT NULL,
  `element` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`atom_id`)
);

CREATE TABLE `bond` (
  `bond_id` varchar(50) NOT NULL,
  `molecule_id` varchar(50) DEFAULT NULL,
  `bond_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`bond_id`)
);

CREATE TABLE `connected` (
  `atom_id` varchar(50) NOT NULL,
  `atom_id2` varchar(50) NOT NULL,
  `bond_id` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`atom_id`,`atom_id2`),
  KEY `fk_conn_atom2` (`atom_id2`),
  KEY `fk_conn_bond` (`bond_id`)
);

CREATE TABLE `molecule` (
  `molecule_id` varchar(50) NOT NULL,
  `label` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`molecule_id`)
);


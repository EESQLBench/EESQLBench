CREATE TABLE `cites` (
  `cited_paper_id` varchar(64)  NOT NULL,
  `citing_paper_id` varchar(64)  NOT NULL,
  PRIMARY KEY (`cited_paper_id`,`citing_paper_id`)
);

CREATE TABLE `content` (
  `paper_id` varchar(64)  NOT NULL,
  `word_cited_id` varchar(64)  NOT NULL,
  PRIMARY KEY (`paper_id`,`word_cited_id`)
);

CREATE TABLE `paper` (
  `paper_id` varchar(64)  NOT NULL,
  `class_label` varchar(64)  NOT NULL,
  PRIMARY KEY (`paper_id`)
);


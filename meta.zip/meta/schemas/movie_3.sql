CREATE TABLE `actor` (
  `actor_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(64)  NOT NULL,
  `last_name` varchar(64)  NOT NULL,
  `last_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`actor_id`)
);

CREATE TABLE `address` (
  `address_id` int NOT NULL AUTO_INCREMENT,
  `address` varchar(64)  NOT NULL,
  `address2` varchar(256)  DEFAULT NULL,
  `district` varchar(64)  NOT NULL,
  `city_id` int NOT NULL,
  `postal_code` varchar(64)  DEFAULT NULL,
  `phone` varchar(64)  NOT NULL,
  `last_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`address_id`),
  KEY `fk_address_city_id` (`city_id`)
);

CREATE TABLE `category` (
  `category_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(64)  NOT NULL,
  `last_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`category_id`)
);

CREATE TABLE `city` (
  `city_id` int NOT NULL AUTO_INCREMENT,
  `city` varchar(64)  NOT NULL,
  `country_id` int NOT NULL,
  `last_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`city_id`),
  KEY `fk_city_country_id` (`country_id`)
);

CREATE TABLE `country` (
  `country_id` int NOT NULL AUTO_INCREMENT,
  `country` varchar(64)  NOT NULL,
  `last_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`country_id`)
);

CREATE TABLE `customer` (
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `store_id` int NOT NULL,
  `first_name` varchar(64)  NOT NULL,
  `last_name` varchar(64)  NOT NULL,
  `email` varchar(64)  DEFAULT NULL,
  `address_id` int NOT NULL,
  `active` int NOT NULL DEFAULT '1',
  `create_date` datetime NOT NULL,
  `last_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`customer_id`),
  KEY `fk_customer_store_id` (`store_id`),
  KEY `fk_customer_address_id` (`address_id`)
);

CREATE TABLE `film` (
  `film_id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(64)  NOT NULL,
  `description` varchar(256)  DEFAULT NULL,
  `release_year` varchar(64)  DEFAULT NULL,
  `language_id` int NOT NULL,
  `original_language_id` int DEFAULT NULL,
  `rental_duration` int NOT NULL DEFAULT '3',
  `rental_rate` double NOT NULL DEFAULT '4.99',
  `length` int DEFAULT NULL,
  `replacement_cost` double NOT NULL DEFAULT '19.99',
  `rating` varchar(64)  DEFAULT 'G',
  `special_features` varchar(64)  DEFAULT NULL,
  `last_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`film_id`),
  KEY `fk_film_language_id` (`language_id`),
  KEY `fk_film_original_language_id` (`original_language_id`)
);

CREATE TABLE `film_actor` (
  `actor_id` int NOT NULL,
  `film_id` int NOT NULL,
  `last_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`actor_id`,`film_id`),
  KEY `fk_film_actor_film_id` (`film_id`)
);

CREATE TABLE `film_category` (
  `film_id` int NOT NULL,
  `category_id` int NOT NULL,
  `last_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`film_id`,`category_id`),
  KEY `fk_film_category_category_id` (`category_id`)
);

CREATE TABLE `film_text` (
  `film_id` int NOT NULL,
  `title` varchar(64)  NOT NULL,
  `description` varchar(256)  DEFAULT NULL,
  PRIMARY KEY (`film_id`)
);

CREATE TABLE `inventory` (
  `inventory_id` int NOT NULL AUTO_INCREMENT,
  `film_id` int NOT NULL,
  `store_id` int NOT NULL,
  `last_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`inventory_id`),
  KEY `fk_inventory_film_id` (`film_id`),
  KEY `fk_inventory_store_id` (`store_id`)
);

CREATE TABLE `language` (
  `language_id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(64)  NOT NULL,
  `last_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`language_id`)
);

CREATE TABLE `payment` (
  `payment_id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `staff_id` int NOT NULL,
  `rental_id` int DEFAULT NULL,
  `amount` double NOT NULL,
  `payment_date` datetime NOT NULL,
  `last_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`payment_id`),
  KEY `fk_payment_customer_id` (`customer_id`),
  KEY `fk_payment_staff_id` (`staff_id`),
  KEY `fk_payment_rental_id` (`rental_id`)
);

CREATE TABLE `rental` (
  `rental_id` int NOT NULL AUTO_INCREMENT,
  `rental_date` datetime NOT NULL,
  `inventory_id` int NOT NULL,
  `customer_id` int NOT NULL,
  `return_date` datetime DEFAULT NULL,
  `staff_id` int NOT NULL,
  `last_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`rental_id`),
  UNIQUE KEY `uk_rental_date_inv_cust` (`rental_date`,`inventory_id`,`customer_id`),
  KEY `fk_rental_inventory_id` (`inventory_id`),
  KEY `fk_rental_customer_id` (`customer_id`),
  KEY `fk_rental_staff_id` (`staff_id`)
);

CREATE TABLE `staff` (
  `staff_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(64)  NOT NULL,
  `last_name` varchar(64)  NOT NULL,
  `address_id` int NOT NULL,
  `picture` blob,
  `email` varchar(64)  DEFAULT NULL,
  `store_id` int NOT NULL,
  `active` int NOT NULL DEFAULT '1',
  `username` varchar(64)  NOT NULL,
  `password` varchar(64)  DEFAULT NULL,
  `last_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`staff_id`),
  KEY `fk_staff_address_id` (`address_id`),
  KEY `fk_staff_store_id` (`store_id`)
);

CREATE TABLE `store` (
  `store_id` int NOT NULL AUTO_INCREMENT,
  `manager_staff_id` int NOT NULL,
  `address_id` int NOT NULL,
  `last_update` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`store_id`),
  UNIQUE KEY `manager_staff_id` (`manager_staff_id`),
  KEY `fk_store_address_id` (`address_id`)
);


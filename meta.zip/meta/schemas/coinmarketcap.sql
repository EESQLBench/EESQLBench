CREATE TABLE `coins` (
  `id` int NOT NULL,
  `name` varchar(64)  DEFAULT NULL,
  `slug` varchar(64)  DEFAULT NULL,
  `symbol` varchar(64)  DEFAULT NULL,
  `status` varchar(64)  DEFAULT NULL,
  `category` varchar(64)  DEFAULT NULL,
  `description` varchar(256)  DEFAULT NULL,
  `subreddit` varchar(64)  DEFAULT NULL,
  `notice` varchar(256)  DEFAULT NULL,
  `tags` varchar(256)  DEFAULT NULL,
  `tag_names` varchar(256)  DEFAULT NULL,
  `website` varchar(256)  DEFAULT NULL,
  `platform_id` int DEFAULT NULL,
  `date_added` datetime DEFAULT NULL,
  `date_launched` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `historical` (
  `DATE` date DEFAULT NULL,
  `coin_id` int DEFAULT NULL,
  `cmc_rank` int DEFAULT NULL,
  `market_cap` double DEFAULT NULL,
  `price` double DEFAULT NULL,
  `open` double DEFAULT NULL,
  `high` double DEFAULT NULL,
  `low` double DEFAULT NULL,
  `close` double DEFAULT NULL,
  `time_high` varchar(64)  DEFAULT NULL,
  `time_low` varchar(64)  DEFAULT NULL,
  `volume_24h` double DEFAULT NULL,
  `percent_change_1h` double DEFAULT NULL,
  `percent_change_24h` double DEFAULT NULL,
  `percent_change_7d` double DEFAULT NULL,
  `circulating_supply` double DEFAULT NULL,
  `total_supply` double DEFAULT NULL,
  `max_supply` double DEFAULT NULL,
  `num_market_pairs` int DEFAULT NULL
);


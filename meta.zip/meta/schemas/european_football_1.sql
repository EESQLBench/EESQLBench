CREATE TABLE `divisions` (
  `division` varchar(64)  NOT NULL,
  `name` varchar(64)  DEFAULT NULL,
  `country` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`division`)
);

CREATE TABLE `matchs` (
  `Div` varchar(64)  DEFAULT NULL,
  `DATE` date DEFAULT NULL,
  `HomeTeam` varchar(64)  DEFAULT NULL,
  `AwayTeam` varchar(64)  DEFAULT NULL,
  `FTHG` int DEFAULT NULL,
  `FTAG` int DEFAULT NULL,
  `FTR` varchar(64)  DEFAULT NULL,
  `season` int DEFAULT NULL,
  KEY `fk_matchs_Div` (`Div`)
);


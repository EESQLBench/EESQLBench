CREATE TABLE `location` (
  `LocationID` int NOT NULL,
  `Country` varchar(64)  DEFAULT NULL,
  `State` varchar(64)  DEFAULT NULL,
  `StateCode` varchar(64)  DEFAULT NULL,
  `City` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`LocationID`)
);

CREATE TABLE `twitter` (
  `TweetID` varchar(64)  NOT NULL,
  `Weekday` varchar(64)  DEFAULT NULL,
  `Hour` int DEFAULT NULL,
  `Day` int DEFAULT NULL,
  `Lang` varchar(64)  DEFAULT NULL,
  `IsReshare` varchar(64)  DEFAULT NULL,
  `Reach` int DEFAULT NULL,
  `RetweetCount` int DEFAULT NULL,
  `Likes` int DEFAULT NULL,
  `Klout` int DEFAULT NULL,
  `Sentiment` double DEFAULT NULL,
  `text` varchar(1024)  DEFAULT NULL,
  `LocationID` int DEFAULT NULL,
  `UserID` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`TweetID`),
  KEY `fk_twitter_LocationID` (`LocationID`),
  KEY `fk_twitter_UserID` (`UserID`)
);

CREATE TABLE `user` (
  `UserID` varchar(64)  NOT NULL,
  `Gender` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`UserID`)
);


CREATE TABLE `all_prevalences` (
  `ITEM` varchar(128)  NOT NULL,
  `POPULATION TYPE` text ,
  `OCCURRENCES` int DEFAULT NULL,
  `POPULATION COUNT` int DEFAULT NULL,
  `PREVALENCE RATE` double DEFAULT NULL,
  `PREVALENCE PERCENTAGE` double DEFAULT NULL,
  PRIMARY KEY (`ITEM`)
);

CREATE TABLE `allergies` (
  `START` varchar(64)  DEFAULT NULL,
  `STOP` varchar(64)  DEFAULT NULL,
  `PATIENT` varchar(64)  NOT NULL,
  `ENCOUNTER` varchar(64)  NOT NULL,
  `CODE` int NOT NULL,
  `DESCRIPTION` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`PATIENT`,`ENCOUNTER`,`CODE`),
  KEY `fk_allergies_ENCOUNTER` (`ENCOUNTER`)
);

CREATE TABLE `careplans` (
  `ID` varchar(64)  DEFAULT NULL,
  `START` date DEFAULT NULL,
  `STOP` date DEFAULT NULL,
  `PATIENT` varchar(64)  DEFAULT NULL,
  `ENCOUNTER` varchar(64)  DEFAULT NULL,
  `CODE` double DEFAULT NULL,
  `DESCRIPTION` varchar(64)  DEFAULT NULL,
  `REASONCODE` bigint DEFAULT NULL,
  `REASONDESCRIPTION` varchar(128)  DEFAULT NULL,
  KEY `fk_careplans_ENCOUNTER` (`ENCOUNTER`),
  KEY `fk_careplans_PATIENT` (`PATIENT`)
);

CREATE TABLE `claims` (
  `ID` varchar(64)  NOT NULL,
  `PATIENT` varchar(64)  NOT NULL,
  `BILLABLEPERIOD` date DEFAULT NULL,
  `ORGANIZATION` varchar(64)  DEFAULT NULL,
  `ENCOUNTER` varchar(64)  NOT NULL,
  `DIAGNOSIS` varchar(256)  DEFAULT NULL,
  `TOTAL` int DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_claims_PATIENT` (`PATIENT`),
  KEY `fk_claims_ENCOUNTER` (`ENCOUNTER`)
);

CREATE TABLE `conditions` (
  `START` date DEFAULT NULL,
  `STOP` date DEFAULT NULL,
  `PATIENT` varchar(64)  DEFAULT NULL,
  `ENCOUNTER` varchar(64)  DEFAULT NULL,
  `CODE` bigint DEFAULT NULL,
  `DESCRIPTION` varchar(128)  DEFAULT NULL,
  KEY `fk_conditions_ENCOUNTER` (`ENCOUNTER`),
  KEY `fk_conditions_PATIENT` (`PATIENT`),
  KEY `fk_conditions_DESCRIPTION` (`DESCRIPTION`)
);

CREATE TABLE `encounters` (
  `ID` varchar(64)  NOT NULL,
  `DATE` date DEFAULT NULL,
  `PATIENT` varchar(64)  DEFAULT NULL,
  `CODE` int DEFAULT NULL,
  `DESCRIPTION` varchar(64)  DEFAULT NULL,
  `REASONCODE` bigint DEFAULT NULL,
  `REASONDESCRIPTION` varchar(128)  DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `fk_encounters_PATIENT` (`PATIENT`)
);

CREATE TABLE `immunizations` (
  `DATE` date NOT NULL,
  `PATIENT` varchar(64)  NOT NULL,
  `ENCOUNTER` varchar(64)  NOT NULL,
  `CODE` int NOT NULL,
  `DESCRIPTION` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`DATE`,`PATIENT`,`ENCOUNTER`,`CODE`),
  KEY `fk_immunizations_ENCOUNTER` (`ENCOUNTER`),
  KEY `fk_immunizations_PATIENT` (`PATIENT`)
);

CREATE TABLE `medications` (
  `START` date NOT NULL,
  `STOP` date DEFAULT NULL,
  `PATIENT` varchar(64)  NOT NULL,
  `ENCOUNTER` varchar(64)  NOT NULL,
  `CODE` int NOT NULL,
  `DESCRIPTION` varchar(128)  DEFAULT NULL,
  `REASONCODE` bigint DEFAULT NULL,
  `REASONDESCRIPTION` varchar(128)  DEFAULT NULL,
  PRIMARY KEY (`START`,`PATIENT`,`ENCOUNTER`,`CODE`),
  KEY `fk_medications_ENCOUNTER` (`ENCOUNTER`),
  KEY `fk_medications_PATIENT` (`PATIENT`)
);

CREATE TABLE `observations` (
  `DATE` date DEFAULT NULL,
  `PATIENT` varchar(64)  DEFAULT NULL,
  `ENCOUNTER` varchar(64)  DEFAULT NULL,
  `CODE` varchar(64)  DEFAULT NULL,
  `DESCRIPTION` varchar(128)  DEFAULT NULL,
  `VALUE` double DEFAULT NULL,
  `UNITS` varchar(64)  DEFAULT NULL,
  KEY `fk_observations_ENCOUNTER` (`ENCOUNTER`),
  KEY `fk_observations_PATIENT` (`PATIENT`)
);

CREATE TABLE `patients` (
  `patient` varchar(64)  NOT NULL,
  `birthdate` date DEFAULT NULL,
  `deathdate` date DEFAULT NULL,
  `ssn` varchar(64)  DEFAULT NULL,
  `drivers` varchar(64)  DEFAULT NULL,
  `passport` varchar(64)  DEFAULT NULL,
  `prefix` varchar(64)  DEFAULT NULL,
  `first` varchar(64)  DEFAULT NULL,
  `last` varchar(64)  DEFAULT NULL,
  `suffix` varchar(64)  DEFAULT NULL,
  `maiden` varchar(64)  DEFAULT NULL,
  `marital` varchar(64)  DEFAULT NULL,
  `race` varchar(64)  DEFAULT NULL,
  `ethnicity` varchar(64)  DEFAULT NULL,
  `gender` varchar(64)  DEFAULT NULL,
  `birthplace` varchar(64)  DEFAULT NULL,
  `address` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`patient`)
);

CREATE TABLE `procedures` (
  `DATE` date DEFAULT NULL,
  `PATIENT` varchar(64)  DEFAULT NULL,
  `ENCOUNTER` varchar(64)  DEFAULT NULL,
  `CODE` bigint DEFAULT NULL,
  `DESCRIPTION` varchar(128)  DEFAULT NULL,
  `REASONCODE` bigint DEFAULT NULL,
  `REASONDESCRIPTION` varchar(128)  DEFAULT NULL,
  KEY `fk_procedures_ENCOUNTER` (`ENCOUNTER`),
  KEY `fk_procedures_PATIENT` (`PATIENT`)
);


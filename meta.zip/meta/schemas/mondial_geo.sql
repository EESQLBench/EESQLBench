CREATE TABLE `borders` (
  `Country1` varchar(64)  NOT NULL DEFAULT '',
  `Country2` varchar(64)  NOT NULL DEFAULT '',
  `Length` double DEFAULT NULL,
  PRIMARY KEY (`Country1`,`Country2`),
  KEY `fk_borders_Country2` (`Country2`)
);

CREATE TABLE `city` (
  `Name` varchar(64)  NOT NULL DEFAULT '',
  `Country` varchar(64)  NOT NULL DEFAULT '',
  `Province` varchar(64)  NOT NULL DEFAULT '',
  `Population` int DEFAULT NULL,
  `Longitude` double DEFAULT NULL,
  `Latitude` double DEFAULT NULL,
  PRIMARY KEY (`Name`,`Province`),
  KEY `city_ibfk_2` (`Province`,`Country`),
  KEY `fk_city_Country` (`Country`)
);

CREATE TABLE `continent` (
  `Name` varchar(64)  NOT NULL DEFAULT '',
  `Area` double DEFAULT NULL,
  PRIMARY KEY (`Name`)
);

CREATE TABLE `country` (
  `Name` varchar(64)  NOT NULL,
  `Code` varchar(64)  NOT NULL DEFAULT '',
  `Capital` varchar(64)  DEFAULT NULL,
  `Province` varchar(64)  DEFAULT NULL,
  `Area` double DEFAULT NULL,
  `Population` int DEFAULT NULL,
  PRIMARY KEY (`Code`)
);

CREATE TABLE `desert` (
  `Name` varchar(64)  NOT NULL DEFAULT '',
  `Area` double DEFAULT NULL,
  `Longitude` double DEFAULT NULL,
  `Latitude` double DEFAULT NULL,
  PRIMARY KEY (`Name`)
);

CREATE TABLE `economy` (
  `Country` varchar(64)  NOT NULL DEFAULT '',
  `GDP` double DEFAULT NULL,
  `Agriculture` double DEFAULT NULL,
  `Service` double DEFAULT NULL,
  `Industry` double DEFAULT NULL,
  `Inflation` double DEFAULT NULL,
  PRIMARY KEY (`Country`)
);

CREATE TABLE `encompasses` (
  `Country` varchar(64)  NOT NULL,
  `Continent` varchar(64)  NOT NULL,
  `Percentage` double DEFAULT NULL,
  PRIMARY KEY (`Country`,`Continent`),
  KEY `fk_encompasses_Continent` (`Continent`)
);

CREATE TABLE `ethnicgroup` (
  `Country` varchar(64)  NOT NULL DEFAULT '',
  `Name` varchar(64)  NOT NULL DEFAULT '',
  `Percentage` double DEFAULT NULL,
  PRIMARY KEY (`Name`,`Country`),
  KEY `fk_ethnicGroup_Country` (`Country`)
);

CREATE TABLE `geo_desert` (
  `Desert` varchar(64)  NOT NULL DEFAULT '',
  `Country` varchar(64)  NOT NULL DEFAULT '',
  `Province` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`Province`,`Country`,`Desert`),
  KEY `fk_geo_desert_Desert` (`Desert`),
  KEY `fk_geo_desert_Country` (`Country`),
  CONSTRAINT `geo_desert_ibfk_2` FOREIGN KEY (`Province`, `Country`) REFERENCES `province` (`Name`, `Country`)
);

CREATE TABLE `geo_estuary` (
  `River` varchar(64)  NOT NULL DEFAULT '',
  `Country` varchar(64)  NOT NULL DEFAULT '',
  `Province` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`Province`,`Country`,`River`),
  KEY `fk_geo_estuary_River` (`River`),
  KEY `fk_geo_estuary_Country` (`Country`),
  CONSTRAINT `geo_estuary_ibfk_2` FOREIGN KEY (`Province`, `Country`) REFERENCES `province` (`Name`, `Country`)
);

CREATE TABLE `geo_island` (
  `Island` varchar(64)  NOT NULL DEFAULT '',
  `Country` varchar(64)  NOT NULL DEFAULT '',
  `Province` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`Province`,`Country`,`Island`),
  KEY `fk_geo_island_Island` (`Island`),
  KEY `fk_geo_island_Country` (`Country`),
  CONSTRAINT `geo_island_ibfk_2` FOREIGN KEY (`Province`, `Country`) REFERENCES `province` (`Name`, `Country`)
);

CREATE TABLE `geo_lake` (
  `Lake` varchar(64)  NOT NULL DEFAULT '',
  `Country` varchar(64)  NOT NULL DEFAULT '',
  `Province` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`Province`,`Country`,`Lake`),
  KEY `fk_geo_lake_Lake` (`Lake`),
  KEY `fk_geo_lake_Country` (`Country`),
  CONSTRAINT `geo_lake_ibfk_2` FOREIGN KEY (`Province`, `Country`) REFERENCES `province` (`Name`, `Country`)
);

CREATE TABLE `geo_mountain` (
  `Mountain` varchar(64)  NOT NULL DEFAULT '',
  `Country` varchar(64)  NOT NULL DEFAULT '',
  `Province` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`Province`,`Country`,`Mountain`),
  KEY `fk_geo_mountain_Mountain` (`Mountain`),
  KEY `fk_geo_mountain_Country` (`Country`),
  CONSTRAINT `geo_mountain_ibfk_2` FOREIGN KEY (`Province`, `Country`) REFERENCES `province` (`Name`, `Country`)
);

CREATE TABLE `geo_river` (
  `River` varchar(64)  NOT NULL DEFAULT '',
  `Country` varchar(64)  NOT NULL DEFAULT '',
  `Province` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`Province`,`Country`,`River`),
  KEY `fk_geo_river_River` (`River`),
  KEY `fk_geo_river_Country` (`Country`),
  CONSTRAINT `geo_river_ibfk_2` FOREIGN KEY (`Province`, `Country`) REFERENCES `province` (`Name`, `Country`)
);

CREATE TABLE `geo_sea` (
  `Sea` varchar(64)  NOT NULL DEFAULT '',
  `Country` varchar(64)  NOT NULL DEFAULT '',
  `Province` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`Province`,`Country`,`Sea`),
  KEY `fk_geo_sea_Sea` (`Sea`),
  KEY `fk_geo_sea_Country` (`Country`),
  CONSTRAINT `geo_sea_ibfk_2` FOREIGN KEY (`Province`, `Country`) REFERENCES `province` (`Name`, `Country`)
);

CREATE TABLE `geo_source` (
  `River` varchar(64)  NOT NULL DEFAULT '',
  `Country` varchar(64)  NOT NULL DEFAULT '',
  `Province` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`Province`,`Country`,`River`),
  KEY `fk_geo_source_River` (`River`),
  KEY `fk_geo_source_Country` (`Country`),
  CONSTRAINT `geo_source_ibfk_2` FOREIGN KEY (`Province`, `Country`) REFERENCES `province` (`Name`, `Country`)
);

CREATE TABLE `island` (
  `Name` varchar(64)  NOT NULL DEFAULT '',
  `Islands` varchar(64)  DEFAULT NULL,
  `Area` double DEFAULT NULL,
  `Height` double DEFAULT NULL,
  `Type` varchar(64)  DEFAULT NULL,
  `Longitude` double DEFAULT NULL,
  `Latitude` double DEFAULT NULL,
  PRIMARY KEY (`Name`)
);

CREATE TABLE `islandin` (
  `Island` varchar(64)  DEFAULT NULL,
  `Sea` varchar(64)  DEFAULT NULL,
  `Lake` varchar(64)  DEFAULT NULL,
  `River` varchar(64)  DEFAULT NULL,
  KEY `fk_islandIn_Island` (`Island`),
  KEY `fk_islandIn_Sea` (`Sea`),
  KEY `fk_islandIn_Lake` (`Lake`),
  KEY `fk_islandIn_River` (`River`)
);

CREATE TABLE `ismember` (
  `Country` varchar(64)  NOT NULL DEFAULT '',
  `Organization` varchar(64)  NOT NULL DEFAULT '',
  `Type` varchar(64)  DEFAULT 'member',
  PRIMARY KEY (`Country`,`Organization`),
  KEY `fk_isMember_Organization` (`Organization`)
);

CREATE TABLE `lake` (
  `Name` varchar(64)  NOT NULL DEFAULT '',
  `Area` double DEFAULT NULL,
  `Depth` double DEFAULT NULL,
  `Altitude` double DEFAULT NULL,
  `Type` varchar(64)  DEFAULT NULL,
  `River` varchar(64)  DEFAULT NULL,
  `Longitude` double DEFAULT NULL,
  `Latitude` double DEFAULT NULL,
  PRIMARY KEY (`Name`)
);

CREATE TABLE `language` (
  `Country` varchar(64)  NOT NULL DEFAULT '',
  `Name` varchar(64)  NOT NULL DEFAULT '',
  `Percentage` double DEFAULT NULL,
  PRIMARY KEY (`Name`,`Country`),
  KEY `fk_language_Country` (`Country`)
);

CREATE TABLE `located` (
  `City` varchar(64)  DEFAULT NULL,
  `Province` varchar(64)  DEFAULT NULL,
  `Country` varchar(64)  DEFAULT NULL,
  `River` varchar(64)  DEFAULT NULL,
  `Lake` varchar(64)  DEFAULT NULL,
  `Sea` varchar(64)  DEFAULT NULL,
  KEY `located_ibfk_2` (`City`,`Province`),
  KEY `located_ibfk_6` (`Province`,`Country`),
  KEY `fk_located_Country` (`Country`),
  KEY `fk_located_River` (`River`),
  KEY `fk_located_Lake` (`Lake`),
  KEY `fk_located_Sea` (`Sea`),
  CONSTRAINT `located_ibfk_2` FOREIGN KEY (`City`, `Province`) REFERENCES `city` (`Name`, `Province`),
  CONSTRAINT `located_ibfk_6` FOREIGN KEY (`Province`, `Country`) REFERENCES `province` (`Name`, `Country`)
);

CREATE TABLE `locatedon` (
  `City` varchar(64)  NOT NULL DEFAULT '',
  `Province` varchar(64)  NOT NULL DEFAULT '',
  `Country` varchar(64)  NOT NULL DEFAULT '',
  `Island` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`City`,`Province`,`Country`,`Island`),
  KEY `locatedOn_ibfk_4` (`Province`,`Country`),
  KEY `fk_locatedOn_Country` (`Country`),
  KEY `fk_locatedOn_Island` (`Island`),
  CONSTRAINT `locatedOn_ibfk_3` FOREIGN KEY (`City`, `Province`) REFERENCES `city` (`Name`, `Province`),
  CONSTRAINT `locatedOn_ibfk_4` FOREIGN KEY (`Province`, `Country`) REFERENCES `province` (`Name`, `Country`)
);

CREATE TABLE `mergeswith` (
  `Sea1` varchar(64)  NOT NULL DEFAULT '',
  `Sea2` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`Sea1`,`Sea2`),
  KEY `fk_mergesWith_Sea2` (`Sea2`)
);

CREATE TABLE `mountain` (
  `Name` varchar(256)  NOT NULL DEFAULT '',
  `Mountains` varchar(256)  DEFAULT NULL,
  `Height` double DEFAULT NULL,
  `Type` varchar(256)  DEFAULT NULL,
  `Longitude` double DEFAULT NULL,
  `Latitude` double DEFAULT NULL,
  PRIMARY KEY (`Name`)
);

CREATE TABLE `mountainonisland` (
  `Mountain` varchar(64)  NOT NULL DEFAULT '',
  `Island` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`Mountain`,`Island`),
  KEY `fk_mountainOnIsland_Island` (`Island`)
);

CREATE TABLE `organization` (
  `Abbreviation` varchar(64)  NOT NULL,
  `Name` varchar(128)  NOT NULL,
  `City` varchar(64)  DEFAULT NULL,
  `Country` varchar(64)  DEFAULT NULL,
  `Province` varchar(64)  DEFAULT NULL,
  `Established` date DEFAULT NULL,
  PRIMARY KEY (`Abbreviation`),
  KEY `organization_ibfk_2` (`City`,`Province`),
  KEY `organization_ibfk_3` (`Province`,`Country`),
  KEY `fk_organization_Country` (`Country`),
  CONSTRAINT `organization_ibfk_2` FOREIGN KEY (`City`, `Province`) REFERENCES `city` (`Name`, `Province`),
  CONSTRAINT `organization_ibfk_3` FOREIGN KEY (`Province`, `Country`) REFERENCES `province` (`Name`, `Country`)
);

CREATE TABLE `politics` (
  `Country` varchar(64)  NOT NULL DEFAULT '',
  `Independence` date DEFAULT NULL,
  `Dependent` varchar(64)  DEFAULT NULL,
  `Government` varchar(128)  DEFAULT NULL,
  PRIMARY KEY (`Country`),
  KEY `fk_politics_Dependent` (`Dependent`)
);

CREATE TABLE `population` (
  `Country` varchar(64)  NOT NULL DEFAULT '',
  `Population_Growth` double DEFAULT NULL,
  `Infant_Mortality` double DEFAULT NULL,
  PRIMARY KEY (`Country`)
);

CREATE TABLE `province` (
  `Name` varchar(64)  NOT NULL,
  `Country` varchar(64)  NOT NULL,
  `Population` int DEFAULT NULL,
  `Area` double DEFAULT NULL,
  `Capital` varchar(64)  DEFAULT NULL,
  `CapProv` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`Name`,`Country`),
  KEY `fk_province_Country` (`Country`)
);

CREATE TABLE `religion` (
  `Country` varchar(64)  NOT NULL DEFAULT '',
  `Name` varchar(64)  NOT NULL DEFAULT '',
  `Percentage` double DEFAULT NULL,
  PRIMARY KEY (`Name`,`Country`),
  KEY `fk_religion_Country` (`Country`)
);

CREATE TABLE `river` (
  `Name` varchar(64)  NOT NULL DEFAULT '',
  `River` varchar(64)  DEFAULT NULL,
  `Lake` varchar(64)  DEFAULT NULL,
  `Sea` varchar(64)  DEFAULT NULL,
  `Length` double DEFAULT NULL,
  `SourceLongitude` double DEFAULT NULL,
  `SourceLatitude` double DEFAULT NULL,
  `Mountains` varchar(64)  DEFAULT NULL,
  `SourceAltitude` double DEFAULT NULL,
  `EstuaryLongitude` double DEFAULT NULL,
  `EstuaryLatitude` double DEFAULT NULL,
  PRIMARY KEY (`Name`),
  KEY `fk_river_Lake` (`Lake`)
);

CREATE TABLE `sea` (
  `Name` varchar(64)  NOT NULL DEFAULT '',
  `Depth` double DEFAULT NULL,
  PRIMARY KEY (`Name`)
);

CREATE TABLE `target` (
  `Country` varchar(64)  NOT NULL,
  `Target` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`Country`)
);


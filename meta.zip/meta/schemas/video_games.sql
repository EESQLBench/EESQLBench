CREATE TABLE `game` (
  `id` int NOT NULL,
  `genre_id` int DEFAULT NULL,
  `game_name` varchar(256)  DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_game_genre_id` (`genre_id`)
);

CREATE TABLE `game_platform` (
  `id` int NOT NULL,
  `game_publisher_id` int DEFAULT NULL,
  `platform_id` int DEFAULT NULL,
  `release_year` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_game_platform_game_publisher_id` (`game_publisher_id`),
  KEY `fk_game_platform_platform_id` (`platform_id`)
);

CREATE TABLE `game_publisher` (
  `id` int NOT NULL,
  `game_id` int DEFAULT NULL,
  `publisher_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_game_publisher_game_id` (`game_id`),
  KEY `fk_game_publisher_publisher_id` (`publisher_id`)
);

CREATE TABLE `genre` (
  `id` int NOT NULL,
  `genre_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `platform` (
  `id` int NOT NULL,
  `platform_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `publisher` (
  `id` int NOT NULL,
  `publisher_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `region` (
  `id` int NOT NULL,
  `region_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `region_sales` (
  `region_id` int DEFAULT NULL,
  `game_platform_id` int DEFAULT NULL,
  `num_sales` double DEFAULT NULL,
  KEY `fk_region_sales_game_platform_id` (`game_platform_id`),
  KEY `fk_region_sales_region_id` (`region_id`)
);


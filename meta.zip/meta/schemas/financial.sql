CREATE TABLE `account` (
  `account_id` int NOT NULL DEFAULT '0',
  `district_id` int NOT NULL DEFAULT '0',
  `frequency` varchar(64)  NOT NULL,
  `DATE` date NOT NULL,
  PRIMARY KEY (`account_id`),
  KEY `fk_account_district_id` (`district_id`)
);

CREATE TABLE `card` (
  `card_id` int NOT NULL DEFAULT '0',
  `disp_id` int NOT NULL,
  `type` varchar(64)  NOT NULL,
  `issued` date NOT NULL,
  PRIMARY KEY (`card_id`),
  KEY `fk_card_disp_id` (`disp_id`)
);

CREATE TABLE `client` (
  `client_id` int NOT NULL,
  `gender` varchar(64)  NOT NULL,
  `birth_date` date NOT NULL,
  `district_id` int NOT NULL,
  PRIMARY KEY (`client_id`),
  KEY `fk_client_district_id` (`district_id`)
);

CREATE TABLE `disp` (
  `disp_id` int NOT NULL,
  `client_id` int NOT NULL,
  `account_id` int NOT NULL,
  `type` varchar(64)  NOT NULL,
  PRIMARY KEY (`disp_id`),
  KEY `fk_disp_account_id` (`account_id`),
  KEY `fk_disp_client_id` (`client_id`)
);

CREATE TABLE `district` (
  `district_id` int NOT NULL DEFAULT '0',
  `A2` varchar(64)  NOT NULL,
  `A3` varchar(64)  NOT NULL,
  `A4` varchar(64)  NOT NULL,
  `A5` varchar(64)  NOT NULL,
  `A6` varchar(64)  NOT NULL,
  `A7` varchar(64)  NOT NULL,
  `A8` int NOT NULL,
  `A9` int NOT NULL,
  `A10` double NOT NULL,
  `A11` int NOT NULL,
  `A12` double DEFAULT NULL,
  `A13` double NOT NULL,
  `A14` int NOT NULL,
  `A15` int DEFAULT NULL,
  `A16` int NOT NULL,
  PRIMARY KEY (`district_id`)
);

CREATE TABLE `loan` (
  `loan_id` int NOT NULL DEFAULT '0',
  `account_id` int NOT NULL,
  `DATE` date NOT NULL,
  `amount` int NOT NULL,
  `duration` int NOT NULL,
  `payments` double NOT NULL,
  `status` varchar(64)  NOT NULL,
  PRIMARY KEY (`loan_id`),
  KEY `fk_loan_account_id` (`account_id`)
);

CREATE TABLE `trans` (
  `trans_id` int NOT NULL DEFAULT '0',
  `account_id` int NOT NULL DEFAULT '0',
  `DATE` date NOT NULL,
  `type` varchar(64)  NOT NULL,
  `operation` varchar(64)  DEFAULT NULL,
  `amount` int NOT NULL,
  `balance` int NOT NULL,
  `k_symbol` varchar(64)  DEFAULT NULL,
  `bank` varchar(64)  DEFAULT NULL,
  `account` int DEFAULT NULL,
  PRIMARY KEY (`trans_id`),
  KEY `fk_trans_account_id` (`account_id`)
);


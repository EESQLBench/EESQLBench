CREATE TABLE `employee` (
  `employee_id` int NOT NULL,
  `first_name` varchar(64)  DEFAULT NULL,
  `last_name` varchar(64)  DEFAULT NULL,
  `address` varchar(64)  DEFAULT NULL,
  `city` varchar(64)  DEFAULT NULL,
  `state` varchar(64)  DEFAULT NULL,
  `zip` int DEFAULT NULL,
  `phone` varchar(64)  DEFAULT NULL,
  `title` varchar(64)  DEFAULT NULL,
  `salary` int DEFAULT NULL,
  `supervisor` int DEFAULT NULL,
  PRIMARY KEY (`employee_id`)
);

CREATE TABLE `establishment` (
  `license_no` int NOT NULL,
  `dba_name` varchar(128)  DEFAULT NULL,
  `aka_name` varchar(64)  DEFAULT NULL,
  `facility_type` varchar(64)  DEFAULT NULL,
  `risk_level` int DEFAULT NULL,
  `address` varchar(64)  DEFAULT NULL,
  `city` varchar(64)  DEFAULT NULL,
  `state` varchar(64)  DEFAULT NULL,
  `zip` int DEFAULT NULL,
  `latitude` double DEFAULT NULL,
  `longitude` double DEFAULT NULL,
  `ward` int DEFAULT NULL,
  PRIMARY KEY (`license_no`)
);

CREATE TABLE `inspection` (
  `inspection_id` int NOT NULL,
  `inspection_date` date DEFAULT NULL,
  `inspection_type` varchar(64)  DEFAULT NULL,
  `results` varchar(64)  DEFAULT NULL,
  `employee_id` int DEFAULT NULL,
  `license_no` int DEFAULT NULL,
  `followup_to` int DEFAULT NULL,
  PRIMARY KEY (`inspection_id`),
  KEY `fk_inspection_employee_id` (`employee_id`),
  KEY `fk_inspection_license_no` (`license_no`)
);

CREATE TABLE `inspection_point` (
  `point_id` int NOT NULL,
  `Description` varchar(256)  DEFAULT NULL,
  `category` varchar(64)  DEFAULT NULL,
  `code` varchar(64)  DEFAULT NULL,
  `fine` int DEFAULT NULL,
  `point_level` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`point_id`)
);

CREATE TABLE `violation` (
  `inspection_id` int NOT NULL,
  `point_id` int NOT NULL,
  `fine` int DEFAULT NULL,
  `inspector_comment` varchar(4096)  DEFAULT NULL,
  PRIMARY KEY (`inspection_id`,`point_id`),
  KEY `fk_violation_point_id` (`point_id`)
);


CREATE TABLE `callcenterlogs` (
  `DATE received` date DEFAULT NULL,
  `Complaint ID` varchar(10)  DEFAULT NULL,
  `rand client` text ,
  `phonefinal` varchar(64)  DEFAULT NULL,
  `vru+line` text ,
  `call_id` int DEFAULT NULL,
  `priority` int DEFAULT NULL,
  `type` varchar(64)  DEFAULT NULL,
  `outcome` varchar(64)  DEFAULT NULL,
  `server` varchar(64)  DEFAULT NULL,
  `ser_start` varchar(64)  DEFAULT NULL,
  `ser_exit` varchar(64)  DEFAULT NULL,
  `ser_time` varchar(64)  DEFAULT NULL,
  UNIQUE KEY `Complaint ID` (`Complaint ID`)
);

CREATE TABLE `client` (
  `client_id` varchar(64)  NOT NULL,
  `sex` varchar(64)  DEFAULT NULL,
  `day` int DEFAULT NULL,
  `month` int DEFAULT NULL,
  `year` int DEFAULT NULL,
  `age` int DEFAULT NULL,
  `social` varchar(64)  DEFAULT NULL,
  `first` varchar(64)  DEFAULT NULL,
  `middle` varchar(64)  DEFAULT NULL,
  `last` varchar(64)  DEFAULT NULL,
  `phone` varchar(64)  DEFAULT NULL,
  `email` varchar(64)  DEFAULT NULL,
  `address_1` varchar(64)  DEFAULT NULL,
  `address_2` varchar(64)  DEFAULT NULL,
  `city` varchar(64)  DEFAULT NULL,
  `state` varchar(64)  DEFAULT NULL,
  `zipcode` int DEFAULT NULL,
  `district_id` int DEFAULT NULL,
  PRIMARY KEY (`client_id`),
  KEY `fk_client_district_id` (`district_id`)
);

CREATE TABLE `district` (
  `district_id` int NOT NULL,
  `city` varchar(64)  DEFAULT NULL,
  `state_abbrev` varchar(64)  DEFAULT NULL,
  `division` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`district_id`),
  KEY `fk_district_state_abbrev` (`state_abbrev`)
);

CREATE TABLE `events` (
  `DATE received` date DEFAULT NULL,
  `Product` varchar(64)  DEFAULT NULL,
  `Sub-product` text ,
  `Issue` varchar(64)  DEFAULT NULL,
  `Sub-issue` text ,
  `Consumer complaint narrative` text ,
  `Tags` varchar(64)  DEFAULT NULL,
  `Consumer consent provided?` text ,
  `Submitted via` text ,
  `DATE sent to company` text ,
  `Company response to consumer` text ,
  `Timely response?` text ,
  `Consumer disputed?` text ,
  `Complaint ID` varchar(10)  NOT NULL,
  `Client_ID` varchar(64)  NOT NULL,
  PRIMARY KEY (`Complaint ID`,`Client_ID`),
  KEY `fk_events_Client_ID` (`Client_ID`)
);

CREATE TABLE `reviews` (
  `DATE` date NOT NULL,
  `Stars` int DEFAULT NULL,
  `Reviews` varchar(4096)  DEFAULT NULL,
  `Product` varchar(64)  DEFAULT NULL,
  `district_id` int DEFAULT NULL,
  PRIMARY KEY (`DATE`),
  KEY `fk_reviews_district_id` (`district_id`)
);

CREATE TABLE `state` (
  `StateCode` varchar(64)  NOT NULL,
  `State` varchar(64)  DEFAULT NULL,
  `Region` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`StateCode`)
);


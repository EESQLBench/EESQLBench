CREATE TABLE `central_superstore` (
  `Row ID` int NOT NULL,
  `Order ID` text ,
  `Order DATE` date DEFAULT NULL,
  `Ship DATE` date DEFAULT NULL,
  `Ship Mode` text ,
  `Customer ID` text ,
  `Region` varchar(64)  DEFAULT NULL,
  `Product ID` text ,
  `Sales` double DEFAULT NULL,
  `Quantity` int DEFAULT NULL,
  `Discount` double DEFAULT NULL,
  `Profit` double DEFAULT NULL,
  PRIMARY KEY (`Row ID`)
);

CREATE TABLE `east_superstore` (
  `Row ID` int NOT NULL,
  `Order ID` text ,
  `Order DATE` date DEFAULT NULL,
  `Ship DATE` date DEFAULT NULL,
  `Ship Mode` text ,
  `Customer ID` text ,
  `Region` varchar(64)  DEFAULT NULL,
  `Product ID` text ,
  `Sales` double DEFAULT NULL,
  `Quantity` int DEFAULT NULL,
  `Discount` double DEFAULT NULL,
  `Profit` double DEFAULT NULL,
  PRIMARY KEY (`Row ID`)
);

CREATE TABLE `people` (
  `Customer ID` varchar(8)  NOT NULL,
  `Customer Name` text ,
  `Segment` varchar(64)  DEFAULT NULL,
  `Country` varchar(64)  DEFAULT NULL,
  `City` varchar(64)  DEFAULT NULL,
  `State` varchar(64)  DEFAULT NULL,
  `Postal Code` int DEFAULT NULL,
  `Region` varchar(64)  NOT NULL,
  PRIMARY KEY (`Customer ID`,`Region`)
);

CREATE TABLE `product` (
  `Product ID` varchar(16)  NOT NULL,
  `Product Name` text ,
  `Category` varchar(64)  DEFAULT NULL,
  `Sub-Category` text ,
  `Region` varchar(64)  NOT NULL,
  PRIMARY KEY (`Product ID`,`Region`)
);

CREATE TABLE `south_superstore` (
  `Row ID` int NOT NULL,
  `Order ID` text ,
  `Order DATE` date DEFAULT NULL,
  `Ship DATE` date DEFAULT NULL,
  `Ship Mode` text ,
  `Customer ID` text ,
  `Region` varchar(64)  DEFAULT NULL,
  `Product ID` text ,
  `Sales` double DEFAULT NULL,
  `Quantity` int DEFAULT NULL,
  `Discount` double DEFAULT NULL,
  `Profit` double DEFAULT NULL,
  PRIMARY KEY (`Row ID`)
);

CREATE TABLE `west_superstore` (
  `Row ID` int NOT NULL,
  `Order ID` text ,
  `Order DATE` date DEFAULT NULL,
  `Ship DATE` date DEFAULT NULL,
  `Ship Mode` text ,
  `Customer ID` text ,
  `Region` varchar(64)  DEFAULT NULL,
  `Product ID` text ,
  `Sales` double DEFAULT NULL,
  `Quantity` int DEFAULT NULL,
  `Discount` double DEFAULT NULL,
  `Profit` double DEFAULT NULL,
  PRIMARY KEY (`Row ID`)
);


CREATE TABLE `alignment` (
  `id` int NOT NULL,
  `alignment` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `attribute` (
  `id` int NOT NULL,
  `attribute_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `colour` (
  `id` int NOT NULL,
  `colour` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `gender` (
  `id` int NOT NULL,
  `gender` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `hero_attribute` (
  `hero_id` int DEFAULT NULL,
  `attribute_id` int DEFAULT NULL,
  `attribute_value` int DEFAULT NULL,
  KEY `fk_hero_attribute_attribute_id` (`attribute_id`),
  KEY `fk_hero_attribute_hero_id` (`hero_id`)
);

CREATE TABLE `hero_power` (
  `hero_id` int DEFAULT NULL,
  `power_id` int DEFAULT NULL,
  KEY `fk_hero_power_hero_id` (`hero_id`),
  KEY `fk_hero_power_power_id` (`power_id`)
);

CREATE TABLE `publisher` (
  `id` int NOT NULL,
  `publisher_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `race` (
  `id` int NOT NULL,
  `race` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE `superhero` (
  `id` int NOT NULL,
  `superhero_name` varchar(64)  DEFAULT NULL,
  `full_name` varchar(64)  DEFAULT NULL,
  `gender_id` int DEFAULT NULL,
  `eye_colour_id` int DEFAULT NULL,
  `hair_colour_id` int DEFAULT NULL,
  `skin_colour_id` int DEFAULT NULL,
  `race_id` int DEFAULT NULL,
  `publisher_id` int DEFAULT NULL,
  `alignment_id` int DEFAULT NULL,
  `height_cm` int DEFAULT NULL,
  `weight_kg` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_superhero_alignment_id` (`alignment_id`),
  KEY `fk_superhero_eye_colour_id` (`eye_colour_id`),
  KEY `fk_superhero_gender_id` (`gender_id`),
  KEY `fk_superhero_hair_colour_id` (`hair_colour_id`),
  KEY `fk_superhero_publisher_id` (`publisher_id`),
  KEY `fk_superhero_race_id` (`race_id`),
  KEY `fk_superhero_skin_colour_id` (`skin_colour_id`)
);

CREATE TABLE `superpower` (
  `id` int NOT NULL,
  `power_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`id`)
);


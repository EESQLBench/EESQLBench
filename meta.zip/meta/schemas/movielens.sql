CREATE TABLE `actors` (
  `actorid` int NOT NULL,
  `a_gender` varchar(64)  NOT NULL,
  `a_quality` int NOT NULL,
  PRIMARY KEY (`actorid`)
);

CREATE TABLE `directors` (
  `directorid` int NOT NULL,
  `d_quality` int NOT NULL,
  `avg_revenue` int NOT NULL,
  PRIMARY KEY (`directorid`)
);

CREATE TABLE `movies` (
  `movieid` int NOT NULL DEFAULT '0',
  `year` int NOT NULL,
  `isEnglish` varchar(64)  NOT NULL,
  `country` varchar(64)  NOT NULL,
  `runningtime` int NOT NULL,
  PRIMARY KEY (`movieid`)
);

CREATE TABLE `movies2actors` (
  `movieid` int NOT NULL,
  `actorid` int NOT NULL,
  `cast_num` int NOT NULL,
  PRIMARY KEY (`movieid`,`actorid`),
  KEY `fk_movies2actors_actorid` (`actorid`)
);

CREATE TABLE `movies2directors` (
  `movieid` int NOT NULL,
  `directorid` int NOT NULL,
  `genre` varchar(64)  NOT NULL,
  PRIMARY KEY (`movieid`,`directorid`),
  KEY `fk_movies2directors_directorid` (`directorid`)
);

CREATE TABLE `u2base` (
  `userid` int NOT NULL DEFAULT '0',
  `movieid` int NOT NULL,
  `rating` varchar(64)  NOT NULL,
  PRIMARY KEY (`userid`,`movieid`),
  KEY `fk_u2base_movieid` (`movieid`)
);

CREATE TABLE `users` (
  `userid` int NOT NULL DEFAULT '0',
  `age` varchar(64)  NOT NULL,
  `u_gender` varchar(64)  NOT NULL,
  `occupation` varchar(64)  NOT NULL,
  PRIMARY KEY (`userid`)
);


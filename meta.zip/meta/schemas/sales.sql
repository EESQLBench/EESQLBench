CREATE TABLE `customers` (
  `CustomerID` int NOT NULL,
  `FirstName` varchar(64)  NOT NULL,
  `MiddleInitial` varchar(64)  DEFAULT NULL,
  `LastName` varchar(64)  NOT NULL,
  PRIMARY KEY (`CustomerID`)
);

CREATE TABLE `employees` (
  `EmployeeID` int NOT NULL,
  `FirstName` varchar(64)  NOT NULL,
  `MiddleInitial` varchar(64)  DEFAULT NULL,
  `LastName` varchar(64)  NOT NULL,
  PRIMARY KEY (`EmployeeID`)
);

CREATE TABLE `products` (
  `ProductID` int NOT NULL,
  `Name` varchar(64)  NOT NULL,
  `Price` double DEFAULT NULL,
  PRIMARY KEY (`ProductID`)
);

CREATE TABLE `sales` (
  `SalesID` int NOT NULL,
  `SalesPersonID` int NOT NULL,
  `CustomerID` int NOT NULL,
  `ProductID` int NOT NULL,
  `Quantity` int NOT NULL,
  PRIMARY KEY (`SalesID`),
  KEY `fk_Sales_SalesPersonID` (`SalesPersonID`),
  KEY `fk_Sales_CustomerID` (`CustomerID`),
  KEY `fk_Sales_ProductID` (`ProductID`)
);


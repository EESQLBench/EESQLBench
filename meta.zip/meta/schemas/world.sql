CREATE TABLE `city` (
  `ID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(64)  NOT NULL DEFAULT '',
  `CountryCode` varchar(64)  NOT NULL DEFAULT '',
  `District` varchar(64)  NOT NULL DEFAULT '',
  `Population` int NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `fk_City_CountryCode` (`CountryCode`)
);

CREATE TABLE `country` (
  `Code` varchar(64)  NOT NULL DEFAULT '',
  `Name` varchar(64)  NOT NULL DEFAULT '',
  `Continent` varchar(64)  NOT NULL DEFAULT 'Asia',
  `Region` varchar(64)  NOT NULL DEFAULT '',
  `SurfaceArea` double NOT NULL DEFAULT '0',
  `IndepYear` int DEFAULT NULL,
  `Population` int NOT NULL DEFAULT '0',
  `LifeExpectancy` double DEFAULT NULL,
  `GNP` double DEFAULT NULL,
  `GNPOld` double DEFAULT NULL,
  `LocalName` varchar(64)  NOT NULL DEFAULT '',
  `GovernmentForm` varchar(64)  NOT NULL DEFAULT '',
  `HeadOfState` varchar(64)  DEFAULT NULL,
  `Capital` int DEFAULT NULL,
  `Code2` varchar(64)  NOT NULL DEFAULT '',
  PRIMARY KEY (`Code`)
);

CREATE TABLE `countrylanguage` (
  `CountryCode` varchar(64)  NOT NULL DEFAULT '',
  `Language` varchar(64)  NOT NULL DEFAULT '',
  `IsOfficial` varchar(64)  NOT NULL DEFAULT 'F',
  `Percentage` double NOT NULL DEFAULT '0',
  PRIMARY KEY (`CountryCode`,`Language`)
);


CREATE TABLE `customers` (
  `CustomerID` int NOT NULL,
  `Customer Names` text ,
  PRIMARY KEY (`CustomerID`)
);

CREATE TABLE `products` (
  `ProductID` int NOT NULL,
  `Product Name` text ,
  PRIMARY KEY (`ProductID`)
);

CREATE TABLE `regions` (
  `StateCode` varchar(64)  NOT NULL,
  `State` varchar(64)  DEFAULT NULL,
  `Region` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`StateCode`)
);

CREATE TABLE `sales orders` (
  `OrderNumber` varchar(64)  NOT NULL,
  `Sales Channel` text ,
  `WarehouseCode` varchar(64)  DEFAULT NULL,
  `ProcuredDate` varchar(64)  DEFAULT NULL,
  `OrderDate` varchar(64)  DEFAULT NULL,
  `ShipDate` varchar(64)  DEFAULT NULL,
  `DeliveryDate` varchar(64)  DEFAULT NULL,
  `CurrencyCode` varchar(64)  DEFAULT NULL,
  `_SalesTeamID` int NOT NULL,
  `_CustomerID` int NOT NULL,
  `_StoreID` int NOT NULL,
  `_ProductID` int NOT NULL,
  `Order Quantity` int DEFAULT NULL,
  `Discount Applied` double DEFAULT NULL,
  `Unit Price` text ,
  `Unit Cost` text ,
  PRIMARY KEY (`OrderNumber`),
  KEY `fk_Sales Orders__CustomerID` (`_CustomerID`),
  KEY `fk_Sales Orders__ProductID` (`_ProductID`),
  CONSTRAINT `fk_Sales Orders__CustomerID` FOREIGN KEY (`_CustomerID`) REFERENCES `customers` (`CustomerID`),
  CONSTRAINT `fk_Sales Orders__ProductID` FOREIGN KEY (`_ProductID`) REFERENCES `products` (`ProductID`)
);

CREATE TABLE `sales team` (
  `SalesTeamID` int NOT NULL,
  `Sales Team` text ,
  `Region` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`SalesTeamID`)
);

CREATE TABLE `store locations` (
  `StoreID` int NOT NULL,
  `City Name` text ,
  `County` varchar(128)  DEFAULT NULL,
  `StateCode` varchar(64)  NOT NULL,
  `State` varchar(64)  DEFAULT NULL,
  `Type` varchar(64)  DEFAULT NULL,
  `Latitude` double DEFAULT NULL,
  `Longitude` double DEFAULT NULL,
  `AreaCode` int DEFAULT NULL,
  `Population` int DEFAULT NULL,
  `Household Income` int DEFAULT NULL,
  `Median Income` int DEFAULT NULL,
  `Land Area` int DEFAULT NULL,
  `Water Area` int DEFAULT NULL,
  `Time Zone` text ,
  PRIMARY KEY (`StoreID`),
  KEY `fk_Store Locations_StateCode` (`StateCode`),
  CONSTRAINT `fk_Store Locations_StateCode` FOREIGN KEY (`StateCode`) REFERENCES `regions` (`StateCode`)
);


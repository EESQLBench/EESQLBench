CREATE TABLE `classification` (
  `GeneID` varchar(64)  NOT NULL,
  `Localization` varchar(64)  NOT NULL,
  PRIMARY KEY (`GeneID`)
);

CREATE TABLE `genes` (
  `GeneID` varchar(64)  NOT NULL,
  `Essential` varchar(64)  NOT NULL,
  `Class` varchar(64)  NOT NULL,
  `Complex` varchar(64)  DEFAULT NULL,
  `Phenotype` varchar(64)  NOT NULL,
  `Motif` varchar(64)  NOT NULL,
  `Chromosome` int NOT NULL,
  `Function` varchar(128)  NOT NULL,
  `Localization` varchar(64)  NOT NULL,
  KEY `fk_Genes_GeneID` (`GeneID`)
);

CREATE TABLE `interactions` (
  `GeneID1` varchar(64)  NOT NULL,
  `GeneID2` varchar(64)  NOT NULL,
  `Type` varchar(64)  NOT NULL,
  `Expression_Corr` double NOT NULL,
  PRIMARY KEY (`GeneID1`,`GeneID2`),
  KEY `fk_Interactions_GeneID2` (`GeneID2`)
);


CREATE TABLE `playstore` (
  `App` varchar(256)  DEFAULT NULL,
  `Category` varchar(64)  DEFAULT NULL,
  `Rating` double DEFAULT NULL,
  `Reviews` int DEFAULT NULL,
  `Size` varchar(64)  DEFAULT NULL,
  `Installs` varchar(64)  DEFAULT NULL,
  `Type` varchar(64)  DEFAULT NULL,
  `Price` varchar(64)  DEFAULT NULL,
  `Content Rating` text ,
  `Genres` varchar(64)  DEFAULT NULL
);

CREATE TABLE `user_reviews` (
  `App` varchar(64)  NOT NULL,
  `Translated_Review` varchar(256)  DEFAULT NULL,
  `Sentiment` varchar(64)  DEFAULT NULL,
  `Sentiment_Polarity` varchar(64)  DEFAULT NULL,
  `Sentiment_Subjectivity` varchar(64)  DEFAULT NULL
);


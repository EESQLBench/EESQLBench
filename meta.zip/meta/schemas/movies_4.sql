CREATE TABLE `country` (
  `country_id` int NOT NULL,
  `country_iso_code` varchar(64)  DEFAULT NULL,
  `country_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`country_id`)
);

CREATE TABLE `department` (
  `department_id` int NOT NULL,
  `department_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`department_id`)
);

CREATE TABLE `gender` (
  `gender_id` int NOT NULL,
  `gender` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`gender_id`)
);

CREATE TABLE `genre` (
  `genre_id` int NOT NULL,
  `genre_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`genre_id`)
);

CREATE TABLE `keyword` (
  `keyword_id` int NOT NULL,
  `keyword_name` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`keyword_id`)
);

CREATE TABLE `language` (
  `language_id` int NOT NULL,
  `language_code` varchar(64)  DEFAULT NULL,
  `language_name` varchar(128)  DEFAULT NULL,
  PRIMARY KEY (`language_id`)
);

CREATE TABLE `language_role` (
  `role_id` int NOT NULL,
  `language_role` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`role_id`)
);

CREATE TABLE `movie` (
  `movie_id` int NOT NULL,
  `title` varchar(128)  DEFAULT NULL,
  `budget` int DEFAULT NULL,
  `homepage` varchar(256)  DEFAULT NULL,
  `overview` varchar(256)  DEFAULT NULL,
  `popularity` double DEFAULT NULL,
  `release_date` date DEFAULT NULL,
  `revenue` int DEFAULT NULL,
  `runtime` int DEFAULT NULL,
  `movie_status` varchar(64)  DEFAULT NULL,
  `tagline` varchar(256)  DEFAULT NULL,
  `vote_average` double DEFAULT NULL,
  `vote_count` int DEFAULT NULL,
  PRIMARY KEY (`movie_id`)
);

CREATE TABLE `movie_cast` (
  `movie_id` int DEFAULT NULL,
  `person_id` int DEFAULT NULL,
  `character_name` varchar(256)  DEFAULT NULL,
  `gender_id` int DEFAULT NULL,
  `cast_order` int DEFAULT NULL,
  KEY `fk_movie_cast_gender_id` (`gender_id`),
  KEY `fk_movie_cast_movie_id` (`movie_id`),
  KEY `fk_movie_cast_person_id` (`person_id`)
);

CREATE TABLE `movie_company` (
  `movie_id` int NOT NULL,
  `company_id` int NOT NULL,
  KEY `fk_movie_company_movie_id` (`movie_id`),
  KEY `fk_movie_company_company_id` (`company_id`)
);

CREATE TABLE `movie_crew` (
  `movie_id` int DEFAULT NULL,
  `person_id` int DEFAULT NULL,
  `department_id` int DEFAULT NULL,
  `job` varchar(64)  DEFAULT NULL,
  KEY `fk_movie_crew_department_id` (`department_id`),
  KEY `fk_movie_crew_movie_id` (`movie_id`),
  KEY `fk_movie_crew_person_id` (`person_id`)
);

CREATE TABLE `movie_genres` (
  `movie_id` int DEFAULT NULL,
  `genre_id` int DEFAULT NULL,
  KEY `fk_movie_genres_genre_id` (`genre_id`),
  KEY `fk_movie_genres_movie_id` (`movie_id`)
);

CREATE TABLE `movie_keywords` (
  `movie_id` int NOT NULL,
  `keyword_id` int NOT NULL,
  KEY `fk_movie_keywords_movie_id` (`movie_id`),
  KEY `fk_movie_keywords_keyword_id` (`keyword_id`)
);

CREATE TABLE `movie_languages` (
  `movie_id` int DEFAULT NULL,
  `language_id` int DEFAULT NULL,
  `language_role_id` int DEFAULT NULL,
  KEY `fk_movie_languages_language_id` (`language_id`),
  KEY `fk_movie_languages_movie_id` (`movie_id`),
  KEY `fk_movie_languages_language_role_id` (`language_role_id`)
);

CREATE TABLE `person` (
  `person_id` int NOT NULL,
  `person_name` varchar(128)  DEFAULT NULL,
  PRIMARY KEY (`person_id`)
);

CREATE TABLE `production_company` (
  `company_id` int NOT NULL,
  `company_name` varchar(128)  DEFAULT NULL,
  PRIMARY KEY (`company_id`)
);

CREATE TABLE `production_country` (
  `movie_id` int DEFAULT NULL,
  `country_id` int DEFAULT NULL,
  KEY `fk_production_country_country_id` (`country_id`),
  KEY `fk_production_country_movie_id` (`movie_id`)
);


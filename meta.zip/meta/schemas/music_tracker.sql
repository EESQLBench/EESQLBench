CREATE TABLE `tags` (
  `index` int NOT NULL,
  `id` int NOT NULL,
  `tag` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`index`),
  KEY `fk_tags_id` (`id`)
);

CREATE TABLE `torrents` (
  `groupName` varchar(1024)  DEFAULT NULL,
  `totalSnatched` int DEFAULT NULL,
  `artist` varchar(128)  DEFAULT NULL,
  `groupYear` int DEFAULT NULL,
  `releaseType` varchar(64)  DEFAULT NULL,
  `groupId` int DEFAULT NULL,
  `id` int NOT NULL,
  PRIMARY KEY (`id`)
);


CREATE TABLE `address` (
  `AddressID` int NOT NULL AUTO_INCREMENT,
  `AddressLine1` varchar(64)  NOT NULL,
  `AddressLine2` varchar(64)  DEFAULT NULL,
  `City` varchar(64)  NOT NULL,
  `StateProvinceID` int NOT NULL,
  `PostalCode` varchar(64)  NOT NULL,
  `SpatialLocation` varchar(64)  DEFAULT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`AddressID`),
  UNIQUE KEY `rowguid` (`rowguid`),
  UNIQUE KEY `AddressLine1` (`AddressLine1`,`AddressLine2`,`City`,`StateProvinceID`,`PostalCode`),
  KEY `fk_Address_StateProvinceID` (`StateProvinceID`)
);

CREATE TABLE `addresstype` (
  `AddressTypeID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(64)  NOT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`AddressTypeID`),
  UNIQUE KEY `Name` (`Name`),
  UNIQUE KEY `rowguid` (`rowguid`)
);

CREATE TABLE `billofmaterials` (
  `BillOfMaterialsID` int NOT NULL AUTO_INCREMENT,
  `ProductAssemblyID` int DEFAULT NULL,
  `ComponentID` int NOT NULL,
  `StartDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `EndDate` datetime DEFAULT NULL,
  `UnitMeasureCode` varchar(64)  NOT NULL,
  `BOMLevel` int NOT NULL,
  `PerAssemblyQty` double NOT NULL DEFAULT '1',
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`BillOfMaterialsID`),
  UNIQUE KEY `ProductAssemblyID` (`ProductAssemblyID`,`ComponentID`,`StartDate`),
  KEY `fk_BillOfMaterials_ComponentID` (`ComponentID`),
  KEY `fk_BillOfMaterials_UnitMeasureCode` (`UnitMeasureCode`)
);

CREATE TABLE `businessentity` (
  `BusinessEntityID` int NOT NULL AUTO_INCREMENT,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`BusinessEntityID`),
  UNIQUE KEY `rowguid` (`rowguid`)
);

CREATE TABLE `businessentityaddress` (
  `BusinessEntityID` int NOT NULL,
  `AddressID` int NOT NULL,
  `AddressTypeID` int NOT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`BusinessEntityID`,`AddressID`,`AddressTypeID`),
  UNIQUE KEY `rowguid` (`rowguid`),
  KEY `fk_BusinessEntityAddress_AddressID` (`AddressID`),
  KEY `fk_BusinessEntityAddress_AddressTypeID` (`AddressTypeID`)
);

CREATE TABLE `businessentitycontact` (
  `BusinessEntityID` int NOT NULL,
  `PersonID` int NOT NULL,
  `ContactTypeID` int NOT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`BusinessEntityID`,`PersonID`,`ContactTypeID`),
  UNIQUE KEY `rowguid` (`rowguid`),
  KEY `fk_BusinessEntityContact_ContactTypeID` (`ContactTypeID`),
  KEY `fk_BusinessEntityContact_PersonID` (`PersonID`)
);

CREATE TABLE `contacttype` (
  `ContactTypeID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ContactTypeID`),
  UNIQUE KEY `Name` (`Name`)
);

CREATE TABLE `countryregion` (
  `CountryRegionCode` varchar(64)  NOT NULL,
  `Name` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`CountryRegionCode`),
  UNIQUE KEY `Name` (`Name`)
);

CREATE TABLE `countryregioncurrency` (
  `CountryRegionCode` varchar(64)  NOT NULL,
  `CurrencyCode` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`CountryRegionCode`,`CurrencyCode`),
  KEY `fk_CountryRegionCurrency_CurrencyCode` (`CurrencyCode`)
);

CREATE TABLE `creditcard` (
  `CreditCardID` int NOT NULL AUTO_INCREMENT,
  `CardType` varchar(64)  NOT NULL,
  `CardNumber` varchar(64)  NOT NULL,
  `ExpMonth` int NOT NULL,
  `ExpYear` int NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`CreditCardID`),
  UNIQUE KEY `CardNumber` (`CardNumber`)
);

CREATE TABLE `culture` (
  `CultureID` varchar(64)  NOT NULL,
  `Name` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`CultureID`),
  UNIQUE KEY `Name` (`Name`)
);

CREATE TABLE `currency` (
  `CurrencyCode` varchar(64)  NOT NULL,
  `Name` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`CurrencyCode`),
  UNIQUE KEY `Name` (`Name`)
);

CREATE TABLE `currencyrate` (
  `CurrencyRateID` int NOT NULL AUTO_INCREMENT,
  `CurrencyRateDate` datetime NOT NULL,
  `FromCurrencyCode` varchar(64)  NOT NULL,
  `ToCurrencyCode` varchar(64)  NOT NULL,
  `AverageRate` double NOT NULL,
  `EndOfDayRate` double NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`CurrencyRateID`),
  UNIQUE KEY `CurrencyRateDate` (`CurrencyRateDate`,`FromCurrencyCode`,`ToCurrencyCode`),
  KEY `fk_CurrencyRate_FromCurrencyCode` (`FromCurrencyCode`),
  KEY `fk_CurrencyRate_ToCurrencyCode` (`ToCurrencyCode`)
);

CREATE TABLE `customer` (
  `CustomerID` int NOT NULL,
  `PersonID` int DEFAULT NULL,
  `StoreID` int DEFAULT NULL,
  `TerritoryID` int DEFAULT NULL,
  `AccountNumber` varchar(256)  NOT NULL,
  `rowguid` varchar(256)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`CustomerID`),
  UNIQUE KEY `AccountNumber` (`AccountNumber`),
  UNIQUE KEY `rowguid` (`rowguid`),
  KEY `fk_Customer_PersonID` (`PersonID`),
  KEY `fk_Customer_TerritoryID` (`TerritoryID`),
  KEY `fk_Customer_StoreID` (`StoreID`)
);

CREATE TABLE `department` (
  `DepartmentID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(64)  NOT NULL,
  `GroupName` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`DepartmentID`),
  UNIQUE KEY `Name` (`Name`)
);

CREATE TABLE `document` (
  `DocumentNode` varchar(64)  NOT NULL,
  `DocumentLevel` int DEFAULT NULL,
  `Title` varchar(64)  NOT NULL,
  `Owner` int NOT NULL,
  `FolderFlag` int NOT NULL DEFAULT '0',
  `FileName` varchar(64)  NOT NULL,
  `FileExtension` varchar(64)  NOT NULL,
  `Revision` varchar(64)  NOT NULL,
  `ChangeNumber` int NOT NULL DEFAULT '0',
  `Status` int NOT NULL,
  `DocumentSummary` varchar(512)  DEFAULT NULL,
  `Document` blob,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`DocumentNode`),
  UNIQUE KEY `rowguid` (`rowguid`),
  UNIQUE KEY `DocumentLevel` (`DocumentLevel`,`DocumentNode`),
  KEY `fk_Document_Owner` (`Owner`)
);

CREATE TABLE `emailaddress` (
  `BusinessEntityID` int NOT NULL,
  `EmailAddressID` int NOT NULL,
  `EmailAddress` varchar(64)  DEFAULT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`EmailAddressID`,`BusinessEntityID`),
  KEY `fk_EmailAddress_BusinessEntityID` (`BusinessEntityID`)
);

CREATE TABLE `employee` (
  `BusinessEntityID` int NOT NULL,
  `NationalIDNumber` varchar(64)  NOT NULL,
  `LoginID` varchar(64)  NOT NULL,
  `OrganizationNode` varchar(64)  DEFAULT NULL,
  `OrganizationLevel` int DEFAULT NULL,
  `JobTitle` varchar(64)  NOT NULL,
  `BirthDate` date NOT NULL,
  `MaritalStatus` varchar(64)  NOT NULL,
  `Gender` varchar(64)  NOT NULL,
  `HireDate` date NOT NULL,
  `SalariedFlag` int NOT NULL DEFAULT '1',
  `VacationHours` int NOT NULL DEFAULT '0',
  `SickLeaveHours` int NOT NULL DEFAULT '0',
  `CurrentFlag` int NOT NULL DEFAULT '1',
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`BusinessEntityID`),
  UNIQUE KEY `NationalIDNumber` (`NationalIDNumber`),
  UNIQUE KEY `LoginID` (`LoginID`),
  UNIQUE KEY `rowguid` (`rowguid`)
);

CREATE TABLE `employeedepartmenthistory` (
  `BusinessEntityID` int NOT NULL,
  `DepartmentID` int NOT NULL,
  `ShiftID` int NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date DEFAULT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`BusinessEntityID`,`StartDate`,`DepartmentID`,`ShiftID`),
  KEY `fk_EmployeeDepartmentHistory_DepartmentID` (`DepartmentID`),
  KEY `fk_EmployeeDepartmentHistory_ShiftID` (`ShiftID`)
);

CREATE TABLE `employeepayhistory` (
  `BusinessEntityID` int NOT NULL,
  `RateChangeDate` datetime NOT NULL,
  `Rate` double NOT NULL,
  `PayFrequency` int NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`BusinessEntityID`,`RateChangeDate`)
);

CREATE TABLE `jobcandidate` (
  `JobCandidateID` int NOT NULL AUTO_INCREMENT,
  `BusinessEntityID` int DEFAULT NULL,
  `Resume` varchar(8192)  DEFAULT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`JobCandidateID`),
  KEY `fk_JobCandidate_BusinessEntityID` (`BusinessEntityID`)
);

CREATE TABLE `location` (
  `LocationID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(64)  NOT NULL,
  `CostRate` double NOT NULL DEFAULT '0',
  `Availability` double NOT NULL DEFAULT '0',
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`LocationID`),
  UNIQUE KEY `Name` (`Name`)
);

CREATE TABLE `password` (
  `BusinessEntityID` int NOT NULL,
  `PasswordHash` varchar(64)  NOT NULL,
  `PasswordSalt` varchar(64)  NOT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`BusinessEntityID`)
);

CREATE TABLE `person` (
  `BusinessEntityID` int NOT NULL,
  `PersonType` varchar(64)  NOT NULL,
  `NameStyle` int NOT NULL DEFAULT '0',
  `Title` varchar(64)  DEFAULT NULL,
  `FirstName` varchar(64)  NOT NULL,
  `MiddleName` varchar(64)  DEFAULT NULL,
  `LastName` varchar(64)  NOT NULL,
  `Suffix` varchar(64)  DEFAULT NULL,
  `EmailPromotion` int NOT NULL DEFAULT '0',
  `AdditionalContactInfo` varchar(2048)  DEFAULT NULL,
  `Demographics` varchar(1024)  DEFAULT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`BusinessEntityID`),
  UNIQUE KEY `rowguid` (`rowguid`)
);

CREATE TABLE `personcreditcard` (
  `BusinessEntityID` int NOT NULL,
  `CreditCardID` int NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`BusinessEntityID`,`CreditCardID`),
  KEY `fk_PersonCreditCard_CreditCardID` (`CreditCardID`)
);

CREATE TABLE `phonenumbertype` (
  `PhoneNumberTypeID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`PhoneNumberTypeID`)
);

CREATE TABLE `product` (
  `ProductID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(64)  NOT NULL,
  `ProductNumber` varchar(64)  NOT NULL,
  `MakeFlag` int NOT NULL DEFAULT '1',
  `FinishedGoodsFlag` int NOT NULL DEFAULT '1',
  `Color` varchar(64)  DEFAULT NULL,
  `SafetyStockLevel` int NOT NULL,
  `ReorderPoint` int NOT NULL,
  `StandardCost` double NOT NULL,
  `ListPrice` double NOT NULL,
  `Size` varchar(64)  DEFAULT NULL,
  `SizeUnitMeasureCode` varchar(64)  DEFAULT NULL,
  `WeightUnitMeasureCode` varchar(64)  DEFAULT NULL,
  `Weight` double DEFAULT NULL,
  `DaysToManufacture` int NOT NULL,
  `ProductLine` varchar(64)  DEFAULT NULL,
  `Class` varchar(64)  DEFAULT NULL,
  `Style` varchar(64)  DEFAULT NULL,
  `ProductSubcategoryID` int DEFAULT NULL,
  `ProductModelID` int DEFAULT NULL,
  `SellStartDate` datetime NOT NULL,
  `SellEndDate` datetime DEFAULT NULL,
  `DiscontinuedDate` datetime DEFAULT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ProductID`),
  UNIQUE KEY `Name` (`Name`),
  UNIQUE KEY `ProductNumber` (`ProductNumber`),
  UNIQUE KEY `rowguid` (`rowguid`)
);

CREATE TABLE `productcategory` (
  `ProductCategoryID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(64)  NOT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ProductCategoryID`),
  UNIQUE KEY `Name` (`Name`),
  UNIQUE KEY `rowguid` (`rowguid`)
);

CREATE TABLE `productcosthistory` (
  `ProductID` int NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date DEFAULT NULL,
  `StandardCost` double NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ProductID`,`StartDate`)
);

CREATE TABLE `productdescription` (
  `ProductDescriptionID` int NOT NULL AUTO_INCREMENT,
  `Description` varchar(256)  NOT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ProductDescriptionID`),
  UNIQUE KEY `rowguid` (`rowguid`)
);

CREATE TABLE `productdocument` (
  `ProductID` int NOT NULL,
  `DocumentNode` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ProductID`,`DocumentNode`),
  KEY `fk_ProductDocument_DocumentNode` (`DocumentNode`)
);

CREATE TABLE `productinventory` (
  `ProductID` int NOT NULL,
  `LocationID` int NOT NULL,
  `Shelf` varchar(64)  NOT NULL,
  `Bin` int NOT NULL,
  `Quantity` int NOT NULL DEFAULT '0',
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ProductID`,`LocationID`),
  KEY `fk_ProductInventory_LocationID` (`LocationID`)
);

CREATE TABLE `productlistpricehistory` (
  `ProductID` int NOT NULL,
  `StartDate` date NOT NULL,
  `EndDate` date DEFAULT NULL,
  `ListPrice` double NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ProductID`,`StartDate`)
);

CREATE TABLE `productmodel` (
  `ProductModelID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(64)  NOT NULL,
  `CatalogDescription` varchar(4096)  DEFAULT NULL,
  `Instructions` varchar(8192)  DEFAULT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ProductModelID`),
  UNIQUE KEY `Name` (`Name`),
  UNIQUE KEY `rowguid` (`rowguid`)
);

CREATE TABLE `productmodelproductdescriptionculture` (
  `ProductModelID` int NOT NULL,
  `ProductDescriptionID` int NOT NULL,
  `CultureID` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ProductModelID`,`ProductDescriptionID`,`CultureID`),
  KEY `fk_ProductModelProductDescriptionCulture_ProductDescriptionID` (`ProductDescriptionID`),
  KEY `fk_ProductModelProductDescriptionCulture_CultureID` (`CultureID`)
);

CREATE TABLE `productphoto` (
  `ProductPhotoID` int NOT NULL AUTO_INCREMENT,
  `ThumbNailPhoto` blob,
  `ThumbnailPhotoFileName` varchar(64)  DEFAULT NULL,
  `LargePhoto` blob,
  `LargePhotoFileName` varchar(64)  DEFAULT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ProductPhotoID`)
);

CREATE TABLE `productproductphoto` (
  `ProductID` int NOT NULL,
  `ProductPhotoID` int NOT NULL,
  `Primary` int NOT NULL DEFAULT '0',
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ProductID`,`ProductPhotoID`),
  KEY `fk_ProductProductPhoto_ProductPhotoID` (`ProductPhotoID`)
);

CREATE TABLE `productreview` (
  `ProductReviewID` int NOT NULL AUTO_INCREMENT,
  `ProductID` int NOT NULL,
  `ReviewerName` varchar(64)  NOT NULL,
  `ReviewDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `EmailAddress` varchar(64)  NOT NULL,
  `Rating` int NOT NULL,
  `Comments` varchar(256)  DEFAULT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ProductReviewID`),
  KEY `fk_ProductReview_ProductID` (`ProductID`)
);

CREATE TABLE `productsubcategory` (
  `ProductSubcategoryID` int NOT NULL AUTO_INCREMENT,
  `ProductCategoryID` int NOT NULL,
  `Name` varchar(64)  NOT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ProductSubcategoryID`),
  UNIQUE KEY `Name` (`Name`),
  UNIQUE KEY `rowguid` (`rowguid`),
  KEY `fk_ProductSubcategory_ProductCategoryID` (`ProductCategoryID`)
);

CREATE TABLE `productvendor` (
  `ProductID` int NOT NULL,
  `BusinessEntityID` int NOT NULL,
  `AverageLeadTime` int NOT NULL,
  `StandardPrice` double NOT NULL,
  `LastReceiptCost` double DEFAULT NULL,
  `LastReceiptDate` datetime DEFAULT NULL,
  `MinOrderQty` int NOT NULL,
  `MaxOrderQty` int NOT NULL,
  `OnOrderQty` int DEFAULT NULL,
  `UnitMeasureCode` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ProductID`,`BusinessEntityID`),
  KEY `fk_ProductVendor_BusinessEntityID` (`BusinessEntityID`),
  KEY `fk_ProductVendor_UnitMeasureCode` (`UnitMeasureCode`)
);

CREATE TABLE `purchaseorderdetail` (
  `PurchaseOrderID` int NOT NULL,
  `PurchaseOrderDetailID` int NOT NULL AUTO_INCREMENT,
  `DueDate` datetime NOT NULL,
  `OrderQty` int NOT NULL,
  `ProductID` int NOT NULL,
  `UnitPrice` double NOT NULL,
  `LineTotal` double NOT NULL,
  `ReceivedQty` double NOT NULL,
  `RejectedQty` double NOT NULL,
  `StockedQty` double NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`PurchaseOrderDetailID`),
  KEY `fk_PurchaseOrderDetail_PurchaseOrderID` (`PurchaseOrderID`),
  KEY `fk_PurchaseOrderDetail_ProductID` (`ProductID`)
);

CREATE TABLE `purchaseorderheader` (
  `PurchaseOrderID` int NOT NULL AUTO_INCREMENT,
  `RevisionNumber` int NOT NULL DEFAULT '0',
  `Status` int NOT NULL DEFAULT '1',
  `EmployeeID` int NOT NULL,
  `VendorID` int NOT NULL,
  `ShipMethodID` int NOT NULL,
  `OrderDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ShipDate` datetime DEFAULT NULL,
  `SubTotal` double NOT NULL DEFAULT '0',
  `TaxAmt` double NOT NULL DEFAULT '0',
  `Freight` double NOT NULL DEFAULT '0',
  `TotalDue` double NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`PurchaseOrderID`),
  KEY `fk_PurchaseOrderHeader_EmployeeID` (`EmployeeID`),
  KEY `fk_PurchaseOrderHeader_VendorID` (`VendorID`),
  KEY `fk_PurchaseOrderHeader_ShipMethodID` (`ShipMethodID`)
);

CREATE TABLE `salesorderdetail` (
  `SalesOrderID` int NOT NULL,
  `SalesOrderDetailID` int NOT NULL AUTO_INCREMENT,
  `CarrierTrackingNumber` varchar(64)  DEFAULT NULL,
  `OrderQty` int NOT NULL,
  `ProductID` int NOT NULL,
  `SpecialOfferID` int NOT NULL,
  `UnitPrice` double NOT NULL,
  `UnitPriceDiscount` double NOT NULL DEFAULT '0',
  `LineTotal` double NOT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`SalesOrderDetailID`),
  UNIQUE KEY `rowguid` (`rowguid`),
  KEY `fk_SalesOrderDetail_SalesOrderID` (`SalesOrderID`)
);

CREATE TABLE `salesorderheader` (
  `SalesOrderID` int NOT NULL AUTO_INCREMENT,
  `RevisionNumber` int NOT NULL DEFAULT '0',
  `OrderDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `DueDate` datetime NOT NULL,
  `ShipDate` datetime DEFAULT NULL,
  `Status` int NOT NULL DEFAULT '1',
  `OnlineOrderFlag` int NOT NULL DEFAULT '1',
  `SalesOrderNumber` varchar(64)  NOT NULL,
  `PurchaseOrderNumber` varchar(64)  DEFAULT NULL,
  `AccountNumber` varchar(64)  DEFAULT NULL,
  `CustomerID` int NOT NULL,
  `SalesPersonID` int DEFAULT NULL,
  `TerritoryID` int DEFAULT NULL,
  `BillToAddressID` int DEFAULT NULL,
  `ShipToAddressID` int DEFAULT NULL,
  `ShipMethodID` int DEFAULT NULL,
  `CreditCardID` int DEFAULT NULL,
  `CreditCardApprovalCode` varchar(64)  DEFAULT NULL,
  `CurrencyRateID` int DEFAULT NULL,
  `SubTotal` double NOT NULL DEFAULT '0',
  `TaxAmt` double NOT NULL DEFAULT '0',
  `Freight` double NOT NULL DEFAULT '0',
  `TotalDue` double NOT NULL,
  `Comment` varchar(256)  DEFAULT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`SalesOrderID`),
  UNIQUE KEY `SalesOrderNumber` (`SalesOrderNumber`),
  UNIQUE KEY `rowguid` (`rowguid`),
  KEY `fk_SalesOrderHeader_CustomerID` (`CustomerID`),
  KEY `fk_SalesOrderHeader_SalesPersonID` (`SalesPersonID`),
  KEY `fk_SalesOrderHeader_TerritoryID` (`TerritoryID`),
  KEY `fk_SalesOrderHeader_BillToAddressID` (`BillToAddressID`),
  KEY `fk_SalesOrderHeader_ShipToAddressID` (`ShipToAddressID`),
  KEY `fk_SalesOrderHeader_CreditCardID` (`CreditCardID`)
);

CREATE TABLE `salesorderheadersalesreason` (
  `SalesOrderID` int NOT NULL,
  `SalesReasonID` int NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`SalesOrderID`,`SalesReasonID`),
  KEY `fk_SalesOrderHeaderSalesReason_SalesReasonID` (`SalesReasonID`)
);

CREATE TABLE `salesperson` (
  `BusinessEntityID` int NOT NULL,
  `TerritoryID` int DEFAULT NULL,
  `SalesQuota` double DEFAULT NULL,
  `Bonus` double NOT NULL DEFAULT '0',
  `CommissionPct` double NOT NULL DEFAULT '0',
  `SalesYTD` double NOT NULL DEFAULT '0',
  `SalesLastYear` double NOT NULL DEFAULT '0',
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`BusinessEntityID`),
  UNIQUE KEY `rowguid` (`rowguid`),
  KEY `fk_SalesPerson_TerritoryID` (`TerritoryID`)
);

CREATE TABLE `salespersonquotahistory` (
  `BusinessEntityID` int NOT NULL,
  `QuotaDate` datetime NOT NULL,
  `SalesQuota` double NOT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`BusinessEntityID`,`QuotaDate`),
  UNIQUE KEY `rowguid` (`rowguid`)
);

CREATE TABLE `salesreason` (
  `SalesReasonID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(64)  NOT NULL,
  `ReasonType` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`SalesReasonID`)
);

CREATE TABLE `salestaxrate` (
  `SalesTaxRateID` int NOT NULL AUTO_INCREMENT,
  `StateProvinceID` int NOT NULL,
  `TaxType` int NOT NULL,
  `TaxRate` double NOT NULL DEFAULT '0',
  `Name` varchar(64)  NOT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`SalesTaxRateID`),
  UNIQUE KEY `rowguid` (`rowguid`),
  UNIQUE KEY `StateProvinceID` (`StateProvinceID`,`TaxType`)
);

CREATE TABLE `salesterritory` (
  `TerritoryID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(64)  NOT NULL,
  `CountryRegionCode` varchar(64)  NOT NULL,
  `Group` varchar(256)  NOT NULL,
  `SalesYTD` double NOT NULL DEFAULT '0',
  `SalesLastYear` double NOT NULL DEFAULT '0',
  `CostYTD` double NOT NULL DEFAULT '0',
  `CostLastYear` double NOT NULL DEFAULT '0',
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`TerritoryID`),
  UNIQUE KEY `Name` (`Name`),
  UNIQUE KEY `rowguid` (`rowguid`),
  KEY `fk_SalesTerritory_CountryRegionCode` (`CountryRegionCode`)
);

CREATE TABLE `salesterritoryhistory` (
  `BusinessEntityID` int NOT NULL,
  `TerritoryID` int NOT NULL,
  `StartDate` datetime NOT NULL,
  `EndDate` datetime DEFAULT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`BusinessEntityID`,`StartDate`,`TerritoryID`),
  UNIQUE KEY `rowguid` (`rowguid`),
  KEY `fk_SalesTerritoryHistory_TerritoryID` (`TerritoryID`)
);

CREATE TABLE `scrapreason` (
  `ScrapReasonID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ScrapReasonID`),
  UNIQUE KEY `Name` (`Name`)
);

CREATE TABLE `shift` (
  `ShiftID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(64)  NOT NULL,
  `StartTime` varchar(64)  NOT NULL,
  `EndTime` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ShiftID`),
  UNIQUE KEY `Name` (`Name`),
  UNIQUE KEY `StartTime` (`StartTime`,`EndTime`)
);

CREATE TABLE `shipmethod` (
  `ShipMethodID` int NOT NULL AUTO_INCREMENT,
  `Name` varchar(64)  NOT NULL,
  `ShipBase` double NOT NULL DEFAULT '0',
  `ShipRate` double NOT NULL DEFAULT '0',
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ShipMethodID`),
  UNIQUE KEY `Name` (`Name`),
  UNIQUE KEY `rowguid` (`rowguid`)
);

CREATE TABLE `shoppingcartitem` (
  `ShoppingCartItemID` int NOT NULL AUTO_INCREMENT,
  `ShoppingCartID` varchar(64)  NOT NULL,
  `Quantity` int NOT NULL DEFAULT '1',
  `ProductID` int NOT NULL,
  `DateCreated` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`ShoppingCartItemID`),
  KEY `fk_ShoppingCartItem_ProductID` (`ProductID`)
);

CREATE TABLE `specialoffer` (
  `SpecialOfferID` int NOT NULL AUTO_INCREMENT,
  `Description` varchar(64)  NOT NULL,
  `DiscountPct` double NOT NULL DEFAULT '0',
  `Type` varchar(64)  NOT NULL,
  `Category` varchar(64)  NOT NULL,
  `StartDate` datetime NOT NULL,
  `EndDate` datetime NOT NULL,
  `MinQty` int NOT NULL DEFAULT '0',
  `MaxQty` int DEFAULT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`SpecialOfferID`),
  UNIQUE KEY `rowguid` (`rowguid`)
);

CREATE TABLE `specialofferproduct` (
  `SpecialOfferID` int NOT NULL,
  `ProductID` int NOT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`SpecialOfferID`,`ProductID`),
  UNIQUE KEY `rowguid` (`rowguid`),
  KEY `fk_SpecialOfferProduct_ProductID` (`ProductID`)
);

CREATE TABLE `stateprovince` (
  `StateProvinceID` int NOT NULL AUTO_INCREMENT,
  `StateProvinceCode` varchar(64)  NOT NULL,
  `CountryRegionCode` varchar(64)  NOT NULL,
  `IsOnlyStateProvinceFlag` int NOT NULL DEFAULT '1',
  `Name` varchar(64)  NOT NULL,
  `TerritoryID` int NOT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`StateProvinceID`),
  UNIQUE KEY `Name` (`Name`),
  UNIQUE KEY `rowguid` (`rowguid`),
  UNIQUE KEY `StateProvinceCode` (`StateProvinceCode`,`CountryRegionCode`),
  KEY `fk_StateProvince_CountryRegionCode` (`CountryRegionCode`),
  KEY `fk_StateProvince_TerritoryID` (`TerritoryID`)
);

CREATE TABLE `store` (
  `BusinessEntityID` int NOT NULL,
  `Name` varchar(64)  NOT NULL,
  `SalesPersonID` int DEFAULT NULL,
  `Demographics` varchar(512)  DEFAULT NULL,
  `rowguid` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`BusinessEntityID`),
  UNIQUE KEY `rowguid` (`rowguid`),
  KEY `fk_Store_SalesPersonID` (`SalesPersonID`)
);

CREATE TABLE `transactionhistory` (
  `TransactionID` int NOT NULL AUTO_INCREMENT,
  `ProductID` int NOT NULL,
  `ReferenceOrderID` int NOT NULL,
  `ReferenceOrderLineID` int NOT NULL DEFAULT '0',
  `TransactionDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `TransactionType` varchar(64)  NOT NULL,
  `Quantity` int NOT NULL,
  `ActualCost` double NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`TransactionID`),
  KEY `fk_TransactionHistory_ProductID` (`ProductID`)
);

CREATE TABLE `transactionhistoryarchive` (
  `TransactionID` int NOT NULL,
  `ProductID` int NOT NULL,
  `ReferenceOrderID` int NOT NULL,
  `ReferenceOrderLineID` int NOT NULL DEFAULT '0',
  `TransactionDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `TransactionType` varchar(64)  NOT NULL,
  `Quantity` int NOT NULL,
  `ActualCost` double NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`TransactionID`)
);

CREATE TABLE `unitmeasure` (
  `UnitMeasureCode` varchar(64)  NOT NULL,
  `Name` varchar(64)  NOT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`UnitMeasureCode`),
  UNIQUE KEY `Name` (`Name`)
);

CREATE TABLE `vendor` (
  `BusinessEntityID` int NOT NULL,
  `AccountNumber` varchar(64)  NOT NULL,
  `Name` varchar(64)  NOT NULL,
  `CreditRating` int NOT NULL,
  `PreferredVendorStatus` int NOT NULL DEFAULT '1',
  `ActiveFlag` int NOT NULL DEFAULT '1',
  `PurchasingWebServiceURL` varchar(64)  DEFAULT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`BusinessEntityID`),
  UNIQUE KEY `AccountNumber` (`AccountNumber`)
);

CREATE TABLE `workorder` (
  `WorkOrderID` int NOT NULL AUTO_INCREMENT,
  `ProductID` int NOT NULL,
  `OrderQty` int NOT NULL,
  `StockedQty` int NOT NULL,
  `ScrappedQty` int NOT NULL,
  `StartDate` datetime NOT NULL,
  `EndDate` datetime DEFAULT NULL,
  `DueDate` datetime NOT NULL,
  `ScrapReasonID` int DEFAULT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`WorkOrderID`),
  KEY `fk_WorkOrder_ProductID` (`ProductID`),
  KEY `fk_WorkOrder_ScrapReasonID` (`ScrapReasonID`)
);

CREATE TABLE `workorderrouting` (
  `WorkOrderID` int NOT NULL,
  `ProductID` int NOT NULL,
  `OperationSequence` int NOT NULL,
  `LocationID` int NOT NULL,
  `ScheduledStartDate` datetime NOT NULL,
  `ScheduledEndDate` datetime NOT NULL,
  `ActualStartDate` datetime DEFAULT NULL,
  `ActualEndDate` datetime DEFAULT NULL,
  `ActualResourceHrs` double DEFAULT NULL,
  `PlannedCost` double NOT NULL,
  `ActualCost` double DEFAULT NULL,
  `ModifiedDate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`WorkOrderID`,`ProductID`,`OperationSequence`),
  KEY `fk_WorkOrderRouting_LocationID` (`LocationID`)
);


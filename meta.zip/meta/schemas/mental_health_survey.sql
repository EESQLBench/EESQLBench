CREATE TABLE `answer` (
  `AnswerText` varchar(4096)  DEFAULT NULL,
  `SurveyID` int NOT NULL,
  `UserID` int NOT NULL,
  `QuestionID` int NOT NULL,
  PRIMARY KEY (`UserID`,`QuestionID`),
  KEY `fk_Answer_SurveyID` (`SurveyID`),
  KEY `fk_Answer_QuestionID` (`QuestionID`)
);

CREATE TABLE `question` (
  `questiontext` varchar(256)  DEFAULT NULL,
  `questionid` int NOT NULL,
  PRIMARY KEY (`questionid`)
);

CREATE TABLE `survey` (
  `SurveyID` int NOT NULL,
  `Description` varchar(64)  DEFAULT NULL,
  PRIMARY KEY (`SurveyID`)
);


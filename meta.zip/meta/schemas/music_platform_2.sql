CREATE TABLE `categories` (
  `podcast_id` varchar(64)  NOT NULL,
  `category` varchar(64)  NOT NULL,
  PRIMARY KEY (`podcast_id`,`category`)
);

CREATE TABLE `podcasts` (
  `podcast_id` varchar(64)  NOT NULL,
  `itunes_id` int NOT NULL,
  `slug` text  NOT NULL,
  `itunes_url` text  NOT NULL,
  `title` text  NOT NULL,
  PRIMARY KEY (`podcast_id`)
);

CREATE TABLE `reviews` (
  `podcast_id` varchar(64)  NOT NULL,
  `title` varchar(128)  NOT NULL,
  `content` varchar(8192)  NOT NULL,
  `rating` int NOT NULL,
  `author_id` varchar(64)  NOT NULL,
  `created_at` varchar(64)  NOT NULL,
  KEY `fk_reviews_podcast_id` (`podcast_id`)
);

CREATE TABLE `runs` (
  `run_at` text  NOT NULL,
  `max_rowid` int NOT NULL,
  `reviews_added` int NOT NULL
);


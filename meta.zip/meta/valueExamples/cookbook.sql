INSERT INTO `ingredient` VALUES (1, 'dairy', '1% lowfat cottage cheese', NULL);
INSERT INTO `ingredient` VALUES (6, 'dairy', '1% lowfat milk', NULL);
INSERT INTO `nutrition` VALUES (214, 5.47, 41.29, 0.0, 11.53, 2.21, 1.39, 260.78, 0.81, 8.89, 586.2, 0.87, 56.8, 35.68, 7.53, 290.79);
INSERT INTO `nutrition` VALUES (215, 5.7, 23.75, 1.93, 1.08, 0.58, 3.48, 46.17, 0.57, 13.02, 2738.24, 0.62, 67.38, 6.89, 16.17, 141.01);
INSERT INTO `quantity` VALUES (1, 214, 1613, 2.0, 2.0, 'cup(s)', NULL, 'FALSE');
INSERT INTO `quantity` VALUES (2, 214, 3334, 0.25, 0.25, 'cup(s)', NULL, 'FALSE');
INSERT INTO `recipe` VALUES (214, 'Raspberry Chiffon Pie', NULL, 10, '1 pie', 20, 8, 305, 'The California Tree Fruit Agreement', NULL, 'For crust, preheat oven to 375 degrees F.
In lightly greased 10-inch pie plate, combine graham cracker crumbs, melted butter and 1/4 cup sugar. Press evenly on bottom and up side of plate. Bake 5 minutes; cool.

For filling, in medium saucepan, combine juice or water and gelatin; let stand 5 minutes. Add 1/3 cup sugar and heat over medium heat, stirring to dissolve gelatin. In blender or food processor, puree 6 plums. Add puree and raspberries to gelatin mixture. Refrigerate until mixture begins to set about 1 hour. Stir yogurt into fruit mixture. In large bowl, beat egg whites until frothy. Gradually add cream of tartar and remaining 1/3 cup sugar and beat until stiff peaks form. Gently fold egg whites into fruit mixture so as not to reduce volume. Spoon into crust. Refrigerate 4 hours or overnight. Thinly slice remaining 2 plums and garnish top of pie.');
INSERT INTO `recipe` VALUES (215, 'Apricot Yogurt Parfaits', NULL, 4, NULL, 5, 2, 65, 'Produce for Better Health Foundation and 5 a Day', NULL, 'Drain canned apricots, pour 1/4 cup of the juice into saucepan or microwave-safe dish. Sprinkle gelatin over juice and let stand for 5 minutes to soften. Warm over low heat or microwave at medium (50% power) for 30 seconds or until gelatin has dissolved.
 
In food processor or blender, puree canned apricots; add lemon juice brandy, yogurt and gelatin mixture and process for 30 seconds or until combined.
 
Pour into parfait or stemmed glasses or champagne flutes. Cover and refrigerate until set, at least 1 hour or overnight.
 
Just before serving arrange fresh apricots on top. (If apricots are not available substitute kiwi slices or berries). Garnish each with a small spoonful of yogurt and sprinkling of brown sugar or mint.');

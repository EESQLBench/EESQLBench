INSERT INTO `businesses` VALUES (10, 'Tiramisu Kitchen', '033 Belden Pl', 'San Francisco', '94104', 37.7911, -122.404, NULL, 'H24', 779059, NULL, 'Tiramisu LLC', '33 Belden St', 'San Francisco', 'CA', '94104');
INSERT INTO `businesses` VALUES (24, 'OMNI S.F. Hotel - 2nd Floor Pantry', '500 California St, 2nd  Floor', 'San Francisco', '94104', 37.7929, -122.403, NULL, 'H24', 352312, NULL, 'OMNI San Francisco Hotel Corp', '500 California St, 2nd Floor', 'San Francisco', 'CA', '94104');
INSERT INTO `inspections` VALUES (10, 92, '2014-01-14', 'Routine - Unscheduled');
INSERT INTO `inspections` VALUES (10, NULL, '2014-01-24', 'Reinspection/Followup');
INSERT INTO `violations` VALUES (10, '2014-07-29', '103129', 'Moderate Risk', 'Insufficient hot water or running water');
INSERT INTO `violations` VALUES (10, '2014-07-29', '103144', 'Low Risk', 'Unapproved or unmaintained equipment or utensils');

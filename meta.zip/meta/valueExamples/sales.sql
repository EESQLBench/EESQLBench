INSERT INTO `customers` VALUES (1, 'Aaron', NULL, 'Alexander');
INSERT INTO `customers` VALUES (2, 'Aaron', NULL, 'Bryant');
INSERT INTO `employees` VALUES (1, 'Abraham', 'e', 'Bennet');
INSERT INTO `employees` VALUES (2, 'Reginald', 'l', 'Blotchet-Halls');
INSERT INTO `products` VALUES (1, 'Adjustable Race', 1.6);
INSERT INTO `products` VALUES (2, 'Bearing Ball', 0.8);
INSERT INTO `sales` VALUES (1, 17, 10482, 500, 500);
INSERT INTO `sales` VALUES (2, 5, 1964, 306, 810);

INSERT INTO `categories` VALUES ('a00018b54eb342567c94dacfb2a3e504', 'business');
INSERT INTO `categories` VALUES ('a00043d34e734b09246d17dc5d56f63c', 'christianity');
INSERT INTO `podcasts` VALUES ('a00018b54eb342567c94dacfb2a3e504', 1313466221, 'scaling-global', 'https://podcasts.apple.com/us/podcast/scaling-global/id1313466221', 'Scaling Global');
INSERT INTO `podcasts` VALUES ('a00043d34e734b09246d17dc5d56f63c', 158973461, 'cornerstone-baptist-church-of-orlando', 'https://podcasts.apple.com/us/podcast/cornerstone-baptist-church-of-orlando/id158973461', 'Cornerstone Baptist Church of Orlando');
INSERT INTO `reviews` VALUES ('c61aa81c9b929a66f0c1db6cbe5d8548', 'really interesting!', 'Thanks for providing these insights.  Really enjoy the variety and depth -- please keep them coming!', 5, 'F7E5A318989779D', '2018-04-24T12:05:16-07:00');
INSERT INTO `reviews` VALUES ('c61aa81c9b929a66f0c1db6cbe5d8548', 'Must listen for anyone interested in the arts!!!', 'Super excited to see this podcast grow. So many fun topics to talk about...Shari is really engaging. Definitely subscribing and would recommend to anyone interested in the arts!!', 5, 'F6BF5472689BD12', '2018-05-09T18:14:32-07:00');
INSERT INTO `runs` VALUES ('2021-05-10 02:53:00', 3266481, 1215223);
INSERT INTO `runs` VALUES ('2021-06-06 21:34:36', 3300773, 13139);

INSERT INTO `tags` VALUES (0, 0, '1970s');
INSERT INTO `tags` VALUES (1, 0, 'funk');
INSERT INTO `torrents` VALUES ('superappin&#39;', 239, 'grandmaster flash & the furious five', 1979, 'single', 720949, 0);
INSERT INTO `torrents` VALUES ('spiderap / a corona jam', 156, 'ron hunt & ronnie g & the sm crew', 1979, 'single', 728752, 1);

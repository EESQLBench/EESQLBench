INSERT INTO `height_info` VALUES (65, 165, '5''5"');
INSERT INTO `height_info` VALUES (67, 170, '5''7"');
INSERT INTO `playerinfo` VALUES (9, 'David Bornhammar', '1981-06-15', 1981, 6, 15, 'Lidingo, SWE', 'Sweden', 73, 198, 'D', 'L', 1999, 7, 192, 'Washington Capitals', 192, 0, 0, 'no');
INSERT INTO `playerinfo` VALUES (18, 'David Printz', '1980-07-24', 1980, 7, 24, 'Stockholm, SWE', 'Sweden', 76, 220, 'D', 'L', 2001, 7, 225, 'Philadelphia Flyers', 176, 13, 84, 'yes');
INSERT INTO `seasonstatus` VALUES (3667, '1997-1998', 'Rimouski Oceanic', 'QMJHL', 'Regular Season', 58, 44, 71, 115, 117, 27);
INSERT INTO `seasonstatus` VALUES (3667, '1997-1998', 'Rimouski Oceanic', 'QMJHL', 'Playoffs', 18, 15, 26, 41, 46, 4);
INSERT INTO `weight_info` VALUES (154, 70, 154);
INSERT INTO `weight_info` VALUES (159, 72, 159);

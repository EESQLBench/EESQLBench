INSERT INTO `station` VALUES (2, 'San Jose Diridon Caltrain Station', 37.329732, -121.90178200000001, 27, 'San Jose', '8/6/2013');
INSERT INTO `station` VALUES (3, 'San Jose Civic Center', 37.330698, -121.888979, 15, 'San Jose', '8/5/2013');
INSERT INTO `status` VALUES (2, 2, 25, '2013-08-29 12:06:01');
INSERT INTO `status` VALUES (2, 2, 25, '2013-08-29 12:07:01');
INSERT INTO `trip` VALUES (4069, 174, '2013-08-29 09:08:00', '2nd at South Park', 64, '2013-08-29 09:11:00', '2nd at South Park', 64, 288, 'Subscriber', 94114);
INSERT INTO `trip` VALUES (4073, 1067, '2013-08-29 09:24:00', 'South Van Ness at Market', 66, '2013-08-29 09:42:00', 'San Francisco Caltrain 2 (330 Townsend)', 69, 321, 'Subscriber', 94703);
INSERT INTO `weather` VALUES ('2013-08-29', 74, 68, 61, 61, 58, 56, 93, 75, 57, 30.07, 30.02, 29.97, 10, 10, 10, 23, 11, 28, '0', 4, '', 286, '94107');
INSERT INTO `weather` VALUES ('2013-08-30', 78, 69, 60, 61, 58, 56, 90, 70, 50, 30.05, 30.0, 29.93, 10, 10, 7, 29, 13, 35, '0', 2, '', 291, '94107');

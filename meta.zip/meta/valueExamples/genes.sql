INSERT INTO `classification` VALUES ('G234064', 'cytoplasm');
INSERT INTO `classification` VALUES ('G234065', 'cytoplasm');
INSERT INTO `genes` VALUES ('G234064', 'Essential', 'GTP/GDP-exchange factors (GEFs)', 'Translation complexes', '?', 'PS00824', 1, 'CELLULAR ORGANIZATION (proteins are localized to the corresponding organelle)', 'cytoplasm');
INSERT INTO `genes` VALUES ('G234064', 'Essential', 'GTP/GDP-exchange factors (GEFs)', 'Translation complexes', '?', 'PS00824', 1, 'PROTEIN SYNTHESIS', 'cytoplasm');
INSERT INTO `interactions` VALUES ('G234064', 'G234126', 'Genetic-Physical', 0.914095071);
INSERT INTO `interactions` VALUES ('G234064', 'G235065', 'Genetic-Physical', 0.751584888);

INSERT INTO `method` VALUES (1, 'HtmlSharp.HtmlParser.Feed', 'Feeds data into the parser', NULL, 'System.String.IsNullOrEmpty HtmlSharp.HtmlParser.GoAhead HtmlSharp.HtmlParser.EndData HtmlSharp.HtmlParser.PopTag', 0, 636430963695654788, 1, NULL, 'html parser feed');
INSERT INTO `method` VALUES (2, 'HtmlSharp.HtmlParser.ParseDoctypeElement', ' interneral -- scan past <!ELEMENT declarations', NULL, 'HtmlSharp.HtmlParser.ScanName System.Collections.Generic.KeyValuePair.Value System.String.Substring System.String.Contains System.StringComparison.Ordinal System.String.IndexOf', 0, 636430963695709898, 1, NULL, 'html parser parse doctype element');
INSERT INTO `methodparameter` VALUES (1, '1', 'System.String', 'data');
INSERT INTO `methodparameter` VALUES (2, '2', 'System.Int32', 'i');
INSERT INTO `repo` VALUES (1, 'https://github.com/wallerdev/htmlsharp.git', 14, 2, 14, 636430963247108053);
INSERT INTO `repo` VALUES (2, 'https://github.com/unclebob/nslim.git', 6, 3, 6, 636472436323838240);
INSERT INTO `solution` VALUES (1, 1, 'wallerdev_htmlsharpHtmlSharp.sln', 636430963695642191, 1);
INSERT INTO `solution` VALUES (2, 3, 'maravillas_linq-to-delicious	asty.sln', 636430963721734366, 1);

INSERT INTO `answer` VALUES ('37', 2014, 1, 1);
INSERT INTO `answer` VALUES ('Female', 2014, 1, 2);
INSERT INTO `question` VALUES ('What is your age?', 1);
INSERT INTO `question` VALUES ('What is your gender?', 2);
INSERT INTO `survey` VALUES (2014, 'mental health survey for 2014');
INSERT INTO `survey` VALUES (2016, 'mental health survey for 2016');

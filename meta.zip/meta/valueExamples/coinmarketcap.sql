INSERT INTO `coins` VALUES (1, 'Bitcoin', 'bitcoin', 'BTC', 'active', 'coin', '## **What Is Bitcoin (BTC)?**

Bitcoin is a decentralized cryptocurrency originally described in a 2008 [whitepaper](https://coinmarketcap.com/alexandria/glossary/whitepaper) by a person, or group of people, using the alias [Satoshi Nakamoto](https://co', 'bitcoin', NULL, 'mineable, pow, sha-256, store-of-value, state-channels, coinbase-ventures-portfolio, three-arrows-capital-portfolio, polychain-capital-portfolio, binance-labs-portfolio, arrington-xrp-capital, blockchain-capital-portfolio, boostvc-portfolio, cms-holdings-', 'Mineable, PoW, SHA-256, Store of Value, State channels, Coinbase Ventures Portfolio, Three Arrows Capital Portfolio, Polychain Capital Portfolio, Binance Labs Portfolio, Arrington XRP capital, Blockchain Capital Portfolio, BoostVC Portfolio, CMS Holdings ', 'https://bitcoin.org/', NULL, '2013-04-28 00:00:00', NULL);
INSERT INTO `coins` VALUES (2, 'Litecoin', 'litecoin', 'LTC', 'active', 'coin', '## What Is Litecoin (LTC)?

Litecoin (LTC) is a cryptocurrency that was designed to provide fast, secure and low-cost payments by leveraging the unique properties of [blockchain](https://coinmarketcap.com/alexandria/glossary/blockchain) technology. 

', 'litecoin', NULL, 'mineable, pow, scrypt, medium-of-exchange, binance-chain', 'Mineable, PoW, Scrypt, Medium of Exchange, Binance Chain', 'https://litecoin.org/', NULL, '2013-04-28 00:00:00', NULL);
INSERT INTO `historical` VALUES ('2013-04-28', 1, 1, 1488566971.9558687, 134.210021972656, NULL, NULL, NULL, NULL, NULL, NULL, 0.0, 0.639231, NULL, NULL, 11091325.0, 11091325.0, 21000000.0, NULL);
INSERT INTO `historical` VALUES ('2013-04-28', 2, 2, 74637021.56790735, 4.34840488433838, NULL, NULL, NULL, NULL, NULL, NULL, 0.0, 0.799273, NULL, NULL, 17164230.0, 17164230.0, 84000000.0, NULL);

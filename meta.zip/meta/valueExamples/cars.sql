INSERT INTO `country` VALUES (1, 'USA');
INSERT INTO `country` VALUES (2, 'Europe');
INSERT INTO `data` VALUES (1, 18.0, 8, 307.0, 130, 3504, 12.0, 70, 'chevrolet chevelle malibu');
INSERT INTO `data` VALUES (2, 15.0, 8, 350.0, 165, 3693, 11.5, 70, 'buick skylark 320');
INSERT INTO `price` VALUES (1, 25561.59078);
INSERT INTO `price` VALUES (2, 24221.42273);
INSERT INTO `production` VALUES (1, 1970, 1);
INSERT INTO `production` VALUES (1, 1971, 1);

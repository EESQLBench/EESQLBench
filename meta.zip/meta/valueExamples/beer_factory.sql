INSERT INTO `customers` VALUES (101811, 'Kenneth', 'Walton', '6715 Commonwealth Dr', 'Sacramento', 'CA', 94256, 'walton.k76@fastmail.com', '(916) 918-1561', '2013-05-30', 'FALSE', 'M');
INSERT INTO `customers` VALUES (103508, 'Madeleine', 'Jones', '3603 Leola Way', 'Sacramento', 'CA', 94258, 'j_madeleine@gmail.com', '(916) 186-9423', '2013-02-06', 'FALSE', 'F');
INSERT INTO `geolocation` VALUES (0, 0.0, 0.0);
INSERT INTO `geolocation` VALUES (1, 38.566129, -121.426432);
INSERT INTO `location` VALUES (0, 'LOST', NULL, NULL, NULL, NULL);
INSERT INTO `location` VALUES (1, 'Sac State American River Courtyard', '6000 J St', 'Sacramento', 'CA', 95819);
INSERT INTO `rootbeer` VALUES (100000, 10001, 'Bottle', 1, '2015-07-03');
INSERT INTO `rootbeer` VALUES (100001, 10001, 'Bottle', 1, '2016-05-09');
INSERT INTO `rootbeerbrand` VALUES (10001, 'A&W', 1919, 'Dr Pepper Snapple Group', 'Lodi', 'CA', 'United States', 'After setting up the first A&W Root Beer stand in California in 1919, Roy Allen partnered with Frank Wright to name their beverage A&W. The two partners then set out to open more root beer stands all across the United States.', 'FALSE', 'TRUE', 'FALSE', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'FALSE', 'FALSE', 'http://www.rootbeer.com/', NULL, NULL, 0.42, 1.0);
INSERT INTO `rootbeerbrand` VALUES (10002, 'A.J. Stephans', 1926, 'AJ Stephans Beverages', 'Fall River', 'MA', 'United States', 'AJ Stephans Company makes 
the finest elixirs and mixers in New England', 'TRUE', 'FALSE', 'FALSE', 'FALSE', 'FALSE', 'FALSE', 'FALSE', 'TRUE', 'FALSE', 'http://www.ajstephans.com/', NULL, NULL, 0.98, 3.0);
INSERT INTO `rootbeerreview` VALUES (101811, 10012, 5, '2013-07-15', NULL);
INSERT INTO `rootbeerreview` VALUES (101811, 10014, 1, '2013-07-08', NULL);
INSERT INTO `transaction` VALUES (100000, 6011583832864739, 864896, '2014-07-07', 'Discover', 2, 105661, 3.0);
INSERT INTO `transaction` VALUES (100001, 6011583832864739, 864896, '2014-07-07', 'Discover', 2, 105798, 3.0);

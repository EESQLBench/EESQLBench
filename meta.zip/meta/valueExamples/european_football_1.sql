INSERT INTO `divisions` VALUES ('B1', 'Division 1A', 'Belgium');
INSERT INTO `divisions` VALUES ('D1', 'Bundesliga', 'Deutschland');
INSERT INTO `matchs` VALUES ('B1', '2020-08-08', 'Club Brugge', 'Charleroi', 0, 1, 'A', 2021);
INSERT INTO `matchs` VALUES ('B1', '2020-08-08', 'Antwerp', 'Mouscron', 1, 1, 'D', 2021);

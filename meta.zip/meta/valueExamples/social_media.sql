INSERT INTO `location` VALUES (1, 'Albania', 'Elbasan', 'AL', 'Elbasan');
INSERT INTO `location` VALUES (2, 'Albania', 'Tirane', 'AL', 'Tirana');
INSERT INTO `twitter` VALUES ('tw-682712873332805633', 'Thursday', 17, 31, 'en', 'FALSE', 44, 0, 0, 35, 0.0, 'We are hiring: Senior Software Engineer - Proto http://www.reqcloud.com/jobs/719865/?k=0LaPxXuFwczs1e32ZURJKrgCIDMQtRO7BquFSQthUKY&utm_source=twitter&utm_campaign=reqCloud_JobPost #job @awscloud #job #protocol #networking #aws #mediastreaming', 3751, 'tw-40932430');
INSERT INTO `twitter` VALUES ('tw-682713045357998080', 'Thursday', 17, 31, 'en', 'TRUE', 1810, 5, 0, 53, 2.0, 'RT @CodeMineStatus: This is true Amazon Web Services https://aws.amazon.com/ #php #html #html5 #css #webdesign #seo #java #javascript htt', 3989, 'tw-3179389829');
INSERT INTO `user` VALUES ('nknow531394', 'Male');
INSERT INTO `user` VALUES ('tw-10000632', 'Female');

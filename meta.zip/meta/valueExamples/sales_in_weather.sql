INSERT INTO `relation` VALUES (1, 1);
INSERT INTO `relation` VALUES (16, 2);
INSERT INTO `sales_in_weather` VALUES ('2012-01-01', 1, 1, 0);
INSERT INTO `sales_in_weather` VALUES ('2012-01-01', 1, 2, 0);
INSERT INTO `weather` VALUES (1, '2012-01-01', 52, 31, 42, NULL, 36, 40, 23, 0, NULL, NULL, 'RA FZFG BR', NULL, 0.05, 29.78, 29.92, 3.6, 20, 4.6);
INSERT INTO `weather` VALUES (1, '2012-01-02', 50, 31, 41, NULL, 26, 35, 24, 0, NULL, NULL, ' ', NULL, 0.01, 29.44, 29.62, 9.8, 24, 10.3);

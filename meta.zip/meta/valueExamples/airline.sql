INSERT INTO `air carriers` VALUES (19031, 'Mackey International Inc.: MAC');
INSERT INTO `air carriers` VALUES (19032, 'Munz Northern Airlines Inc.: XY');
INSERT INTO `airlines` VALUES ('2018/8/1', 19805, 'N956AN', 1587, 12478, 1247805, 31703, 'JFK', 14107, 1410702, 30466, 'PHX', 1640, 1649, 9, 9, 2006, 44, 44, 0, NULL, 342, 377, 9, 0, 35, 0, 0);
INSERT INTO `airlines` VALUES ('2018/8/1', 19805, 'N973AN', 1588, 14107, 1410702, 30466, 'PHX', 11618, 1161802, 31703, 'EWR', 1512, 1541, 29, 29, 2350, 53, 53, 0, NULL, 285, 309, 0, 0, 53, 0, 0);
INSERT INTO `airports` VALUES ('01A', 'Afognak Lake, AK: Afognak Lake Airport');
INSERT INTO `airports` VALUES ('03A', 'Granite Mountain, AK: Bear Creek Mining Strip');

INSERT INTO `city` VALUES (1, 'Kabul', 'AFG', 'Kabol', 1780000);
INSERT INTO `city` VALUES (2, 'Qandahar', 'AFG', 'Qandahar', 237500);
INSERT INTO `country` VALUES ('AAA', 'Nation_AAA', 'North America', 'South North America', 1951097.6, 1462, 145058309, 72.0, 636789.93, 573110.94, 'Local_Nation_AAA', 'Monarchy', 'HeadOfState_AAA', NULL, 'AA');
INSERT INTO `country` VALUES ('AAB', 'Nation_AAB', 'Oceania', 'West Oceania', 1170884.9, 1014, 989070702, 75.7, 499480.93, 449532.84, 'Local_Nation_AAB', 'Territory', 'HeadOfState_AAB', NULL, 'AA');
INSERT INTO `countrylanguage` VALUES ('AAA', 'Dutch', 'T', 92.1);
INSERT INTO `countrylanguage` VALUES ('AAB', 'Bengali', 'T', 94.1);

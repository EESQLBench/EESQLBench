INSERT INTO `generalinfo` VALUES (1, 'sparky''s diner', '24 hour diner', 'san francisco', 2.3);
INSERT INTO `generalinfo` VALUES (2, 'kabul afghan cuisine', 'afghani', 'san carlos', 3.8);
INSERT INTO `geographic` VALUES ('alameda', 'alameda county', 'bay area');
INSERT INTO `geographic` VALUES ('alamo', 'contra costa county', 'bay area');
INSERT INTO `location` VALUES (1, 242, 'church st', 'san francisco');
INSERT INTO `location` VALUES (2, 135, 'el camino real', 'san carlos');

INSERT INTO `playstore` VALUES ('Photo Editor & Candy Camera & Grid & ScrapBook', 'ART_AND_DESIGN', 4.1, 159, '19M', '10,000+', 'Free', '0', 'Everyone', 'Art & Design');
INSERT INTO `playstore` VALUES ('Coloring book moana', 'ART_AND_DESIGN', 3.9, 967, '14M', '500,000+', 'Free', '0', 'Everyone', 'Art & Design;Pretend Play');
INSERT INTO `user_reviews` VALUES ('10 Best Foods for You', 'I like eat delicious food. That''s I''m cooking food myself, case "10 Best Foods" helps lot, also "Best Before (Shelf Life)"', 'Positive', '1.0', '0.5333333333333333');
INSERT INTO `user_reviews` VALUES ('10 Best Foods for You', 'This help eating healthy exercise regular basis', 'Positive', '0.25', '0.28846153846153844');

INSERT INTO `chapters` VALUES (18704, 1, 1, 'DUKE ORSINO’s palace.', 1);
INSERT INTO `chapters` VALUES (18705, 1, 2, 'The sea-coast.', 1);
INSERT INTO `characters` VALUES (1, 'First Apparition', 'First Apparition', '');
INSERT INTO `characters` VALUES (2, 'First Citizen', 'First Citizen', '');
INSERT INTO `paragraphs` VALUES (630863, 3, '[Enter DUKE ORSINO, CURIO, and other Lords; Musicians attending]', 1261, 18704);
INSERT INTO `paragraphs` VALUES (630864, 4, 'If music be the food of love, play on;
Give me excess of it, that, surfeiting,
The appetite may sicken, and so die.
That strain again! it had a dying fall:
O, it came o''er my ear like the sweet sound,
That breathes upon a bank of violets,
Stealing and giving odour! Enough; no more:
''Tis not so sweet now as it was before.
O spirit of love! how quick and fresh art thou,
That, notwithstanding thy capacity
Receiveth as the sea, nought enters there,
Of what validity and pitch soe''er,
But falls into abatement and low price,
Even in a minute: so full of shapes is fancy
That it alone is high fantastical.', 840, 18704);
INSERT INTO `works` VALUES (1, 'Twelfth Night', 'Twelfth Night, Or What You Will', 1599, 'Comedy');
INSERT INTO `works` VALUES (2, 'All''s Well That Ends Well', 'All''s Well That Ends Well', 1602, 'Comedy');

INSERT INTO `beers` VALUES (1, 166, 0.065, 65.0, 'Dale''s Pale Ale', 'American Pale Ale (APA)', 12.0);
INSERT INTO `beers` VALUES (4, 166, 0.087, 85.0, 'Gordon Ale (2009)', 'American Double / Imperial IPA', 12.0);
INSERT INTO `breweries` VALUES (0, 'NorthGate Brewing ', 'Minneapolis', 'MN');
INSERT INTO `breweries` VALUES (1, 'Against the Grain Brewery', 'Louisville', 'KY');

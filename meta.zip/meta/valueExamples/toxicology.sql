INSERT INTO `atom` VALUES ('TR000_1', 'TR000', 'cl');
INSERT INTO `atom` VALUES ('TR000_2', 'TR000', 'c');
INSERT INTO `bond` VALUES ('TR000_1_2', 'TR000', '-');
INSERT INTO `bond` VALUES ('TR000_2_3', 'TR000', '-');
INSERT INTO `connected` VALUES ('TR000_1', 'TR000_2', 'TR000_1_2');
INSERT INTO `connected` VALUES ('TR000_2', 'TR000_1', 'TR000_1_2');
INSERT INTO `molecule` VALUES ('TR000', '+');
INSERT INTO `molecule` VALUES ('TR001', '+');
